<?php
$brand = isset($_GET['brand']) ? trim($_GET['brand']) : 'Royal Canin';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'terbaru';
$min_price = isset($_GET['min_price']) ? (int)$_GET['min_price'] : 0;
$max_price = isset($_GET['max_price']) ? (int)$_GET['max_price'] : 0;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 12;

/*
|--------------------------------------------------------------------------
| DATA PRODUK
|--------------------------------------------------------------------------
| Produk dibuat khusus untuk kucing.
| Nama dan contoh harga disusun berdasarkan daftar produk yang terlihat
| pada halaman brand Petshop Indonesia yang dirujuk.
*/
// 1. Panggil koneksi database
include 'koneksi.php';

// 2. Siapkan wadah array kosong
$produk = [];

// 3. Ambil semua data dari tabel 'produk' di database
$query = mysqli_query($koneksi, "SELECT * FROM produk");

// 4. Pindahkan data dari MySQL ke dalam array $produk secara otomatis
while ($row = mysqli_fetch_assoc($query)) {
    $produk[] = $row;
}

$brand_list = ['Royal Canin', 'Whiskas', 'Pro Plan', 'Kitchen Flavor', 'Me-O'];

if (!in_array($brand, $brand_list, true)) {
    $brand = 'Royal Canin';
}

/*
|--------------------------------------------------------------------------
| FILTER BRAND
|--------------------------------------------------------------------------
*/
$hasil = array_values(array_filter($produk, function ($item) use ($brand) {
    return strtolower($item['brand']) === strtolower($brand);
}));

/*
|--------------------------------------------------------------------------
| FILTER HARGA
|--------------------------------------------------------------------------
*/
if ($min_price > 0) {
    $hasil = array_values(array_filter($hasil, function ($item) use ($min_price) {
        return $item['harga'] >= $min_price;
    }));
}

if ($max_price > 0) {
    $hasil = array_values(array_filter($hasil, function ($item) use ($max_price) {
        return $item['harga'] <= $max_price;
    }));
}

/*
|--------------------------------------------------------------------------
| SORTING
|--------------------------------------------------------------------------
*/
if ($sort === 'termurah') {
    usort($hasil, function ($a, $b) {
        return $a['harga'] <=> $b['harga'];
    });
} elseif ($sort === 'termahal') {
    usort($hasil, function ($a, $b) {
        return $b['harga'] <=> $a['harga'];
    });
} elseif ($sort === 'nama') {
    usort($hasil, function ($a, $b) {
        return strcasecmp($a['nama'], $b['nama']);
    });
}

$total_produk = count($hasil);
$total_halaman = max(1, (int)ceil($total_produk / $per_page));
$page = min($page, $total_halaman);

$offset = ($page - 1) * $per_page;
$produk_tampil = array_slice($hasil, $offset, $per_page);

$mulai = $total_produk > 0 ? $offset + 1 : 0;
$selesai = min($offset + $per_page, $total_produk);

$brand_deskripsi = [
    'Royal Canin' => 'Pilihan makanan kucing Royal Canin untuk berbagai kebutuhan dan tahap usia.',
    'Whiskas' => 'Beragam makanan dan snack Whiskas untuk kucing kesayangan.',
    'Pro Plan' => 'Produk Pro Plan khusus kucing, termasuk makanan harian dan kebutuhan khusus.',
    'Kitchen Flavor' => 'Makanan basah dan kering Kitchen Flavor untuk kucing dengan berbagai pilihan rasa.',
    'Me-O' => 'Pilihan makanan Me-O untuk kucing dewasa dan kitten.'
];

function rupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

function url_page($brand, $sort, $min_price, $max_price, $page) {
    return 'makanan_kucing.php?' . http_build_query([
        'brand' => $brand,
        'sort' => $sort,
        'min_price' => $min_price,
        'max_price' => $max_price,
        'page' => $page
    ]);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($brand); ?> - Cat Shop</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #fff;
            color: #222;
        }

        a {
            text-decoration: none;
        }

        .topbar {
            background: #111;
            color: #fff;
            font-size: 13px;
            padding: 8px 0;
        }

        .main-header {
            background: #fff;
            border-bottom: 1px solid #eee;
            padding: 20px 0;
        }

        .logo {
            font-size: 30px;
            font-weight: 800;
            letter-spacing: 2px;
            color: #111;
        }

        .header-icon {
            color: #111;
            font-size: 20px;
            margin-left: 18px;
        }

        .navbar-cat {
            background: #fff;
            border-bottom: 1px solid #eee;
        }

        .navbar-cat .nav-link {
            color: #111;
            font-size: 13px;
            font-weight: 700;
            padding: 15px 12px;
        }

        .breadcrumb-area {
            background: #f7f7f7;
            padding: 18px 0;
            margin-bottom: 35px;
        }

        .breadcrumb {
            margin: 0;
            font-size: 14px;
        }

        .page-title {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .brand-description {
            color: #777;
            line-height: 1.7;
            max-width: 760px;
        }

        .brand-banner {
            height: 190px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            padding: 35px;
            margin: 25px 0;
            background: linear-gradient(135deg, #111, #444);
            color: #fff;
            overflow: hidden;
        }

        .brand-banner h2 {
            font-size: 42px;
            font-weight: 800;
            margin: 0;
        }

        .brand-banner p {
            margin: 8px 0 0;
            opacity: .85;
        }

        .sidebar-box {
            border: 1px solid #e5e5e5;
            padding: 22px;
            margin-bottom: 20px;
            border-radius: 5px;
            background: #fff;
        }

        .sidebar-title {
            font-weight: 800;
            font-size: 17px;
            margin-bottom: 16px;
        }

        .category-list,
        .brand-list,
        .tag-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .category-list li,
        .brand-list li {
            border-bottom: 1px solid #eee;
            padding: 9px 0;
        }

        .category-list a,
        .brand-list a {
            color: #555;
            font-size: 14px;
        }

        .brand-list a.active {
            color: #111;
            font-weight: 800;
        }

        .tag-list {
            display: flex;
            flex-wrap: wrap;
            gap: 7px;
        }

        .tag-list a {
            border: 1px solid #ddd;
            padding: 6px 10px;
            color: #555;
            font-size: 12px;
            border-radius: 3px;
        }

        .toolbar {
            border-bottom: 1px solid #eee;
            padding-bottom: 18px;
            margin-bottom: 22px;
        }

        .product-count {
            color: #777;
            font-size: 14px;
        }

        .sort-select {
            width: 210px;
        }

        .product-card {
            position: relative;
            border: 1px solid #eee;
            background: #fff;
            height: 100%;
            transition: .2s;
        }

        .product-card:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, .08);
            transform: translateY(-2px);
        }

        .product-image {
            height: 220px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fafafa;
            position: relative;
            padding: 15px;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .product-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background: #dc3545;
            color: #fff;
            font-size: 11px;
            padding: 5px 8px;
            z-index: 2;
            border-radius: 2px;
        }

        .product-info {
            padding: 15px;
        }

        .product-brand {
            color: #888;
            font-size: 12px;
            margin-bottom: 5px;
        }

        .product-name {
            color: #222;
            font-size: 15px;
            font-weight: 700;
            line-height: 1.45;
            min-height: 44px;
        }

        .product-weight {
            color: #888;
            font-size: 12px;
            margin: 7px 0;
        }

        .product-price {
            color: #111;
            font-weight: 800;
            font-size: 17px;
        }

        .btn-product {
            display: block;
            text-align: center;
            background: #111;
            color: #fff;
            padding: 10px;
            margin-top: 13px;
            font-size: 13px;
            font-weight: 700;
            border-radius: 3px;
        }

        .btn-product:hover {
            background: #333;
            color: #fff;
        }

        .pagination .page-link {
            color: #111;
        }

        .pagination .active .page-link {
            background: #111;
            border-color: #111;
            color: #fff;
        }

        .footer {
            background: #111;
            color: #ddd;
            margin-top: 70px;
            padding: 55px 0 25px;
        }

        .footer h5 {
            color: #fff;
            font-weight: 800;
            margin-bottom: 18px;
        }

        .footer a {
            color: #bbb;
        }

        .footer a:hover {
            color: #fff;
        }

        .footer ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer li {
            margin-bottom: 9px;
            font-size: 14px;
        }

        @media (max-width: 991px) {
            .navbar-cat .nav-link {
                padding: 9px 5px;
            }

            .brand-banner h2 {
                font-size: 32px;
            }
        }

        @media (max-width: 767px) {
            .page-title {
                font-size: 28px;
            }

            .brand-banner {
                height: 150px;
                padding: 25px;
            }

            .brand-banner h2 {
                font-size: 28px;
            }

            .product-image {
                height: 180px;
            }

            .sort-select {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<!-- TOPBAR -->
<div class="topbar">
    <div class="container d-flex justify-content-between">
        <span>CAT SHOP - Pusat Kebutuhan Kucing</span>
        <span><i class="bi bi-whatsapp"></i> 0857-1932-3258</span>
    </div>
</div>

<!-- HEADER -->
<header class="main-header">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="index.php" class="logo">CAT SHOP</a>

        <div>
            <a href="akun.php" class="header-icon" title="Akun">
                <i class="bi bi-person"></i>
            </a>
            <a href="wishlist.php" class="header-icon" title="Wishlist">
                <i class="bi bi-heart"></i>
            </a>
            <a href="keranjang.php" class="header-icon" title="Keranjang">
                <i class="bi bi-bag"></i>
            </a>
        </div>
    </div>
</header>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-cat">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#catNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="catNavbar">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">HOME</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="shop.php">SHOP</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="makanan_kucing.php?brand=Royal%20Canin">BRAND</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="kucing.php">KUCING</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="grooming.php">GROOMING</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="klinik.php">KLINIK</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="hotel.php">HOTEL</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="blog.php">BLOG</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="toko_terdekat.php">TOKO TERDEKAT</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- BREADCRUMB -->
<div class="breadcrumb-area">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php" class="text-dark">Home Page</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="shop.php" class="text-dark">Brand</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <?php echo htmlspecialchars($brand); ?>
                </li>
            </ol>
        </nav>
    </div>
</div>

<!-- CONTENT -->
<main class="container mb-5">
    <div class="row g-4">

        <!-- SIDEBAR -->
        <aside class="col-lg-3">

            <div class="sidebar-box">
                <div class="sidebar-title">Kategori</div>

                <ul class="category-list">
                    <li><a href="makanan_kucing.php?brand=<?php echo urlencode($brand); ?>">Makanan Kucing</a></li>
                    <li><a href="perlengkapan_kucing.php">Pasir & Toilet</a></li>
                    <li><a href="perlengkapan_kucing.php">Mainan Kucing</a></li>
                    <li><a href="kesehatan_kucing.php">Vitamin & Kesehatan</a></li>
                    <li><a href="perlengkapan_kucing.php">Aksesoris Kucing</a></li>
                    <li><a href="grooming.php">Perawatan & Grooming</a></li>
                </ul>
            </div>

            <div class="sidebar-box">
                <div class="sidebar-title">Filter Harga</div>

                <form method="GET">
                    <input type="hidden" name="brand" value="<?php echo htmlspecialchars($brand); ?>">
                    <input type="hidden" name="sort" value="<?php echo htmlspecialchars($sort); ?>">

                    <label class="form-label small text-muted">Harga minimum</label>
                    <input
                        type="number"
                        name="min_price"
                        class="form-control mb-3"
                        placeholder="Rp 0"
                        value="<?php echo $min_price > 0 ? $min_price : ''; ?>"
                    >

                    <label class="form-label small text-muted">Harga maksimum</label>
                    <input
                        type="number"
                        name="max_price"
                        class="form-control mb-3"
                        placeholder="Rp 3.000.000"
                        value="<?php echo $max_price > 0 ? $max_price : ''; ?>"
                    >

                    <button class="btn btn-dark w-100" type="submit">
                        Terapkan Filter
                    </button>
                </form>
            </div>

            <div class="sidebar-box">
                <div class="sidebar-title">Brands</div>

                <ul class="brand-list">
                    <?php foreach ($brand_list as $b): ?>
                        <li>
                            <a
                                href="makanan_kucing.php?brand=<?php echo urlencode($b); ?>"
                                class="<?php echo strtolower($b) === strtolower($brand) ? 'active' : ''; ?>"
                            >
                                <?php echo htmlspecialchars($b); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="sidebar-box">
                <div class="sidebar-title">Tag Produk</div>

                <div class="tag-list">
                    <a href="#">Makanan Kucing</a>
                    <a href="#">Kitten</a>
                    <a href="#">Adult</a>
                    <a href="#">Wet Food</a>
                    <a href="#">Dry Food</a>
                    <a href="#">Premium</a>
                    <a href="#">Veterinary</a>
                </div>
            </div>

        </aside>

        <!-- PRODUK -->
        <section class="col-lg-9">

            <h1 class="page-title">
                <?php echo htmlspecialchars($brand); ?>
            </h1>

            <p class="brand-description">
                <?php echo htmlspecialchars($brand_deskripsi[$brand]); ?>
            </p>

            <div class="brand-banner">
                <div>
                    <div class="small text-uppercase mb-2">CAT SHOP • CAT FOOD</div>
                    <h2><?php echo htmlspecialchars($brand); ?></h2>
                    <p>Produk pilihan khusus untuk kebutuhan kucing.</p>
                </div>
            </div>

            <div class="toolbar d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div class="product-count">
                    <?php if ($total_produk > 0): ?>
                        Menampilkan <?php echo $mulai; ?>–<?php echo $selesai; ?>
                        dari <?php echo $total_produk; ?> produk
                    <?php else: ?>
                        Tidak ada produk yang sesuai filter.
                    <?php endif; ?>
                </div>

                <form method="GET">
                    <input type="hidden" name="brand" value="<?php echo htmlspecialchars($brand); ?>">
                    <input type="hidden" name="min_price" value="<?php echo $min_price; ?>">
                    <input type="hidden" name="max_price" value="<?php echo $max_price; ?>">

                    <select name="sort" class="form-select sort-select" onchange="this.form.submit()">
                        <option value="terbaru" <?php echo $sort === 'terbaru' ? 'selected' : ''; ?>>
                            Diurutkan: Terbaru
                        </option>
                        <option value="termurah" <?php echo $sort === 'termurah' ? 'selected' : ''; ?>>
                            Harga: Terendah
                        </option>
                        <option value="termahal" <?php echo $sort === 'termahal' ? 'selected' : ''; ?>>
                            Harga: Tertinggi
                        </option>
                        <option value="nama" <?php echo $sort === 'nama' ? 'selected' : ''; ?>>
                            Nama Produk
                        </option>
                    </select>
                </form>
            </div>

            <?php if ($total_produk > 0): ?>

                <div class="row g-4">

                    <?php foreach ($produk_tampil as $item): ?>

                        <div class="col-6 col-md-4">
                            <div class="product-card">

                                <?php if ($item['badge'] !== ''): ?>
                                    <span class="product-badge">
                                        <?php echo htmlspecialchars($item['badge']); ?>
                                    </span>
                                <?php endif; ?>

                                <div class="product-image">
                                    <img
                                        src="<?php echo htmlspecialchars($item['gambar']); ?>"
                                        alt="<?php echo htmlspecialchars($item['nama']); ?>"
                                    >
                                </div>

                                <div class="product-info">

                                    <div class="product-brand">
                                        <?php echo htmlspecialchars($item['brand']); ?>
                                    </div>

                                    <a
                                        href="produk.php?id=<?php echo urlencode($item['id']); ?>"
                                        class="product-name d-block"
                                    >
                                        <?php echo htmlspecialchars($item['nama']); ?>
                                    </a>

                                    <div class="product-weight">
                                        <?php echo htmlspecialchars($item['berat']); ?>
                                    </div>

                                    <div class="product-price">
                                        <?php echo rupiah($item['harga']); ?>
                                    </div>

                                    <a
<a href="produk.php?id=<?php echo $item['id']; ?>" class="btn-product">
    Lihat Produk
</a>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; ?>

                </div>

                <!-- PAGINATION -->
                <?php if ($total_halaman > 1): ?>
                    <nav class="mt-5">
                        <ul class="pagination justify-content-center">

                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a
                                        class="page-link"
                                        href="<?php echo htmlspecialchars(url_page($brand, $sort, $min_price, $max_price, $page - 1)); ?>"
                                    >
                                        &laquo;
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php for ($i = 1; $i <= $total_halaman; $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a
                                        class="page-link"
                                        href="<?php echo htmlspecialchars(url_page($brand, $sort, $min_price, $max_price, $i)); ?>"
                                    >
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $total_halaman): ?>
                                <li class="page-item">
                                    <a
                                        class="page-link"
                                        href="<?php echo htmlspecialchars(url_page($brand, $sort, $min_price, $max_price, $page + 1)); ?>"
                                    >
                                        &raquo;
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </nav>
                <?php endif; ?>

            <?php else: ?>

                <div class="text-center py-5 border rounded">
                    <i class="bi bi-box-seam fs-1 text-muted"></i>
                    <h5 class="mt-3">Produk tidak ditemukan</h5>
                    <p class="text-muted">
                        Coba ubah filter harga atau pilih brand lain.
                    </p>
                </div>

            <?php endif; ?>

        </section>
    </div>
</main>

<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <div class="row g-4">

            <div class="col-md-4">
                <h5>CAT SHOP</h5>
                <p>
                    Pusat kebutuhan kucing untuk makanan, kesehatan,
                    perlengkapan, grooming, dan kebutuhan lainnya.
                </p>
            </div>

            <div class="col-md-2">
                <h5>CAT SHOP</h5>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="shop.php">Shop</a></li>
                    <li><a href="our_story.php">Our Story</a></li>
                    <li><a href="blog.php">Blog</a></li>
                </ul>
            </div>

            <div class="col-md-3">
                <h5>BRAND</h5>
                <ul>
                    <?php foreach ($brand_list as $b): ?>
                        <li>
                            <a href="makanan_kucing.php?brand=<?php echo urlencode($b); ?>">
                                <?php echo htmlspecialchars($b); ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="col-md-3">
                <h5>HUBUNGI KAMI</h5>
                <ul>
                    <li>
                        <i class="bi bi-whatsapp me-2"></i>
                        0857-1932-3258
                    </li>
                    <li>
                        <i class="bi bi-envelope me-2"></i>
                        info@catshop.com
                    </li>
                </ul>
            </div>

        </div>

        <hr class="my-4">

        <div class="text-center small">
            © <?php echo date('Y'); ?> Cat Shop. All Rights Reserved.
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
