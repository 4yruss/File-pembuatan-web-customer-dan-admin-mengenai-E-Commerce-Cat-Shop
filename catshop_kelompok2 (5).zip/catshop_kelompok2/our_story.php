<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Our Story - Cat Shop</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,Helvetica,sans-serif;color:#222;background:#fff}.topbar{height:36px;border-bottom:1px solid #ddd;font-size:12px;color:#666}.topbar a{color:#666;text-decoration:none}.main-header{min-height:145px;border-bottom:1px solid #ddd}.cat-logo{text-decoration:none}.cat-logo-title{font-size:31px;font-weight:800;letter-spacing:-1.5px;color:#16bde8}.cat-logo-subtitle{font-size:10px;color:#777}.search-wrap{height:40px}.search-wrap input{border:0;background:#f2f2f2;border-radius:24px 0 0 24px;padding-left:18px}.search-wrap button{width:50px;border:0;background:#16bde8;color:#fff;border-radius:0 24px 24px 0}.header-icons{display:flex;justify-content:flex-end;gap:21px}.header-icon{position:relative;color:#111;font-size:21px;text-decoration:none}.badge-count{position:absolute;top:-10px;right:-10px;background:#16bde8;color:#fff;border-radius:20px;font-size:9px;padding:2px 5px}.nav-wrap{height:42px;border-bottom:1px solid #ddd}.main-nav{height:100%;display:flex;align-items:center;justify-content:space-between}.nav-left{display:flex;gap:25px;height:100%;align-items:center}.nav-left a,.wa{font-size:12px;font-weight:700;color:#111;text-decoration:none;white-space:nowrap}.nav-dropdown{height:100%;position:relative;display:flex;align-items:center}.nav-dropdown>a:after{content:'\f282';font-family:'bootstrap-icons';font-size:9px;margin-left:5px}.dropdown-box{display:none;position:absolute;top:41px;left:-12px;background:#fff;min-width:220px;padding:10px 0;border:1px solid #eee;box-shadow:0 5px 18px rgba(0,0,0,.12);z-index:50}.nav-dropdown:hover .dropdown-box{display:block}.dropdown-box a{display:block;padding:9px 16px;font-size:13px;font-weight:400;color:#666}.dropdown-box a:hover{background:#f7f7f7;color:#16bde8}
.hero{height:380px;background:linear-gradient(90deg,rgba(0,0,0,.57),rgba(0,0,0,.15)),url('https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1800&q=85') center/cover;display:flex;align-items:center}.hero-content{color:#fff;max-width:650px}.hero-content small{letter-spacing:2px;font-weight:700}.hero h1{font-size:48px;font-weight:800;margin:10px 0}.hero p{font-size:17px;line-height:1.7}.section{padding:75px 0}.eyebrow{color:#16bde8;font-size:12px;font-weight:800;letter-spacing:2px;text-transform:uppercase}.section h2{font-size:32px;font-weight:800}.story-img{width:100%;height:430px;object-fit:cover}.story-text{line-height:1.8;color:#666}.vision-card{height:100%;padding:35px;border:1px solid #e8e8e8;background:#fff}.vision-card i{font-size:36px;color:#16bde8}.number{font-size:40px;font-weight:800;color:#16bde8}.stat-section{background:#f7f7f7}.service{padding:30px 20px;text-align:center}.service i{font-size:42px;color:#16bde8}.service h5{font-weight:800;margin-top:18px}.service p{color:#777;font-size:14px;line-height:1.7}.cta{background:#16bde8;color:#fff;padding:60px 0}.cta h2{font-weight:800}.footer{padding:55px 0 25px;border-top:1px solid #eee;color:#666;font-size:13px}.footer h6{font-weight:800;color:#222}.footer ul{list-style:none;padding:0}.footer li{margin-bottom:9px}.footer a{color:#666;text-decoration:none}@media(max-width:991px){.main-nav{overflow:auto}.nav-left{gap:15px}.hero{height:330px}.hero h1{font-size:38px}}@media(max-width:767px){.main-header{padding:20px 0}.hero{height:420px}.hero h1{font-size:34px}.story-img{height:300px}}
</style>
</head>
<body>

<!-- TOPBAR -->
<div class="topbar d-flex align-items-center">
 <div class="container d-flex justify-content-between">
  <div><a href="#"><i class="bi bi-geo-alt me-1"></i>Lokasi Toko Terdekat</a><span class="mx-3"><i class="bi bi-truck me-1"></i>Order Tracking</span></div>
  <div class="fw-bold">JOIN OUR FRANCHISE!</div>
 </div>
</div>

<!-- HEADER -->
<header class="main-header d-flex align-items-center">
 <div class="container">
  <div class="row align-items-center">
   <div class="col-lg-4 col-md-3 mb-3 mb-md-0">
    <a href="index.php" class="cat-logo"><div class="cat-logo-title">CAT SHOP</div><div class="cat-logo-subtitle">Pusat Kebutuhan Kucing Terlengkap</div></a>
   </div>
   <div class="col-lg-6 col-md-6 mb-3 mb-md-0">
    <form class="search-wrap d-flex"><input class="form-control" type="search" placeholder="Search products..."><button><i class="bi bi-search"></i></button></form>
   </div>
   <div class="col-lg-2 col-md-3"><div class="header-icons">
    <a class="header-icon" href="#"><i class="bi bi-person"></i></a>
    <a class="header-icon" href="#"><i class="bi bi-heart"></i><span class="badge-count">1</span></a>
    <a class="header-icon" href="#"><i class="bi bi-cart3"></i><span class="badge-count">2</span></a>
   </div></div>
  </div>
 </div>
</header>

<!-- NAVBAR -->
<div class="nav-wrap">
 <div class="container h-100"><div class="main-nav">
  <div class="nav-left">
   <div class="nav-dropdown"><a href="#">TENTANG CAT SHOP</a><div class="dropdown-box"><a href="our_story.php">Our Story</a><a href="#">Our Channel</a><a href="#">Our Leaders</a><a href="#">Our Veterinarian</a></div></div>
   <div class="nav-dropdown"><a href="#">BRAND</a><div class="dropdown-box"><a href="#">Royal Canin</a><a href="#">Whiskas</a><a href="#">Pro Plan</a><a href="#">Me-O</a><a href="#">Kitchen Flavor</a></div></div>
   <div class="nav-dropdown"><a href="#">KEPERLUAN KUCING</a><div class="dropdown-box"><a href="#">Makanan Kucing</a><a href="#">Pasir & Toilet</a><a href="#">Mainan Kucing</a><a href="#">Vitamin & Kesehatan</a><a href="#">Aksesoris Kucing</a></div></div>
   <div class="nav-dropdown"><a href="#">LAYANAN</a><div class="dropdown-box"><a href="#">Grooming Kucing</a><a href="#">Klinik Kucing</a><a href="#">Pet Hotel Kucing</a></div></div>
   <a href="#">BLOG</a><a href="#">TOKO TERDEKAT</a><a href="#">LINK</a><a href="#">KARIR</a>
  </div><div class="wa"><i class="bi bi-whatsapp"></i> WhatsApp: <span style="color:#08aee0">0857-1932-3258</span></div>
 </div></div>
</div>

<!-- HERO OUR STORY -->
<section class="hero"><div class="container"><div class="hero-content"><small>CAT SHOP</small><h1>Our Story</h1><p>Cerita kami dalam menghadirkan kebutuhan terbaik untuk kucing dan membantu setiap pemilik kucing memberikan kehidupan yang nyaman, sehat, dan bahagia.</p></div></div></section>

<!-- STORY -->
<section class="section"><div class="container"><div class="row align-items-center g-5">
 <div class="col-lg-6"><img class="story-img" src="https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop&w=1000&q=85" alt="Kucing Cat Shop"></div>
 <div class="col-lg-6"><div class="eyebrow">Tentang Cat Shop</div><h2 class="mt-2 mb-4">Tempat untuk Semua Kebutuhan Kucing</h2><p class="story-text">Cat Shop hadir dari kecintaan terhadap kucing dan keinginan untuk menyediakan tempat yang mudah bagi para cat lovers untuk mendapatkan kebutuhan kucing dalam satu tempat.</p><p class="story-text">Kami berfokus pada produk dan layanan untuk kucing, mulai dari makanan, pasir, mainan, aksesoris, perawatan, hingga kebutuhan kesehatan. Setiap produk dipilih dengan memperhatikan kebutuhan dan kenyamanan kucing.</p><p class="story-text">Bagi kami, kucing bukan hanya hewan peliharaan. Kucing adalah bagian dari keluarga. Karena itu, Cat Shop berusaha memberikan pengalaman belanja yang nyaman sekaligus membantu pemilik kucing merawat sahabat berbulu mereka dengan lebih baik.</p></div>
</div></div></section>

<!-- VISI MISI -->
<section class="section bg-light"><div class="container"><div class="text-center mb-5"><div class="eyebrow">Nilai Kami</div><h2>Visi & Misi Cat Shop</h2></div><div class="row g-4">
 <div class="col-md-6"><div class="vision-card"><i class="bi bi-eye"></i><h3 class="mt-3 fw-bold">Visi</h3><p class="story-text mb-0">Menjadi pilihan terpercaya bagi para pemilik kucing dalam memenuhi kebutuhan kucing yang sehat, nyaman, dan bahagia.</p></div></div>
 <div class="col-md-6"><div class="vision-card"><i class="bi bi-heart"></i><h3 class="mt-3 fw-bold">Misi</h3><p class="story-text mb-0">Menyediakan produk kucing yang beragam dan berkualitas, memberikan layanan yang ramah, serta membantu cat lovers mendapatkan informasi dan kebutuhan kucing dengan mudah.</p></div></div>
</div></div></section>

<!-- STATS -->
<section class="section stat-section"><div class="container"><div class="row text-center g-4">
 <div class="col-6 col-md-3"><div class="number">100+</div><div>Produk Kucing</div></div>
 <div class="col-6 col-md-3"><div class="number">50+</div><div>Brand Pilihan</div></div>
 <div class="col-6 col-md-3"><div class="number">24/7</div><div>Untuk Cat Lovers</div></div>
 <div class="col-6 col-md-3"><div class="number">100%</div><div>Fokus Kucing</div></div>
</div></div></section>

<!-- SERVICES -->
<section class="section"><div class="container"><div class="text-center mb-5"><div class="eyebrow">Apa yang Kami Sediakan</div><h2>Layanan untuk Kucing</h2></div><div class="row g-3">
 <div class="col-md-3"><div class="service"><i class="bi bi-bag-heart"></i><h5>Cat Shop</h5><p>Kebutuhan harian kucing dari makanan sampai aksesoris.</p></div></div>
 <div class="col-md-3"><div class="service"><i class="bi bi-scissors"></i><h5>Grooming</h5><p>Perawatan bulu dan kebersihan kucing agar tetap nyaman.</p></div></div>
 <div class="col-md-3"><div class="service"><i class="bi bi-heart-pulse"></i><h5>Kesehatan</h5><p>Kebutuhan kesehatan dan perawatan untuk kucing kesayangan.</p></div></div>
 <div class="col-md-3"><div class="service"><i class="bi bi-house-heart"></i><h5>Cat Hotel</h5><p>Tempat nyaman untuk kucing ketika pemilik sedang bepergian.</p></div></div>
</div></div></section>

<!-- CTA -->
<section class="cta"><div class="container text-center"><h2>Karena Setiap Kucing Layak Mendapatkan yang Terbaik</h2><p class="mb-4">Temukan kebutuhan kucing kesayanganmu di Cat Shop.</p><a href="index.php" class="btn btn-light px-4 py-2 fw-bold">Belanja Sekarang</a></div></section>

<!-- FOOTER -->
<footer class="footer"><div class="container"><div class="row g-4">
 <div class="col-md-4"><div class="cat-logo-title">CAT SHOP</div><p class="mt-2">Pusat kebutuhan kucing terlengkap untuk cat lovers Indonesia.</p><div><a href="#" class="me-3"><i class="bi bi-instagram"></i></a><a href="#" class="me-3"><i class="bi bi-facebook"></i></a><a href="#"><i class="bi bi-tiktok"></i></a></div></div>
 <div class="col-md-2"><h6>CAT SHOP</h6><ul><li><a href="our_story.php">Our Story</a></li><li><a href="#">Brand</a></li><li><a href="#">Blog</a></li><li><a href="#">Karir</a></li></ul></div>
 <div class="col-md-3"><h6>KEPERLUAN KUCING</h6><ul><li>Makanan Kucing</li><li>Pasir & Toilet</li><li>Mainan</li><li>Aksesoris</li></ul></div>
 <div class="col-md-3"><h6>HUBUNGI KAMI</h6><ul><li><i class="bi bi-whatsapp me-2"></i>0857-1932-3258</li><li><i class="bi bi-envelope me-2"></i>info@catshop.com</li></ul></div>
 </div><hr class="my-4"><div class="text-center">© <?php echo date('Y'); ?> Cat Shop. All Rights Reserved.</div></div></footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
