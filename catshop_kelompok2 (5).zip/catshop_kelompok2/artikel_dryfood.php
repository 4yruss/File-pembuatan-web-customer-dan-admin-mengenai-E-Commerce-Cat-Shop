<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dry Food vs Wet Food - Cat Shop</title>
    <!-- Pastikan file CSS Bootstrap dan Font kamu sudah dilink di sini, mirip dengan di index.php -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-white">

    <!-- BAGIAN 1: COPY NAVBAR/MENU DARI index.php KE SINI -->
    <!-- (Kamu bisa copas bagian header web kamu ke sini agar menunya tetap ada) -->

    <div class="container mt-5 mb-5 pt-4">
        <div class="row justify-content-center">
            <!-- Kita pakai col-lg-8 agar artikelnya berada di tengah dan tidak terlalu lebar -->
            <div class="col-lg-8">
                
                <!-- Kategori & Tanggal -->
                <div class="mb-3">
                    <span class="badge bg-info text-dark">Kucing</span>
                    <span class="badge bg-info text-dark ms-1">Nutrition</span>
                    <small class="text-muted ms-3"><i class="bi bi-calendar"></i> 19 Agustus 2026</small>
                </div>

                <!-- Judul Artikel -->
                <h1 class="fw-bold mb-4">Dry Food vs Wet Food: Lebih Baik Mana untuk Kucing Kesayangan?</h1>

                <!-- Gambar Utama Artikel -->
                <img src="https://placehold.co/800x400/f1f5f9/333?text=Dry+Food+vs+Wet+Food" class="img-fluid rounded mb-4 w-100 object-fit-cover" alt="Dry Food vs Wet Food">

                <!-- Isi Konten Artikel -->
                <div class="article-content" style="font-size: 16px; line-height: 1.8; color: #444;">
                    
                    <h5 class="fw-bold text-dark">Jawaban Singkat:</h5>
                    <p>Tidak ada yang mutlak lebih baik antara dry food dan wet food. Baik dry food maupun wet food memiliki kelebihan dan kekurangan masing-masing. Dry food cocok sebagai makanan harian karena lebih praktis, sedangkan wet food baik untuk menambah asupan cairan.</p>

                    <h5 class="fw-bold text-dark mt-4">Lalu, sebenarnya mana yang paling tepat untuk kucing kesayangan?</h5>
                    <p>Jawabannya sangat bergantung pada kondisi kucingmu, seperti usia, kondisi kesehatan, tingkat aktivitas, dan lain-lain. Jika kamu masih ragu menentukan pilihan, konsultasikan dengan dokter hewan agar mendapatkan rekomendasi yang sesuai.</p>

                    <!-- Gambar Sisipan (Contoh kucing makan dry food) -->
                    <img src="https://placehold.co/800x400/f1f5f9/333?text=Gambar+Kucing+Makan+Dry+Food" class="img-fluid rounded mb-3 mt-3 w-100" alt="Kucing makan dry food">

                    <h5 class="fw-bold text-dark mt-4">Apa itu Dry Food?</h5>
                    <p>Dry food atau makanan kering adalah jenis makanan kucing yang memiliki kandungan air sangat rendah (biasanya sekitar 10%). Makanan ini diproses dengan cara diekstrusi, yaitu dicampur, dimasak dengan tekanan dan suhu tinggi, lalu dicetak menjadi biskuit kecil (kibble).</p>

                    <hr class="my-5">

                    <!-- Bagian FAQ -->
                    <h4 class="fw-bold mb-3">FAQ</h4>
                    <div class="mb-3">
                        <h6 class="fw-bold text-dark">Apakah dry food lebih baik daripada wet food?</h6>
                        <p class="text-muted">Tidak ada yang secara mutlak lebih baik. Pilihan yang paling tepat bergantung pada usia, kondisi kesehatan, kebutuhan nutrisi, serta kebiasaan makan setiap kucing.</p>
                    </div>
                    <div class="mb-3">
                        <h6 class="fw-bold text-dark">Apakah dry food dan wet food boleh dicampur dalam satu mangkuk?</h6>
                        <p class="text-muted">Boleh. Banyak pemilik kucing yang mengkombinasikan keduanya sebagai variasi menu harian. Yang terpenting adalah memastikan total porsi makan tetap sesuai dengan kebutuhan nutrisi kucing.</p>
                    </div>

                </div>

                <!-- Tombol Kembali ke index.php -->
                <div class="mt-5 border-top pt-4">
                    <a href="index.php" class="btn btn-primary rounded-pill px-4"><i class="bi bi-arrow-left"></i> Kembali ke Beranda</a>
                </div>

            </div>
        </div>
    </div>

    <!-- BAGIAN 2: COPY FOOTER DARI index.php KE SINI -->
    <!-- (Copas bagian bawah web (copyright dll) ke sini) -->

</body>
</html>