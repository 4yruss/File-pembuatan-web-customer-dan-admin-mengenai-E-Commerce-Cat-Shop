<?php
include 'koneksi.php';

$id = $_GET['id'];

// Menghapus data berdasarkan id_keranjang
mysqli_query($koneksi, "DELETE FROM keranjang WHERE id_keranjang = '$id'");

// Mengarahkan kembali ke halaman keranjang
header("Location: keranjang.php");
exit();
?>