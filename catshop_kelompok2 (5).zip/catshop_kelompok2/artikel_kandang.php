<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tips Membuat Kucing Nyaman di Kandang - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-white">

    <!-- BAGIAN 1: COPY NAVBAR/MENU DARI index.php KE SINI -->

    <div class="container mt-5 mb-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <!-- Kategori & Tanggal -->
                <div class="mb-3">
                    <span class="badge bg-info text-dark">Kucing</span>
                    <small class="text-muted ms-3"><i class="bi bi-calendar"></i> 8 Maret 2026</small>
                </div>

                <!-- Judul Artikel -->
                <h1 class="fw-bold mb-4">Tips Membuat Kucing Nyaman di Kandang</h1>

                <!-- Gambar Utama Artikel -->
                <img src="https://placehold.co/800x400/f1f5f9/333?text=Kucing+di+Kandang" class="img-fluid rounded mb-4 w-100 object-fit-cover" alt="Kucing di kandang">

                <!-- Isi Konten Artikel -->
                <div class="article-content" style="font-size: 16px; line-height: 1.8; color: #444;">
                    
                    <p>Ada dua jenis pet parents di dunia ini. Pertama ialah pet parents yang suka membiarkan anabulnya untuk berkeliaran bebas di dalam rumah. Kedua adalah yang terbiasa menempatkan kucing di dalam kandang pada waktu-waktu tertentu untuk alasan keamanan atau pembiasaan.</p>

                    <h5 class="fw-bold text-dark mt-4">1. Pilih Ukuran Kandang yang Tepat</h5>
                    <p>Kandang harus cukup luas agar kucing bisa berdiri, berputar, dan meregangkan tubuhnya dengan nyaman. Jangan lupa sisakan ruang untuk tempat makan, minum, dan litter box (kotak pasir) jika kucing berada di dalam kandang untuk waktu yang agak lama.</p>

                    <h5 class="fw-bold text-dark mt-4">2. Sediakan Alas yang Nyaman</h5>
                    <p>Letakkan selimut lembut, handuk, atau tempat tidur khusus kucing di dalam kandang. Ini akan membuat mereka merasa lebih hangat dan aman. Kucing sangat menyukai tempat yang empuk dan tertutup untuk tidur.</p>

                    <!-- Gambar Sisipan -->
                    <img src="https://placehold.co/800x400/f1f5f9/333?text=Kandang+Kucing+Nyaman" class="img-fluid rounded mb-3 mt-3 w-100" alt="Kandang kucing yang nyaman">

                    <h5 class="fw-bold text-dark mt-4">3. Jaga Kebersihan Kandang</h5>
                    <p>Kucing adalah hewan yang sangat menjaga kebersihan. Pastikan kamu rutin membersihkan kandang, mencuci alas tidurnya, dan membersihkan litter box setiap hari agar kucing tidak stres akibat bau tidak sedap di area tempat tinggalnya.</p>

                </div>

                <!-- Tombol Kembali -->
                <div class="mt-5 border-top pt-4">
                    <a href="index.php" class="btn btn-primary rounded-pill px-4"><i class="bi bi-arrow-left"></i> Kembali ke Beranda</a>
                </div>

            </div>
        </div>
    </div>

    <!-- BAGIAN 2: COPY FOOTER DARI index.php KE SINI -->

</body>
</html>