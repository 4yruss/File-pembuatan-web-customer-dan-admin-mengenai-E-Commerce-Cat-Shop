<?php
session_start();
include 'koneksi.php';

// Ambil user_id dan hitung total wishlist dari database
$user_id = $_SESSION['user_id'] ?? 0;
$query_wishlist_jml = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM wishlist WHERE id_user = '$user_id'");
$data_wishlist_jml = mysqli_fetch_assoc($query_wishlist_jml);
$jumlah_wishlist = $data_wishlist_jml['total'] ?? 0;
$ambil = mysqli_query($koneksi, "SELECT * FROM wishlist JOIN produk ON wishlist.id_produk = produk.id WHERE wishlist.id_user = '$user_id'");
?>
<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Wishlist - Cat Shop</title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fa;
        }

        .logo {
            font-size: 28px;
            font-weight: 800;
            color: #111;
            text-decoration: none;
        }

        .header-icon {
            color: #111;
            text-decoration: none;
            font-size: 22px;
            margin-left: 20px;
            position: relative;
        }

        .badge-count {
            position: absolute;
            top: -9px;
            right: -10px;

            background: #111;
            color: #fff;

            border-radius: 20px;

            font-size: 10px;

            min-width: 16px;
            height: 16px;

            text-align: center;
        }

        .item {
            background: #fff;
            border: 1px solid #e5e5e5;
            border-radius: 10px;
            padding: 15px;
        }

        .item img {
            width: 90px;
            height: 90px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>

<body>

    <!-- =========================
         HEADER
    ========================== -->
<header class="bg-white border-bottom py-3">
    <div class="container d-flex justify-content-between align-items-center">
        <!-- Logo -->
        <div>
            <a href="index.php" class="logo text-decoration-none fw-bold fs-4 text-dark">CAT SHOP</a>
        </div>

        <!-- Header Icons -->
        <div>
            <!-- Akun -->
            <a href="akun.php" class="header-icon me-3">
                <i class="bi bi-person"></i>
            </a>

            <!-- Wishlist -->
            <a href="wishlist.php" class="header-icon me-3">
                <i class="bi bi-heart-fill"></i>
                <span class="badge-count">
                    <?php echo $jumlah_wishlist; ?>
                </span>
            </a>

            <!-- Keranjang -->
            <a href="keranjang.php" class="header-icon">
                <i class="bi bi-cart3"></i>
                <span class="badge-count">
                    <?php echo $jumlah_keranjang; ?>
                </span>
            </a>
        </div>
    </div>
</header>


    <!-- =========================
         MAIN CONTENT
    ========================== -->
    <main class="container py-5">

        <h2 class="fw-bold">
            Wishlist Saya
        </h2>

        <p class="text-muted">
            Produk yang kamu simpan dengan ikon love akan muncul di sini.
        </p>


<!-- Wishlist List -->
            <div class="row g-3 mt-2">
                <?php 
                $ambil = mysqli_query($koneksi, "SELECT * FROM wishlist JOIN produk ON wishlist.id_produk = produk.id WHERE wishlist.id_user = '$user_id'");
                while ($pecah = mysqli_fetch_assoc($ambil)) { 
                ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <img src="<?php echo $pecah['gambar']; ?>" class="card-img-top" alt="Produk" style="height: 200px; object-fit: cover;">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $pecah['nama']; ?></h5>
                                <p class="card-text text-primary fw-bold">Rp <?php echo number_format($pecah['harga'], 0, ',', '.'); ?></p>
                                <a href="produk.php?id=<?php echo $pecah['id_produk']; ?>" class="btn btn-dark btn-sm">Lihat Produk</a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
    </main>


    <!-- =========================
         JAVASCRIPT
    ========================== -->
    <script>

        // Ambil data wishlist dari localStorage
        const wishlist = JSON.parse(
            localStorage.getItem('catshop_wishlist') || '[]'
        );


        // Ambil data keranjang dari localStorage
        const cart = JSON.parse(
            localStorage.getItem('catshop_cart') || '[]'
        );


        // =========================
        // UPDATE JUMLAH WISHLIST
        // =========================

        document.getElementById('wishCount').textContent =
            wishlist.length;


        // =========================
        // UPDATE JUMLAH KERANJANG
        // =========================

        document.getElementById('cartCount').textContent =
            cart.reduce(
                (total, item) => total + (item.qty || 1),
                0
            );


        // =========================
        // TAMPILKAN WISHLIST
        // =========================

        const list = document.getElementById('list');


        // Jika wishlist kosong
        if (wishlist.length === 0) {

            list.innerHTML = `
                <div class="col-12">

                    <div class="alert alert-light border">
                        Wishlist masih kosong.
                        Silakan pilih produk lalu klik ikon love.
                    </div>

                </div>
            `;

        }


        // =========================
        // LOOP PRODUK WISHLIST
        // =========================

        wishlist.forEach((product, index) => {

            list.innerHTML += `
                <div class="col-md-6">

                    <div class="item d-flex gap-3 align-items-center">

                        <!-- Gambar Produk -->
                        <img
                            src="${product.image}"
                            alt="${product.name}"
                        >


                        <!-- Informasi Produk -->
                        <div class="flex-grow-1">

                            <h6 class="fw-bold mb-1">
                                ${product.name}
                            </h6>

                            <div>
                                Rp ${Number(product.price).toLocaleString('id-ID')}
                            </div>


                            <!-- Tombol Hapus -->
                            <button
                                class="btn btn-sm btn-outline-danger mt-2"
                                onclick="removeWish(${index})"
                            >
                                Hapus
                            </button>

                        </div>

                    </div>

                </div>
            `;

        });


        // =========================
        // HAPUS PRODUK WISHLIST
        // =========================

        function removeWish(index) {

            wishlist.splice(index, 1);

            localStorage.setItem(
                'catshop_wishlist',
                JSON.stringify(wishlist)
            );

            location.reload();
        }

    </script>

</body>

</html>