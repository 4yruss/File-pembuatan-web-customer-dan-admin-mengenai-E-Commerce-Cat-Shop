<?php
session_start();
include 'koneksi.php';

// Jika belum login, alihkan ke halaman login
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location='akun.php';</script>";
    exit();
}

$id_user = $_SESSION['user_id'];

// Proses jika tombol checkout ditekan
if (isset($_POST['checkout'])) {
$nama_penerima = $_POST['nama_penerima'];
    $no_hp = $_POST['no_hp'];
    $alamat_lengkap = $_POST['alamat_lengkap'];
    $kurir = $_POST['kurir']; // <--- Tambahkan baris ini
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $total_belanja = $_POST['total_belanja'];

    // Simpan ke tabel pesanan
    $query = "INSERT INTO pesanan (id_user, nama_penerima, no_hp, alamat_lengkap, kurir, metode_pembayaran, total_belanja) VALUES ('$id_user', '$nama_penerima', '$no_hp', '$alamat_lengkap', '$kurir', '$metode_pembayaran', '$total_belanja')";
    $simpan = mysqli_query($koneksi, $query);

if ($simpan) {
        // Ambil ID pesanan yang baru saja dimasukkan
        $id_pesanan_baru = mysqli_insert_id($koneksi);
        
        // Hapus keranjang belanja user setelah checkout berhasil
        mysqli_query($koneksi, "DELETE FROM keranjang WHERE id_user = '$id_user'");
        
        // Alihkan langsung ke halaman nota dengan membawa id_pesanan
        echo "<script>alert('Checkout berhasil! Pesanan Anda sedang diproses.'); window.location='nota.php?id=$id_pesanan_baru';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container my-5">
        <h2 class="fw-bold mb-4">Checkout Pesanan</h2>
        
        <div class="row">
            <!-- Form Pengiriman & Pembayaran -->
            <div class="col-md-7">
                <div class="card shadow-sm p-4 mb-4">
                    <h5 class="fw-bold mb-3">Informasi Pengiriman & Pembayaran</h5>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nama Penerima</label>
                            <input type="text" name="nama_penerima" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nomor WhatsApp / HP</label>
                            <input type="text" name="no_hp" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alamat Lengkap</label>
                            <textarea name="alamat_lengkap" class="form-control" rows="3" required></textarea>
                            <div class="mb-3">
    <label class="form-label">Pilih Kurir Pengiriman</label>
    <select name="kurir" class="form-control" required>
        <option value="">-- Pilih Kurir Pengiriman --</option>
        <option value="J&T Express (Estimasi 2-3 Hari)">J&T Express (Estimasi 2-3 Hari)</option>
        <option value="JNE Reguler (Estimasi 2-3 Hari)">JNE Reguler (Estimasi 2-3 Hari)</option>
        <option value="Kurir Reguler (Gratis Ongkir)">Kurir Reguler Toko (Gratis)</option>
    </select>
</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Metode Pembayaran</label>
                            <select name="metode_pembayaran" class="form-control" required>
                                <option value="">-- Pilih Metode Pembayaran --</option>
                                <option value="Transfer Bank BCA">Transfer Bank (BCA)</option>
                                <option value="Transfer Bank Mandiri">Transfer Bank (Mandiri)</option>
                                <option value="COD (Cash on Delivery)">COD (Bayar di Tempat)</option>
                            </select>
                        </div>

                        <?php
                        // Hitung total belanja dari keranjang
                        $total = 0;
                        $ambil = mysqli_query($koneksi, "SELECT * FROM keranjang JOIN produk ON keranjang.id_produk = produk.id WHERE keranjang.id_user = '$id_user'");
                        while ($row = mysqli_fetch_assoc($ambil)) {
                            $subtotal = $row['harga'] * $row['jumlah'];
                            $total += $subtotal;
                        }
                        ?>
                        <input type="hidden" name="total_belanja" value="<?php echo $total; ?>">

                        <button type="submit" name="checkout" class="btn btn-dark w-100 py-2">Buat Pesanan Sekarang</button>
                    </form>
                </div>
            </div>

            <!-- Ringkasan Pesanan -->
            <div class="col-md-5">
                <div class="card shadow-sm p-4">
                    <h5 class="fw-bold mb-3">Ringkasan Belanja</h5>
                    <ul class="list-group mb-3">
                        <?php 
                        $ambil_cart = mysqli_query($koneksi, "SELECT * FROM keranjang JOIN produk ON keranjang.id_produk = produk.id WHERE keranjang.id_user = '$id_user'");
                        while ($item = mysqli_fetch_assoc($ambil_cart)) {
                            $sub = $item['harga'] * $item['jumlah'];
                        ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="my-0"><?php echo $item['nama']; ?></h6>
                                    <small class="text-muted">Jumlah: <?php echo $item['jumlah']; ?></small>
                                </div>
                                <span class="text-muted">Rp <?php echo number_format($sub, 0, ',', '.'); ?></span>
                            </li>
                        <?php } ?>
                        <li class="list-group-item d-flex justify-content-between bg-light">
                            <span class="fw-bold">Total Pembayaran</span>
                            <strong class="text-primary">Rp <?php echo number_format($total, 0, ',', '.'); ?></strong>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</body>
</html>