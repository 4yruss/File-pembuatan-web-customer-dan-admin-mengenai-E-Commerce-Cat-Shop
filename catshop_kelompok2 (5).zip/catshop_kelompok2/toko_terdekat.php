<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Toko Terdekat - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { font-family: Arial, Helvetica, sans-serif; color: #222; }
        .topbar { height: 36px; border-bottom: 1px solid #ddd; font-size: 12px; color: #666; }
        .topbar a { color: #666; text-decoration: none; }
        .header { min-height: 145px; border-bottom: 1px solid #ddd; display:flex; align-items:center; }
        .logo { text-decoration:none; }
        .brand { font-size:31px; font-weight:800; color:#16bde8; }
        .tag { font-size:10px; color:#777; }
        .search { height:40px; background:#f2f2f2; border:0; border-radius:24px; padding-left:18px; width:100%; }
        .icons { font-size:21px; display:flex; gap:20px; justify-content:end; }
        .icons a { color:#111; }
        .nav-wrap { border-bottom:1px solid #ddd; min-height:45px; }
        .nav { min-height:45px; display:flex; align-items:center; gap:25px; overflow:auto; }
        .nav a { font-size:12px; font-weight:700; color:#111; text-decoration:none; white-space:nowrap; }
        .nav a:hover { color:#16bde8; }
        .hero { min-height:320px; background:linear-gradient(90deg,rgba(0,0,0,.65),rgba(0,0,0,.2)), url('https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1800&q=85') center/cover; display:flex; align-items:center; color:#fff; }
        .hero h1 { font-size:46px; font-weight:800; }
        .content { padding:65px 0; }
        .box { border:1px solid #eee; padding:30px; height:100%; box-shadow:0 3px 12px rgba(0,0,0,.06); }
        footer { border-top:1px solid #eee; padding:40px 0; color:#666; font-size:13px; }
        @media(max-width:767px) { .hero h1 { font-size:35px; } }
    </style>
</head>
<body>
    <div class="topbar d-flex align-items-center">
        <div class="container d-flex justify-content-between">
            <div><a href="index.php"><i class="bi bi-house me-1"></i>Cat Shop</a><span class="mx-3">Order Tracking</span></div>
            <b>CAT SHOP</b>
        </div>
    </div>

    <header class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <a href="index.php" class="logo">
                        <div class="brand">CAT SHOP</div>
                        <div class="tag">Pusat Kebutuhan Kucing Terlengkap</div>
                    </a>
                </div>
                <div class="col-md-6"><input class="search" placeholder="Search products..."></div>
                <div class="col-md-3"><div class="icons"><a href="#"><i class="bi bi-person"></i></a><a href="#"><i class="bi bi-heart"></i></a><a href="#"><i class="bi bi-cart3"></i></a></div></div>
            </div>
        </div>
    </header>

    <div class="nav-wrap">
        <div class="container">
            <nav class="nav">
                <a href="index.php">BERANDA</a>
                <a href="our_story.php">OUR STORY</a>
                <a href="our_channel.php">OUR CHANNEL</a>
                <a href="our_leaders.php">OUR LEADERS</a>
                <a href="our_veterinarian.php">OUR VETERINARIAN</a>
                <a href="brand.php">BRAND</a>
                <a href="blog.php">BLOG</a>
                <a href="toko_terdekat.php">TOKO TERDEKAT</a>
                <a href="link.php">LINK</a>
                <a href="karir.php">KARIR</a>
            </nav>
        </div>
    </div>

    <section class="hero">
        <div class="container">
            <small>CAT SHOP</small>
            <h1>Toko Terdekat</h1>
            <p class="lead">Informasi lokasi toko Cat Shop untuk Cat Lovers.</p>
        </div>
    </section>

    <section class="content">
        <div class="container">
            <div class="box">
                <h2>Toko Terdekat</h2>
                <p>Informasi lokasi toko Cat Shop untuk Cat Lovers.</p>
                <a href="index.php" class="btn btn-info text-white mt-3">Kembali ke Beranda</a>
            </div>
        </div>
    </section>

    <footer>
        <div class="container d-flex justify-content-between flex-wrap">
            <div><b class="text-dark">CAT SHOP</b><br>Pusat kebutuhan kucing terlengkap.</div>
            <div>WhatsApp: 0857-1932-3258</div>
            <div>Copyright © 2026 Cat Shop.</div>
        </div>
    </footer>
</body>
</html>
