<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cara Merawat Anak Kucing Baru Lahir - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-white">

    <!-- BAGIAN 1: COPY NAVBAR/MENU DARI index.php KE SINI -->

    <div class="container mt-5 mb-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <!-- Kategori & Tanggal -->
                <div class="mb-3">
                    <span class="badge bg-info text-dark">Kucing</span>
                    <small class="text-muted ms-3"><i class="bi bi-calendar"></i> 23 Oktober 2025</small>
                </div>

                <!-- Judul Artikel -->
                <h1 class="fw-bold mb-4">Cara Merawat Anak Kucing Baru Lahir: Panduan Lengkap dari 0-8 Minggu</h1>

                <!-- Gambar Utama Artikel -->
                <img src="https://placehold.co/800x400/f1f5f9/333?text=Anak+Kucing+Baru+Lahir" class="img-fluid rounded mb-4 w-100 object-fit-cover" alt="Anak Kucing Baru Lahir">

                <!-- Isi Konten Artikel -->
                <div class="article-content" style="font-size: 16px; line-height: 1.8; color: #444;">
                    
                    <p>Menemukan atau merawat anak kucing yang baru lahir memang bikin hati meleleh, tapi juga menuntut perhatian khusus dan ketelatenan. Di usia 0-8 minggu, mereka sangat rentan dan sepenuhnya bergantung pada perawatan yang tepat untuk bisa bertahan hidup dan tumbuh sehat.</p>

                    <h5 class="fw-bold text-dark mt-4">Usia 0-2 Minggu: Masa Kritis Penuh Kehangatan</h5>
                    <p>Pada usia ini, mata dan telinga anak kucing belum terbuka sempurna. Mereka belum bisa mengatur suhu tubuhnya sendiri. Pastikan mereka berada di tempat yang hangat, idealnya dengan lampu penghangat atau botol air hangat yang dibalut handuk. Jika tanpa induk, mereka perlu disusui dengan susu formula khusus kucing (bukan susu sapi) setiap 2-3 jam sekali menggunakan botol dot khusus.</p>

                    <h5 class="fw-bold text-dark mt-4">Usia 3-4 Minggu: Mulai Bereksplorasi</h5>
                    <p>Mata dan telinga mereka sudah berfungsi lebih baik. Mereka mulai mencoba berdiri dan berjalan perlahan. Di usia ini, kamu sudah bisa mulai memperkenalkan litter box (kotak pasir) berukuran dangkal. Untuk makanan, mulai campurkan sedikit wet food (makanan basah) khusus kitten dengan susu formula untuk membuat tekstur bubur yang lembut.</p>

                    <!-- Gambar Sisipan -->
                    <img src="https://placehold.co/800x400/f1f5f9/333?text=Kitten+Bermain" class="img-fluid rounded mb-3 mt-3 w-100" alt="Kitten bermain">

                    <h5 class="fw-bold text-dark mt-4">Usia 5-6 Minggu: Masa Transisi Makanan Padat</h5>
                    <p>Anak kucing sudah semakin aktif berlari dan bermain. Gigi susunya mulai tumbuh. Ini adalah waktu yang tepat untuk sepenuhnya beralih ke wet food dan perlahan memperkenalkan dry food (kibble) khusus kitten yang dibasahi sedikit air agar mudah dikunyah.</p>

                    <h5 class="fw-bold text-dark mt-4">Usia 7-8 Minggu: Siap Mandiri dan Vaksinasi</h5>
                    <p>Pada usia 8 minggu, anak kucing sudah sepenuhnya bisa makan makanan padat (dry food) dan menggunakan litter box dengan lancar. Ini juga merupakan usia ideal untuk membawa mereka ke dokter hewan untuk mendapatkan vaksinasi pertama dan obat cacing.</p>

                </div>

                <!-- Tombol Kembali -->
                <div class="mt-5 border-top pt-4">
                    <a href="index.php" class="btn btn-primary rounded-pill px-4"><i class="bi bi-arrow-left"></i> Kembali ke Beranda</a>
                </div>

            </div>
        </div>
    </div>

    <!-- BAGIAN 2: COPY FOOTER DARI index.php KE SINI -->

</body>
</html>