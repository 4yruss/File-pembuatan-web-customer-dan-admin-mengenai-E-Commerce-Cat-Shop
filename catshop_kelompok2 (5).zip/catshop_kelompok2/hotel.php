<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cat Hotel - Cat Shop</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            color: #222;
        }

        .topbar {
            height: 36px;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }

        .topbar a {
            color: #666;
            text-decoration: none;
        }

        .header {
            min-height: 145px;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
        }

        .logo {
            text-decoration: none;
        }

        .brand {
            font-size: 31px;
            font-weight: 800;
            color: #111;
        }

        .tag {
            font-size: 10px;
            color: #777;
        }

        .search {
            height: 40px;
            background: #f2f2f2;
            border: 0;
            border-radius: 24px;
            padding-left: 18px;
            width: 100%;
        }

        .icons {
            font-size: 21px;
            display: flex;
            gap: 20px;
            justify-content: end;
        }

        .icons a {
            color: #111;
        }

        .nav-wrap {
            border-bottom: 1px solid #ddd;
            min-height: 45px;
        }

        .nav {
            min-height: 45px;
            display: flex;
            align-items: center;
            gap: 25px;
            overflow: auto;
        }

        .nav a {
            font-size: 12px;
            font-weight: 700;
            color: #111;
            text-decoration: none;
            white-space: nowrap;
        }

        .nav a:hover {
            color: #16bde8;
        }

        .hero {
            min-height: 470px;
            background:
                linear-gradient(90deg, rgba(0, 0, 0, .72), rgba(0, 0, 0, .20)),
                url('https://images.unsplash.com/photo-1511044568932-338cba0ad803?auto=format&fit=crop&w=1800&q=85') center/cover;
            display: flex;
            align-items: center;
            color: #fff;
        }

        .hero h1 {
            font-size: 52px;
            font-weight: 800;
            margin-bottom: 18px;
        }

        .hero p {
            max-width: 650px;
        }

        .section {
            padding: 70px 0;
        }

        .section-title {
            font-weight: 800;
            margin-bottom: 14px;
        }

        .section-subtitle {
            color: #666;
            max-width: 760px;
            margin: 0 auto 40px;
        }

        .problem-card,
        .benefit-card,
        .branch-card {
            border: 1px solid #eee;
            background: #fff;
            padding: 28px;
            height: 100%;
            box-shadow: 0 4px 18px rgba(0, 0, 0, .06);
        }

        .problem-icon,
        .benefit-icon {
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: #f1f1f1;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
            margin-bottom: 18px;
        }

        .hotel-image {
            width: 100%;
            height: 420px;
            object-fit: cover;
        }

        .facility-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .facility-list li {
            padding: 14px 0;
            border-bottom: 1px solid #eee;
        }

        .facility-list i {
            margin-right: 10px;
        }

        .price-box {
            background: #111;
            color: #fff;
            padding: 45px 30px;
            text-align: center;
        }

        .price {
            font-size: 46px;
            font-weight: 800;
        }

        .cta {
            background: #f5f5f5;
            padding: 65px 0;
        }

        .btn-wa {
            background: #25d366;
            border: 0;
            color: #fff;
            padding: 13px 26px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-weight: 700;
        }

        .btn-wa:hover {
            background: #1ebe5d;
            color: #fff;
        }

        .branch-card h5 {
            font-weight: 800;
        }

        footer {
            background: #111;
            color: #aaa;
            padding: 55px 0 25px;
            font-size: 14px;
        }

        footer h5,
        footer strong {
            color: #fff;
        }

        footer a {
            color: #aaa;
            text-decoration: none;
        }

        footer a:hover {
            color: #fff;
        }

        .footer-bottom {
            border-top: 1px solid #333;
            margin-top: 35px;
            padding-top: 20px;
        }

        @media (max-width: 767px) {
            .hero {
                min-height: 400px;
            }

            .hero h1 {
                font-size: 38px;
            }

            .hotel-image {
                height: 300px;
            }
        }
    </style>
</head>

<body>

    <!-- TOP BAR -->
    <div class="topbar d-flex align-items-center">
        <div class="container d-flex justify-content-between">
            <div>
                <a href="index.php">
                    <i class="bi bi-house me-1"></i>Cat Shop
                </a>
                <span class="mx-3">Order Tracking</span>
            </div>
            <b>CAT SHOP</b>
        </div>
    </div>

    <!-- HEADER -->
    <header class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <a href="index.php" class="logo">
                        <div class="brand">CAT SHOP</div>
                        <div class="tag">Pusat Kebutuhan Kucing Terlengkap</div>
                    </a>
                </div>

                <div class="col-md-6">
                    <input class="search" placeholder="Search products...">
                </div>

                <div class="col-md-3">
                    <div class="icons">
                        <a href="#"><i class="bi bi-person"></i></a>
                        <a href="#"><i class="bi bi-heart"></i></a>
                        <a href="#"><i class="bi bi-cart3"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- NAVIGATION -->
    <div class="nav-wrap">
        <div class="container">
            <nav class="nav">
                <a href="index.php">BERANDA</a>
                <a href="our_story.php">OUR STORY</a>
                <a href="our_channel.php">OUR CHANNEL</a>
                <a href="our_leaders.php">OUR LEADERS</a>
                <a href="our_veterinarian.php">OUR VETERINARIAN</a>
                <a href="brand.php">BRAND</a>
                <a href="blog.php">BLOG</a>
                <a href="toko_terdekat.php">TOKO TERDEKAT</a>
                <a href="link.php">LINK</a>
                <a href="karir.php">KARIR</a>
            </nav>
        </div>
    </div>

    <!-- HERO -->
    <section class="hero">
        <div class="container">
            <small class="fw-bold">CAT SHOP HOTEL</small>
            <h1>CAT HOTEL SERVICE</h1>
            <p class="lead">
                Mau pergi mudik atau liburan tapi tidak ada yang menjaga kucing kesayangan?
                Titipkan kucingmu di Cat Hotel dengan nyaman, aman, dan terawat.
            </p>
            <a href="https://wa.me/6285719323258?text=Halo%20*Cat%20Shop*,%20%F0%9F%91%8B%F0%9F%98%BA%20Saya%20ingin%20informasi%20lebih%20lanjut%20tentang%20*Cat%20Hotel*%20di%20Cat%20Shop."
               class="btn-wa mt-3" target="_blank">
                <i class="bi bi-whatsapp me-2"></i>Saya Ada Kebutuhan CAT HOTEL
            </a>
        </div>
    </section>

    <!-- PROBLEM -->
    <section class="section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Mau Pergi Mudik atau Liburan?</h2>
                <p class="section-subtitle">
                    Jangan khawatir meninggalkan kucing kesayanganmu sendirian di rumah.
                    Cat Shop siap membantu menjaga dan merawatnya selama kamu pergi.
                </p>
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="problem-card">
                        <div class="problem-icon"><i class="bi bi-house-heart"></i></div>
                        <h5>Kucing Sendirian</h5>
                        <p class="text-muted mb-0">Tidak tega meninggalkan kucing sendirian di rumah saat kamu bepergian.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="problem-card">
                        <div class="problem-icon"><i class="bi bi-person-x"></i></div>
                        <h5>Tidak Ada yang Menjaga</h5>
                        <p class="text-muted mb-0">Tidak ada keluarga atau teman yang bisa membantu merawat kucingmu.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="problem-card">
                        <div class="problem-icon"><i class="bi bi-shield-check"></i></div>
                        <h5>Butuh Tempat Terpercaya</h5>
                        <p class="text-muted mb-0">Khawatir menitipkan kucing kepada orang lain dengan standar perawatan yang berbeda.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- INTRO -->
    <section class="section bg-light">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <img src="https://images.unsplash.com/photo-1543852786-1cf6624b9987?auto=format&fit=crop&w=1200&q=85"
                         class="hotel-image"
                         alt="Kucing di Cat Hotel">
                </div>

                <div class="col-lg-6">
                    <small class="text-uppercase fw-bold">CAT SHOP</small>
                    <h2 class="section-title mt-2">CAT HOTEL SERVICE BY CAT SHOP</h2>
                    <p>
                        Cat Hotel adalah layanan penitipan khusus kucing untuk membantu kamu
                        ketika harus bepergian, mudik, liburan, atau memiliki aktivitas lain.
                    </p>
                    <p>
                        Kucing mendapatkan tempat yang nyaman dan bersih serta dipantau selama
                        berada di Cat Hotel.
                    </p>
                    <a href="https://wa.me/6285719323258?text=Halo%20*Cat%20Shop*,%20%F0%9F%91%8B%F0%9F%98%BA%20Saya%20ingin%20booking%20*Cat%20Hotel*."
                       class="btn-wa mt-2" target="_blank">
                        <i class="bi bi-whatsapp me-2"></i>Booking Cat Hotel
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- BENEFITS -->
    <section class="section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Fasilitas & Benefit Cat Hotel</h2>
                <p class="section-subtitle">
                    Beberapa fasilitas yang kami siapkan untuk membantu menjaga kenyamanan kucing selama menginap.
                </p>
            </div>

            <div class="row g-4">
                <div class="col-md-6 col-lg-4">
                    <div class="benefit-card">
                        <div class="benefit-icon"><i class="bi bi-snow"></i></div>
                        <h5>Ruangan Sejuk</h5>
                        <p class="text-muted mb-0">Area penitipan dibuat nyaman dengan ruangan yang sejuk dan bersih.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="benefit-card">
                        <div class="benefit-icon"><i class="bi bi-stars"></i></div>
                        <h5>Kandang Dibersihkan</h5>
                        <p class="text-muted mb-0">Kebersihan area kucing diperhatikan secara rutin selama masa penitipan.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="benefit-card">
                        <div class="benefit-icon"><i class="bi bi-camera-video"></i></div>
                        <h5>Update Kondisi</h5>
                        <p class="text-muted mb-0">Pemilik dapat meminta informasi mengenai kondisi kucing selama menginap.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="benefit-card">
                        <div class="benefit-icon"><i class="bi bi-cup-hot"></i></div>
                        <h5>Makan & Minum</h5>
                        <p class="text-muted mb-0">Kebutuhan makan dan minum kucing diperhatikan sesuai informasi dari pemilik.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="benefit-card">
                        <div class="benefit-icon"><i class="bi bi-heart-pulse"></i></div>
                        <h5>Dipantau</h5>
                        <p class="text-muted mb-0">Kondisi kucing dipantau selama berada di area Cat Hotel.</p>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4">
                    <div class="benefit-card">
                        <div class="benefit-icon"><i class="bi bi-house"></i></div>
                        <h5>Tempat Nyaman</h5>
                        <p class="text-muted mb-0">Kucing mendapatkan area istirahat yang nyaman selama masa penitipan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FACILITIES -->
    <section class="section bg-light">
        <div class="container">
            <div class="row g-5 align-items-center">
                <div class="col-lg-6">
                    <h2 class="section-title">Apa Saja yang Didapatkan?</h2>
                    <p class="text-muted mb-4">
                        Cat Shop menyediakan beberapa layanan pendukung agar kebutuhan dasar kucing tetap diperhatikan selama menginap.
                    </p>

                    <ul class="facility-list">
                        <li><i class="bi bi-check-circle-fill"></i> Area penitipan yang bersih</li>
                        <li><i class="bi bi-check-circle-fill"></i> Ruangan nyaman untuk kucing</li>
                        <li><i class="bi bi-check-circle-fill"></i> Pemberian makan dan minum</li>
                        <li><i class="bi bi-check-circle-fill"></i> Pembersihan area secara rutin</li>
                        <li><i class="bi bi-check-circle-fill"></i> Pemantauan kondisi kucing</li>
                        <li><i class="bi bi-check-circle-fill"></i> Informasi kondisi kepada pemilik</li>
                    </ul>
                </div>

                <div class="col-lg-6">
                    <img src="https://images.unsplash.com/photo-1518791841217-8f162f1e1131?auto=format&fit=crop&w=1200&q=85"
                         class="hotel-image"
                         alt="Kucing beristirahat">
                </div>
            </div>
        </div>
    </section>

    <!-- PRICE -->
    <section class="section">
        <div class="container">
            <div class="price-box">
                <small class="text-uppercase">Cat Hotel Services</small>
                <h2 class="mt-2 mb-3">Harga Penitipan Kucing</h2>
                <div class="price">Mulai dari Rp35.000</div>
                <p class="mb-0">per malam</p>
                <p class="mt-3 mb-4 text-white-50">
                    Harga dapat disesuaikan berdasarkan tipe kamar, kebutuhan kucing, dan durasi penitipan.
                </p>
                <a href="https://wa.me/6285719323258?text=Halo%20*Cat%20Shop*,%20%F0%9F%91%8B%F0%9F%98%BA%20Saya%20ingin%20menanyakan%20harga%20dan%20ketersediaan%20*Cat%20Hotel*."
                   class="btn btn-light px-4 py-2 fw-bold" target="_blank">
                    Tanya Harga & Ketersediaan
                </a>
            </div>
        </div>
    </section>

    <!-- BOOKING CTA -->
    <section class="cta">
        <div class="container text-center">
            <h2 class="section-title">Booking Jadwal CAT HOTEL Hari Ini!</h2>
            <p class="text-muted mb-4">
                Hubungi Cat Shop melalui WhatsApp untuk menanyakan jadwal dan ketersediaan tempat.
            </p>
            <a href="https://wa.me/6285719323258?text=Halo%20*Cat%20Shop*,%20%F0%9F%91%8B%F0%9F%98%BA%20Saya%20ingin%20booking%20*Cat%20Hotel*."
               class="btn-wa" target="_blank">
                <i class="bi bi-whatsapp me-2"></i>Booking Sekarang
            </a>
            <p class="small text-muted mt-3">*Syarat dan ketentuan berlaku.</p>
        </div>
    </section>

    <!-- BRANCHES -->
    <section class="section">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Lokasi Cat Shop</h2>
                <p class="section-subtitle">
                    Hubungi Cat Shop untuk mengetahui lokasi dan ketersediaan layanan Cat Hotel di cabang yang kamu pilih.
                </p>
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="branch-card">
                        <h5>Bekasi</h5>
                        <p class="text-muted mb-0">Pekayon • Harapan Indah • Perwira • Tambun</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="branch-card">
                        <h5>Jakarta</h5>
                        <p class="text-muted mb-0">Jakarta Barat • Jakarta Timur • Jakarta Selatan • Jakarta Utara</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="branch-card">
                        <h5>Depok</h5>
                        <p class="text-muted mb-0">Tanah Baru • Sawangan • Cimanggis • Sukmajaya</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="branch-card">
                        <h5>Bogor</h5>
                        <p class="text-muted mb-0">Sentul City • Pandu Raya</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="branch-card">
                        <h5>Tangerang</h5>
                        <p class="text-muted mb-0">Ciputat • Ciledug • Gading Serpong</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="branch-card">
                        <h5>Kota Lain</h5>
                        <p class="text-muted mb-0">Hubungi kami untuk informasi cabang dan layanan Cat Hotel.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACT -->
    <section class="cta">
        <div class="container text-center">
            <h2 class="section-title">Butuh Penitipan Kucing?</h2>
            <p class="text-muted mb-4">
                Jangan tunggu sampai jadwal penuh. Hubungi Cat Shop untuk informasi dan booking Cat Hotel.
            </p>
            <a href="https://wa.me/6285719323258?text=Halo%20*Cat%20Shop*,%20%F0%9F%91%8B%F0%9F%98%BA%20Saya%20ingin%20informasi%20tentang%20*Cat%20Hotel*."
               class="btn-wa" target="_blank">
                <i class="bi bi-whatsapp me-2"></i>Hubungi Cat Shop
            </a>
        </div>
    </section>

    <!-- FOOTER -->
    <footer>
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5>CAT SHOP</h5>
                    <p class="mt-3">
                        Pusat kebutuhan kucing terlengkap, mulai dari makanan, perlengkapan,
                        kesehatan, grooming, klinik, hingga Cat Hotel.
                    </p>
                </div>

                <div class="col-lg-2 col-md-4">
                    <h5>Cat Shop</h5>
                    <ul class="list-unstyled mt-3">
                        <li class="mb-2"><a href="index.php">Beranda</a></li>
                        <li class="mb-2"><a href="brand.php">Brand</a></li>
                        <li class="mb-2"><a href="blog.php">Blog</a></li>
                        <li class="mb-2"><a href="toko_terdekat.php">Toko Terdekat</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-4">
                    <h5>Layanan</h5>
                    <ul class="list-unstyled mt-3">
                        <li class="mb-2"><a href="shop.php">Shop</a></li>
                        <li class="mb-2"><a href="grooming.php">Grooming</a></li>
                        <li class="mb-2"><a href="klinik.php">Klinik</a></li>
                        <li class="mb-2"><a href="hotel.php">Cat Hotel</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-4">
                    <h5>Hubungi Kami</h5>
                    <p class="mt-3 mb-2">
                        <i class="bi bi-whatsapp me-2"></i>0857-1932-3258
                    </p>
                    <p class="mb-2">
                        <i class="bi bi-envelope me-2"></i>info@catshop.com
                    </p>
                    <p class="mb-0">
                        <i class="bi bi-clock me-2"></i>Setiap Hari 09.00 - 21.00
                    </p>
                </div>
            </div>

            <div class="footer-bottom d-flex justify-content-between flex-wrap gap-2">
                <span>Copyright © 2026 Cat Shop. All Rights Reserved.</span>
                <span>
                    <a href="#" class="me-3"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="me-3"><i class="bi bi-facebook"></i></a>
                    <a href="https://wa.me/6285719323258" target="_blank"><i class="bi bi-whatsapp"></i></a>
                </span>
            </div>
        </div>
    </footer>

</body>
</html>
