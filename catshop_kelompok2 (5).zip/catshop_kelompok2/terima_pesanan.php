<?php
session_start();
include 'koneksi.php';

// Jika belum login, alihkan ke halaman login
if (!isset($_SESSION['user_id'])) {
    header("location: akun.php");
    exit();
}

$id_pesanan = isset($_GET['id']) ? $_GET['id'] : '';

// Ubah status pesanan menjadi Selesai
$update = mysqli_query($koneksi, "UPDATE pesanan SET status = 'Selesai' WHERE id_pesanan = '$id_pesanan'");

if ($update) {
    echo "<script>alert('Terima kasih! Pesanan dinyatakan selesai.'); window.location='riwayat_pesanan.php';</script>";
} else {
    echo "<script>alert('Gagal memperbarui status pesanan.'); window.location='riwayat_pesanan.php';</script>";
}
?>