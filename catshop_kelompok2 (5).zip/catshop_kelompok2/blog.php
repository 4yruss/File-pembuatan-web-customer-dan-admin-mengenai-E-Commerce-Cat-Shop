<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - Cat Shop</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-gray-50 text-gray-800">

    <!-- Header / Navbar -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="container mx-auto px-4 py-4 flex justify-between items-center">
            <h1 class="text-2xl font-bold text-indigo-600">CAT SHOP 🐾</h1>
            <div class="hidden md:flex w-1/2">
                <input type="text" class="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Cari produk atau artikel...">
            </div>
            <div class="flex items-center space-x-4">
                <a href="keranjang.php" class="text-gray-700 hover:text-indigo-600"><i class="bi bi-cart text-xl"></i></a>
                <a href="wishlist.php" class="text-gray-700 hover:text-indigo-600"><i class="bi bi-heart text-xl"></i></a>
                <a href="akun.php" class="text-gray-700 hover:text-indigo-600"><i class="bi bi-person text-xl"></i></a>
            </div>
        </div>
        <nav class="bg-white border-t">
            <div class="container mx-auto px-4 py-2 flex space-x-6 overflow-x-auto text-sm font-medium">
                <a href="index.php" class="text-gray-600 hover:text-indigo-600">BERANDA</a>
                <a href="shop.php" class="text-gray-600 hover:text-indigo-600">SHOP</a>
                <a href="klinik.php" class="text-gray-600 hover:text-indigo-600">KLINIK</a>
                <a href="grooming.php" class="text-gray-600 hover:text-indigo-600">GROOMING</a>
                <a href="hotel.php" class="text-gray-600 hover:text-indigo-600">HOTEL</a>
                <a href="blog.php" class="text-indigo-600 font-bold border-b-2 border-indigo-600 pb-1">BLOG</a>
                <a href="toko_terdekat.php" class="text-gray-600 hover:text-indigo-600">TOKO TERDEKAT</a>
            </div>
        </nav>
    </header>

    <!-- Hero Section Blog -->
    <section class="bg-emerald-800 text-white py-12">
        <div class="container mx-auto px-4">
            <p class="text-xs uppercase tracking-wider mb-1 text-emerald-200">Cat Shop • Blog</p>
            <h2 class="text-3xl font-extrabold mb-2">Blog</h2>
            <p class="text-sm text-emerald-100">Artikel dan informasi terbaru seputar dunia kucing.</p>
        </div>
    </section>

    <!-- Main Content Layout (2 Kolom: Kiri Artikel, Kanan Sidebar) -->
    <main class="container mx-auto px-4 py-10">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <!-- Kolom Kiri: Daftar Artikel (2 Kolom Grid Kecil di dalam) -->
            <div class="lg:col-span-2">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    
                    <!-- Artikel 1 -->
                    <div class="bg-white border rounded-xl overflow-hidden shadow-sm hover:shadow transition flex flex-col justify-between">
                        <div>
                            <img src="https://placehold.co/400x250/e2e8f0/475569?text=Dry+Food+vs+Wet+Food" alt="Artikel 1" class="w-full h-44 object-cover">
                            <div class="p-4">
                                <span class="text-xs bg-indigo-100 text-indigo-600 font-semibold px-2.5 py-1 rounded">Nutrisi</span>
                                <h3 class="font-bold text-base mt-2 mb-2 leading-snug">Dry Food vs Wet Food: Lebih Baik Mana untuk Kucing Kesayangan?</h3>
                                <p class="text-xs text-gray-500 line-clamp-2">Temukan perbedaan antara dry food dan wet food agar nutrisi anabul tetap seimbang...</p>
                            </div>
                        </div>
                        <div class="p-4 pt-0">
                            <a href="#" class="inline-block bg-indigo-600 text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-indigo-700 transition">Read More →</a>
                        </div>
                    </div>

                    <!-- Artikel 2 -->
                    <div class="bg-white border rounded-xl overflow-hidden shadow-sm hover:shadow transition flex flex-col justify-between">
                        <div>
                            <img src="https://placehold.co/400x250/e2e8f0/475569?text=Anak+Kucing" alt="Artikel 2" class="w-full h-44 object-cover">
                            <div class="p-4">
                                <span class="text-xs bg-indigo-100 text-indigo-600 font-semibold px-2.5 py-1 rounded">Perawatan</span>
                                <h3 class="font-bold text-base mt-2 mb-2 leading-snug">Cara Merawat Anak Kucing Baru Lahir: Panduan Lengkap dari 0-8 Minggu</h3>
                                <p class="text-xs text-gray-500 line-clamp-2">Memelihara anak kucing yang baru lahir menuntut perhatian khusus dan ketelatenan...</p>
                            </div>
                        </div>
                        <div class="p-4 pt-0">
                            <a href="#" class="inline-block bg-indigo-600 text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-indigo-700 transition">Read More →</a>
                        </div>
                    </div>

                    <!-- Artikel 3 -->
                    <div class="bg-white border rounded-xl overflow-hidden shadow-sm hover:shadow transition flex flex-col justify-between">
                        <div>
                            <img src="https://placehold.co/400x250/e2e8f0/475569?text=Kucing+Sehat" alt="Artikel 3" class="w-full h-44 object-cover">
                            <div class="p-4">
                                <span class="text-xs bg-indigo-100 text-indigo-600 font-semibold px-2.5 py-1 rounded">Kesehatan</span>
                                <h3 class="font-bold text-base mt-2 mb-2 leading-snug">Merawat Kucing Kesayangan di Rumah dengan Optimal</h3>
                                <p class="text-xs text-gray-500 line-clamp-2">Menjaga kebersihan mental dan fisik hewan peliharaan adalah kunci utama umur panjang...</p>
                            </div>
                        </div>
                        <div class="p-4 pt-0">
                            <a href="#" class="inline-block bg-indigo-600 text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-indigo-700 transition">Read More →</a>
                        </div>
                    </div>

                    <!-- Artikel 4 -->
                    <div class="bg-white border rounded-xl overflow-hidden shadow-sm hover:shadow transition flex flex-col justify-between">
                        <div>
                            <img src="https://placehold.co/400x250/e2e8f0/475569?text=Kandang+Kucing" alt="Artikel 4" class="w-full h-44 object-cover">
                            <div class="p-4">
                                <span class="text-xs bg-indigo-100 text-indigo-600 font-semibold px-2.5 py-1 rounded">Tips</span>
                                <h3 class="font-bold text-base mt-2 mb-2 leading-snug">Tips Membuat Kucing Nyaman di Kandang Agar Tidak Stress</h3>
                                <p class="text-xs text-gray-500 line-clamp-2">Ada beberapa jenis grooming di studio ini yang dirancang khusus untuk kenyamanan anabul...</p>
                            </div>
                        </div>
                        <div class="p-4 pt-0">
                            <a href="#" class="inline-block bg-indigo-600 text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-indigo-700 transition">Read More →</a>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Kolom Kanan: Sidebar (Pencarian, Artikel Terbaru, Kategori) -->
            <div class="space-y-6">
                
                <!-- Widget Cari -->
                <div class="bg-white border p-5 rounded-xl shadow-sm">
                    <h4 class="font-bold text-sm mb-3 uppercase tracking-wider text-gray-700">Cari</h4>
                    <div class="relative">
                        <input type="text" class="w-full border rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Cari artikel...">
                        <span class="absolute right-3 top-2.5 text-gray-400 text-xs"><i class="bi bi-search"></i></span>
                    </div>
                </div>

                <!-- Widget Artikel Terbaru -->
                <div class="bg-white border p-5 rounded-xl shadow-sm">
                    <h4 class="font-bold text-sm mb-4 uppercase tracking-wider text-gray-700">Artikel Terbaru</h4>
                    <div class="space-y-3">
                        <a href="#" class="flex items-center gap-3 group">
                            <img src="https://placehold.co/60x60/e2e8f0/475569?text=Food" alt="Thumb" class="w-12 h-12 rounded object-cover">
                            <div>
                                <p class="text-xs font-semibold text-gray-800 group-hover:text-indigo-600 leading-snug">Dry Food vs Wet Food: Lebih Baik Mana...</p>
                                <span class="text-[10px] text-gray-400">19 Oktober 2026</span>
                            </div>
                        </a>
                        <a href="#" class="flex items-center gap-3 group">
                            <img src="https://placehold.co/60x60/e2e8f0/475569?text=Kitten" alt="Thumb" class="w-12 h-12 rounded object-cover">
                            <div>
                                <p class="text-xs font-semibold text-gray-800 group-hover:text-indigo-600 leading-snug">Cara Merawat Anak Kucing Baru Lahir...</p>
                                <span class="text-[10px] text-gray-400">21 Oktober 2026</span>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Widget Kategori Artikel -->
                <div class="bg-white border p-5 rounded-xl shadow-sm">
                    <h4 class="font-bold text-sm mb-4 uppercase tracking-wider text-gray-700">Kategori Artikel</h4>
                    <ul class="text-xs space-y-2 text-gray-600">
                        <li class="flex justify-between border-b pb-1.5"><a href="#" class="hover:text-indigo-600">Nutrisi Kucing</a> <span>(5)</span></li>
                        <li class="flex justify-between border-b pb-1.5"><a href="#" class="hover:text-indigo-600">Perawatan & Grooming</a> <span>(8)</span></li>
                        <li class="flex justify-between border-b pb-1.5"><a href="#" class="hover:text-indigo-600">Kesehatan Anabul</a> <span>(4)</span></li>
                        <li class="flex justify-between pb-1.5"><a href="#" class="hover:text-indigo-600">Tips & Trik</a> <span>(6)</span></li>
                    </ul>
                </div>

            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-8 mt-12">
        <div class="container mx-auto px-4 text-center text-xs text-gray-400">
            Copyright © 2026 Cat Shop. All rights reserved.
        </div>
    </footer>

</body>
</html>