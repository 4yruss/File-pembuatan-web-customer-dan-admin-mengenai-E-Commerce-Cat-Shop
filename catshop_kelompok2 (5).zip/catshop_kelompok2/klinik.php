<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klinik Hewan - Cat Shop</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-gray-50 text-gray-800">

    <!-- Header / Navbar -->
    <header class="bg-white shadow-sm sticky top-0 z-50">
        <div class="container mx-auto px-4 py-4 flex justify-between items-center">
            <h1 class="text-2xl font-bold text-indigo-600">CAT SHOP 🐾</h1>
            <div class="hidden md:flex w-1/2">
                <input type="text" class="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" placeholder="Cari produk, layanan, atau klinik...">
            </div>
            <div class="flex items-center space-x-4">
                <a href="keranjang.php" class="text-gray-700 hover:text-indigo-600"><i class="bi bi-cart text-xl"></i></a>
                <a href="wishlist.php" class="text-gray-700 hover:text-indigo-600"><i class="bi bi-heart text-xl"></i></a>
                <a href="akun.php" class="text-gray-700 hover:text-indigo-600"><i class="bi bi-person text-xl"></i></a>
            </div>
        </div>
        <nav class="bg-white border-t">
            <div class="container mx-auto px-4 py-2 flex space-x-6 overflow-x-auto text-sm font-medium">
                <a href="index.php" class="text-gray-600 hover:text-indigo-600">BERANDA</a>
                <a href="shop.php" class="text-gray-600 hover:text-indigo-600">SHOP</a>
                <a href="klinik.php" class="text-indigo-600 font-bold border-b-2 border-indigo-600 pb-1">KLINIK</a>
                <a href="grooming.php" class="text-gray-600 hover:text-indigo-600">GROOMING</a>
                <a href="hotel.php" class="text-gray-600 hover:text-indigo-600">HOTEL</a>
                <a href="blog.php" class="text-gray-600 hover:text-indigo-600">BLOG</a>
                <a href="toko_terdekat.php" class="text-gray-600 hover:text-indigo-600">TOKO TERDEKAT</a>
            </div>
        </nav>
    </header>

    <!-- Hero Section Klinik -->
    <section class="bg-white py-12 text-center border-b">
        <div class="container mx-auto px-4">
            <p class="text-sm text-gray-500 uppercase tracking-wider mb-2">Periksa ke Dokter Hewan Terpercaya</p>
            <h2 class="text-3xl font-extrabold mb-3">Konsultasi & Pemeriksaan Untuk Membantu Mengetahui Kondisi Anabul Dengan Tepat</h2>
            <p class="text-sm text-gray-400 font-semibold">VET CLINIC SERVICE BY CAT SHOP</p>
        </div>
    </section>

    <!-- Bagian Gejala / Masalah Anabul -->
    <section class="py-12 bg-white">
        <div class="container mx-auto px-4 text-center">
            <h3 class="text-2xl font-bold mb-8">Apakah Anabul Kamu Mengalami Ini?</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                <div class="p-4 border rounded-xl bg-gray-50 shadow-sm hover:shadow transition">
                    <img src="https://placehold.co/80x80/e2e8f0/475569?text=Muntah" alt="Gejala Sakit" class="mx-auto mb-3 rounded-full">
                    <h4 class="font-semibold text-sm mb-1">Gejala Sakit atau Muntah</h4>
                    <p class="text-xs text-gray-500">Anabul lemas, muntah, atau tidak mau makan.</p>
                </div>
                <div class="p-4 border rounded-xl bg-gray-50 shadow-sm hover:shadow transition">
                    <img src="https://placehold.co/80x80/e2e8f0/475569?text=Luka" alt="Luka" class="mx-auto mb-3 rounded-full">
                    <h4 class="font-semibold text-sm mb-1">Luka, Cedera, atau Pendarahan</h4>
                    <p class="text-xs text-gray-500">Terkena goresan, luka luar, atau pincang.</p>
                </div>
                <div class="p-4 border rounded-xl bg-gray-50 shadow-sm hover:shadow transition">
                    <img src="https://placehold.co/80x80/e2e8f0/475569?text=Kulit" alt="Kulit" class="mx-auto mb-3 rounded-full">
                    <h4 class="font-semibold text-sm mb-1">Penyakit Kulit & Telinga</h4>
                    <p class="text-xs text-gray-500">Gatal-gatal, jamur, scabies, atau kutu.</p>
                </div>
                <div class="p-4 border rounded-xl bg-gray-50 shadow-sm hover:shadow transition">
                    <img src="https://placehold.co/80x80/e2e8f0/475569?text=Vaksin" alt="Vaksin" class="mx-auto mb-3 rounded-full">
                    <h4 class="font-semibold text-sm mb-1">Vaksinasi & Kesehatan Rutin</h4>
                    <p class="text-xs text-gray-500">Pemberian vaksin tahunan dan cek kesehatan.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Banner Foto Klinik -->
    <section class="py-8 bg-gray-100 text-center">
        <div class="container mx-auto px-4">
            <img src="https://placehold.co/900x350/334155/FFFFFF?text=Cat+Shop+Vet+Clinic" alt="Vet Clinic" class="mx-auto rounded-2xl shadow-md w-full max-w-3xl object-cover">
        </div>
    </section>

    <!-- Jadwal & Lokasi Dokter -->
    <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
            <h3 class="text-xl font-bold text-center mb-8 uppercase tracking-wide">Jadwal & Lokasi Dokter • Cat Shop Vet Center</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                <!-- Lokasi 1 -->
                <div class="bg-white border rounded-xl p-5 shadow-sm hover:shadow transition flex flex-col justify-between">
                    <div>
                        <h4 class="font-bold text-indigo-600 mb-2">CIBUBUR</h4>
                        <p class="text-xs text-gray-500 mb-2">Jadwal Praktik Dokter:</p>
                        <ul class="text-xs text-gray-600 space-y-1 mb-4">
                            <li>• drh. Anita (09.00 - 13.00)</li>
                            <li>• drh. Rian (14.00 - 18.00)</li>
                        </ul>
                    </div>
                    <a href="#" class="block text-center bg-indigo-50 text-indigo-600 font-semibold py-2 rounded-lg text-xs hover:bg-indigo-100 transition">Lihat Lokasi & Dokter</a>
                </div>
                <!-- Lokasi 2 -->
                <div class="bg-white border rounded-xl p-5 shadow-sm hover:shadow transition flex flex-col justify-between">
                    <div>
                        <h4 class="font-bold text-indigo-600 mb-2">BUNGUR</h4>
                        <p class="text-xs text-gray-500 mb-2">Jadwal Praktik Dokter:</p>
                        <ul class="text-xs text-gray-600 space-y-1 mb-4">
                            <li>• drh. Siska (10.00 - 14.00)</li>
                            <li>• drh. Doni (15.00 - 19.00)</li>
                        </ul>
                    </div>
                    <a href="#" class="block text-center bg-indigo-50 text-indigo-600 font-semibold py-2 rounded-lg text-xs hover:bg-indigo-100 transition">Lihat Lokasi & Dokter</a>
                </div>
                <!-- Lokasi 3 -->
                <div class="bg-white border rounded-xl p-5 shadow-sm hover:shadow transition flex flex-col justify-between">
                    <div>
                        <h4 class="font-bold text-indigo-600 mb-2">RADIO DALAM</h4>
                        <p class="text-xs text-gray-500 mb-2">Jadwal Praktik Dokter:</p>
                        <ul class="text-xs text-gray-600 space-y-1 mb-4">
                            <li>• drh. Maya (09.00 - 13.00)</li>
                            <li>• drh. Bayu (14.00 - 18.00)</li>
                        </ul>
                    </div>
                    <a href="#" class="block text-center bg-indigo-50 text-indigo-600 font-semibold py-2 rounded-lg text-xs hover:bg-indigo-100 transition">Lihat Lokasi & Dokter</a>
                </div>
                <!-- Lokasi 4 -->
                <div class="bg-white border rounded-xl p-5 shadow-sm hover:shadow transition flex flex-col justify-between">
                    <div>
                        <h4 class="font-bold text-indigo-600 mb-2">CIPUTAT</h4>
                        <p class="text-xs text-gray-500 mb-2">Jadwal Praktik Dokter:</p>
                        <ul class="text-xs text-gray-600 space-y-1 mb-4">
                            <li>• drh. Putri (11.00 - 15.00)</li>
                            <li>• drh. Joko (16.00 - 20.00)</li>
                        </ul>
                    </div>
                    <a href="#" class="block text-center bg-indigo-50 text-indigo-600 font-semibold py-2 rounded-lg text-xs hover:bg-indigo-100 transition">Lihat Lokasi & Dokter</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-8 mt-12">
        <div class="container mx-auto px-4 text-center text-xs text-gray-400">
            Copyright © 2026 Cat Shop. All rights reserved.
        </div>
    </footer>

</body>
</html>