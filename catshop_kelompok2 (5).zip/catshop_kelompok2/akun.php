<?php
session_start();
include 'koneksi.php'; // Pastikan file koneksi database Anda benar

// 1. PROSES DAFTAR (REGISTER)
if (isset($_POST['daftar'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Enkripsi password

    // Cek apakah email sudah dipakai
    $cek_email = mysqli_query($koneksi, "SELECT * FROM users WHERE email = '$email'");
    if (mysqli_num_rows($cek_email) > 0) {
        echo "<script>alert('Email sudah terdaftar! Silakan gunakan email lain atau login.');</script>";
    } else {
        // Masukkan data ke MySQL
        mysqli_query($koneksi, "INSERT INTO users (nama, email, password) VALUES ('$nama', '$email', '$password')");
        echo "<script>alert('Akun berhasil dibuat! Silakan login.');</script>";
    }
}

// 2. PROSES LOGIN
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $cek = mysqli_query($koneksi, "SELECT * FROM users WHERE email = '$email'");
    if (mysqli_num_rows($cek) > 0) {
        $data = mysqli_fetch_assoc($cek);
        // Periksa apakah password cocok dengan yang ada di database (hasil password_hash)
        if (password_verify($password, $data['password'])) {
            $_SESSION['user_id'] = $data['id']; // Pastikan nama kolom di database Anda 'id' atau ubah jadi 'id_user' jika berbeda
            $_SESSION['user_nama'] = $data['nama'];
            echo "<script>alert('Login Berhasil!'); window.location='index.php';</script>";
        } else {
            echo "<script>alert('Password salah!');</script>";
        }
    } else {
        echo "<script>alert('Email belum terdaftar!');</script>";
    }
}
?>
<?php
$pageTitle = 'Akun Saya - Cat Shop';
?>
<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $pageTitle ?></title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <style>
        body {
            background: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .top {
            background: #111;
            color: #fff;
            padding: 10px 0;
        }

        .logo {
            font-size: 28px;
            font-weight: 800;
            color: #111;
            text-decoration: none;
        }

        .icon-link {
            color: #111;
            text-decoration: none;
            font-size: 22px;
            margin-left: 20px;
        }

        .card-box {
            background: #fff;
            border: 1px solid #e5e5e5;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.05);
        }

        .form-control {
            padding: 11px 12px;
            border-radius: 8px;
        }

        .btn-dark {
            border-radius: 8px;
            padding: 11px 20px;
        }

        .account-link {
            color: #111;
            text-decoration: none;
            cursor: pointer;
        }

        .account-link:hover {
            text-decoration: underline;
        }

        .form-section {
            display: none;
        }

        .form-section.active {
            display: block;
        }
    </style>
</head>

<body>

    <!-- =========================
         TOP BAR
    ========================== -->
    <div class="top">
        <div class="container d-flex justify-content-between">

            <span>
                Cat Shop - Pusat Kebutuhan Kucing
            </span>

            <a
                href="https://wa.me/6285719323258"
                class="text-white text-decoration-none"
            >
                WhatsApp
            </a>

        </div>
    </div>


    <!-- =========================
         HEADER
    ========================== -->
    <header class="bg-white border-bottom py-3">

        <div class="container d-flex align-items-center justify-content-between">

            <!-- Logo -->
            <a
                class="logo"
                href="index.php"
            >
                CAT SHOP
            </a>


            <!-- Header Icons -->
            <div>

                <a
                    href="akun.php"
                    class="icon-link"
                    title="Akun"
                >
                    <i class="bi bi-person"></i>
                </a>

                <a
                    href="wishlist.php"
                    class="icon-link"
                    title="Wishlist"
                >
                    <i class="bi bi-heart"></i>
                </a>

                <a
                    href="keranjang.php"
                    class="icon-link"
                    title="Keranjang"
                >
                    <i class="bi bi-cart3"></i>
                </a>

            </div>

        </div>

    </header>


    <!-- =========================
         MAIN CONTENT
    ========================== -->
    <main class="container py-5">

        <div class="row justify-content-center">

            <div class="col-lg-7">

                <div class="card-box">

                    <!-- =========================
                         LOGIN
                    ========================== -->
<?php if (isset($_SESSION['user_id'])): ?>
    <!-- TAMPILAN JIKA SUDAH LOGIN -->
    <div class="text-center py-4">
        <h2 class="fw-bold mb-2">Halo, <?php echo $_SESSION['user_nama']; ?>!</h2>
        <p class="text-muted mb-4">Anda sudah berhasil login ke akun Cat Shop.</p>
<a href="riwayat_pesanan.php" class="btn btn-dark px-4 me-2">📦 Riwayat Pesanan</a>
<a href="logout.php" class="btn btn-danger px-4" onclick="return confirm('Yakin ingin keluar dari akun?')">Logout</a>
    </div>
<?php else: ?>
    <!-- TAMPILAN FORM LOGIN -->
    <div id="loginSection" class="form-section active">
        <h2 class="fw-bold mb-2">Login</h2>
        <p class="text-muted mb-4">Masuk ke akun Cat Shop kamu.</p>

        <form action="" method="POST">
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" id="loginEmail" class="form-control" placeholder="nama@email.com" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" id="loginPassword" class="form-control" placeholder="Password" required>
            </div>

            <button type="submit" name="login" class="btn btn-dark w-100 mb-3">Login</button>
        </form>

        <div class="text-center mt-4">
            <a href="#" class="account-link" onclick="showSection('forgotSection')">Lupa password?</a>
            <span class="mx-2">|</span>
            <a href="#" class="account-link" onclick="showSection('registerSection')">Buat akun</a>
        </div>
    </div>
<?php endif; ?>


                    <!-- =========================
                         REGISTER
                    ========================== -->
                    <div
                        id="registerSection"
                        class="form-section"
                    >

                        <h2 class="fw-bold mb-2">
                            Buat Akun
                        </h2>

                        <p class="text-muted mb-4">
                            Daftar akun baru untuk berbelanja di Cat Shop.
                        </p>

<form action="" method="POST">
    <div class="mb-3">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="nama" class="form-control" placeholder="Nama lengkap" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" placeholder="Email aktif" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password" required>
    </div>

    <button type="submit" name="daftar" class="btn btn-dark w-100 mb-3">Daftar Akun</button>
</form>

                        <div
                            id="registerMsg"
                            class="alert mt-3 d-none"
                        ></div>


                        <div class="text-center mt-4">

                            Sudah punya akun?

                            <a
                                class="account-link"
                                onclick="showSection('loginSection')"
                            >
                                Login
                            </a>

                        </div>

                    </div>


                    <!-- =========================
                         LUPA PASSWORD
                    ========================== -->
                    <div
                        id="forgotSection"
                        class="form-section"
                    >

                        <h2 class="fw-bold mb-2">
                            Lupa Password
                        </h2>

                        <p class="text-muted mb-4">
                            Masukkan email akun kamu untuk memulihkan password.
                        </p>

                        <form onsubmit="forgotPassword(event)">

                            <div class="mb-3">
                                <label class="form-label">
                                    Email
                                </label>

                                <input
                                    id="forgotEmail"
                                    type="email"
                                    class="form-control"
                                    placeholder="nama@email.com"
                                    required
                                >
                            </div>


                            <button
                                type="submit"
                                class="btn btn-dark w-100"
                            >
                                Pulihkan Password
                            </button>

                        </form>


                        <div
                            id="forgotMsg"
                            class="alert mt-3 d-none"
                        ></div>


                        <div class="text-center mt-4">

                            <a
                                class="account-link"
                                onclick="showSection('loginSection')"
                            >
                                Kembali ke Login
                            </a>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </main>


    <!-- =========================
         FOOTER
    ========================== -->
    <footer class="bg-dark text-white py-4">

        <div class="container text-center">
            © 2026 Cat Shop. Semua hak dilindungi.
        </div>

    </footer>


    <!-- =========================
         JAVASCRIPT
    ========================== -->
    <script>

        // =========================
        // GANTI FORM AKUN
        // =========================
        function showSection(sectionId) {

            document.querySelectorAll('.form-section').forEach(function (section) {
                section.classList.remove('active');
            });

            document
                .getElementById(sectionId)
                .classList.add('active');
        }


        // =========================
        // BUAT AKUN
        // =========================
        function registerUser(event) {

            event.preventDefault();

            const name = document.getElementById('registerName').value.trim();
            const email = document.getElementById('registerEmail').value.trim().toLowerCase();
            const phone = document.getElementById('registerPhone').value.trim();
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('registerConfirm').value;


            // Cek password
            if (password !== confirmPassword) {

                showMessage(
                    'registerMsg',
                    'danger',
                    'Password dan konfirmasi password tidak sama.'
                );

                return;
            }


            // Ambil akun yang sudah ada
            const users = JSON.parse(
                localStorage.getItem('catshop_users') || '[]'
            );


            // Cek email sudah terdaftar
            const existingUser = users.find(function (user) {
                return user.email === email;
            });


            if (existingUser) {

                showMessage(
                    'registerMsg',
                    'danger',
                    'Email tersebut sudah terdaftar. Silakan login.'
                );

                return;
            }


            // Simpan akun baru
            users.push({
                name: name,
                email: email,
                phone: phone,
                password: password
            });


            localStorage.setItem(
                'catshop_users',
                JSON.stringify(users)
            );


            showMessage(
                'registerMsg',
                'success',
                'Akun berhasil dibuat! Silakan login menggunakan email dan password kamu.'
            );


            // Kosongkan form
            document.getElementById('registerPassword').value = '';
            document.getElementById('registerConfirm').value = '';
        }


        // =========================
        // LOGIN
        // =========================
        function loginUser(event) {

            event.preventDefault();

            const email = document
                .getElementById('loginEmail')
                .value
                .trim()
                .toLowerCase();

            const password = document.getElementById('loginPassword').value;


            const users = JSON.parse(
                localStorage.getItem('catshop_users') || '[]'
            );


            const user = users.find(function (item) {
                return item.email === email && item.password === password;
            });


            if (!user) {

                showMessage(
                    'loginMsg',
                    'danger',
                    'Email atau password salah.'
                );

                return;
            }


            // Simpan status login
            localStorage.setItem(
                'catshop_logged_in',
                JSON.stringify(user)
            );


            showMessage(
                'loginMsg',
                'success',
                'Login berhasil. Selamat datang, ' + user.name + '!'
            );
        }


        // =========================
        // LUPA PASSWORD
        // =========================
        function forgotPassword(event) {

            event.preventDefault();

            const email = document
                .getElementById('forgotEmail')
                .value
                .trim()
                .toLowerCase();


            const users = JSON.parse(
                localStorage.getItem('catshop_users') || '[]'
            );


            const user = users.find(function (item) {
                return item.email === email;
            });


            if (!user) {

                showMessage(
                    'forgotMsg',
                    'danger',
                    'Email belum terdaftar di Cat Shop.'
                );

                return;
            }


            showMessage(
                'forgotMsg',
                'success',
                'Akun ditemukan. Untuk versi demo ini, silakan gunakan password yang kamu daftarkan sebelumnya.'
            );
        }


        // =========================
        // PESAN NOTIFIKASI
        // =========================
        function showMessage(elementId, type, message) {

            const element = document.getElementById(elementId);

            element.className = 'alert alert-' + type + ' mt-3';
            element.textContent = message;
        }

    </script>

</body>

</html>
