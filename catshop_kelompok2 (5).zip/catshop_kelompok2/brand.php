<!doctype html>
<html lang="id">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Brand - Cat Shop</title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>

        body {
            font-family: Arial, Helvetica, sans-serif;
            color: #222;
            background: #fff;
        }

        /* TOPBAR */

        .topbar {
            height: 36px;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }

        .topbar a {
            color: #666;
            text-decoration: none;
        }

        /* HEADER */

        .header {
            min-height: 145px;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
        }

        .logo {
            text-decoration: none;
        }

        .brand-logo {
            font-size: 31px;
            font-weight: 800;
            color: #111;
        }

        .tag {
            font-size: 10px;
            color: #777;
        }

        .search {
            height: 40px;
            background: #f2f2f2;
            border: 0;
            border-radius: 24px;
            padding-left: 18px;
            width: 100%;
        }

        .icons {
            font-size: 21px;
            display: flex;
            gap: 20px;
            justify-content: end;
        }

        .icons a {
            color: #111;
            text-decoration: none;
        }

        /* NAVBAR */

        .nav-wrap {
            border-bottom: 1px solid #ddd;
            min-height: 45px;
        }

        .nav {
            min-height: 45px;
            display: flex;
            align-items: center;
            gap: 25px;
            overflow-x: auto;
        }

        .nav a {
            font-size: 12px;
            font-weight: 700;
            color: #111;
            text-decoration: none;
            white-space: nowrap;
        }

        .nav a:hover {
            color: #16bde8;
        }

        /* HERO */

        .hero {
            min-height: 300px;

            background:
                linear-gradient(
                    90deg,
                    rgba(0, 0, 0, .65),
                    rgba(0, 0, 0, .2)
                ),
                url("https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1800&q=85")
                center / cover;

            display: flex;
            align-items: center;

            color: white;
        }

        .hero h1 {
            font-size: 46px;
            font-weight: 800;
        }

        /* BRAND SECTION */

        .brand-section {
            padding: 65px 0;
        }

        .section-title {
            font-size: 30px;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .section-description {
            color: #777;
            margin-bottom: 40px;
        }

        /* BRAND CARD */

        .brand-card {
            display: block;

            height: 150px;

            border: 1px solid #e5e5e5;
            border-radius: 8px;

            text-decoration: none;
            color: #222;

            background: white;

            display: flex;
            align-items: center;
            justify-content: center;

            transition: .25s;

            box-shadow: 0 3px 12px rgba(0, 0, 0, .05);
        }

        .brand-card:hover {
            transform: translateY(-5px);

            box-shadow:
                0 10px 25px rgba(0, 0, 0, .12);

            border-color: #16bde8;
        }

        .brand-card h4 {
            font-size: 20px;
            font-weight: 800;
            margin: 0;
        }

        .brand-card p {
            font-size: 12px;
            color: #777;
            margin-top: 8px;
            margin-bottom: 0;
        }

        .brand-icon {
            font-size: 35px;
            margin-bottom: 10px;
            color: #16bde8;
        }

        /* FOOTER */

        footer {
            border-top: 1px solid #eee;
            padding: 40px 0;
            color: #666;
            font-size: 13px;
        }

        /* MOBILE */

        @media (max-width: 767px) {

            .hero h1 {
                font-size: 35px;
            }

            .header {
                min-height: auto;
                padding: 25px 0;
            }

            .search {
                margin: 20px 0;
            }

            .icons {
                justify-content: start;
            }

        }

    </style>

</head>


<body>


    <!-- TOPBAR -->

    <div class="topbar d-flex align-items-center">

        <div class="container d-flex justify-content-between">

            <div>

                <a href="index.php">

                    <i class="bi bi-house me-1"></i>

                    Cat Shop

                </a>

                <span class="mx-3">
                    Order Tracking
                </span>

            </div>

            <b>
                CAT SHOP
            </b>

        </div>

    </div>


    <!-- HEADER -->

    <header class="header">

        <div class="container">

            <div class="row align-items-center">

                <!-- LOGO -->

                <div class="col-md-3">

                    <a
                        href="index.php"
                        class="logo"
                    >

                        <div class="brand-logo">
                            CAT SHOP
                        </div>

                        <div class="tag">
                            Pusat Kebutuhan Kucing Terlengkap
                        </div>

                    </a>

                </div>


                <!-- SEARCH -->

                <div class="col-md-6">

                    <input
                        type="text"
                        class="search"
                        placeholder="Search products..."
                    >

                </div>


                <!-- ICON -->

                <div class="col-md-3">

                    <div class="icons">

                        <a href="akun.php">
                            <i class="bi bi-person"></i>
                        </a>

                        <a href="wishlist.php">
                            <i class="bi bi-heart"></i>
                        </a>

                        <a href="keranjang.php">
                            <i class="bi bi-cart3"></i>
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </header>


    <!-- NAVBAR -->

    <div class="nav-wrap">

        <div class="container">

            <nav class="nav">

                <a href="index.php">
                    BERANDA
                </a>

                <a href="our_story.php">
                    OUR STORY
                </a>

                <a href="our_channel.php">
                    OUR CHANNEL
                </a>

                <a href="our_leaders.php">
                    OUR LEADERS
                </a>

                <a href="our_veterinarian.php">
                    OUR VETERINARIAN
                </a>

                <a href="brand.php">
                    BRAND
                </a>

                <a href="blog.php">
                    BLOG
                </a>

                <a href="toko_terdekat.php">
                    TOKO TERDEKAT
                </a>

                <a href="link.php">
                    LINK
                </a>

                <a href="karir.php">
                    KARIR
                </a>

            </nav>

        </div>

    </div>


    <!-- HERO -->

    <section class="hero">

        <div class="container">

            <small>
                CAT SHOP
            </small>

            <h1>
                Brand
            </h1>

            <p class="lead">
                Pilihan brand terbaik untuk kebutuhan kucing.
            </p>

        </div>

    </section>


    <!-- BRAND -->

    <section class="brand-section">

        <div class="container">

            <h2 class="section-title">
                Brand Kucing
            </h2>

            <p class="section-description">
                Pilih brand untuk melihat produk yang tersedia di Cat Shop.
            </p>


            <div class="row g-4">


                <!-- ROYAL CANIN -->

                <div class="col-6 col-md-4 col-lg-3">

                    <a
                        href="makanan_kucing.php?brand=Royal%20Canin"
                        class="brand-card"
                    >

                        <div class="text-center">

                            <div class="brand-icon">
                                <i class="bi bi-heart-fill"></i>
                            </div>

                            <h4>
                                Royal Canin
                            </h4>

                            <p>
                                Lihat produk
                            </p>

                        </div>

                    </a>

                </div>


                <!-- PRO PLAN -->

                <div class="col-6 col-md-4 col-lg-3">

                    <a
                        href="makanan_kucing.php?brand=Pro%20Plan"
                        class="brand-card"
                    >

                        <div class="text-center">

                            <div class="brand-icon">
                                <i class="bi bi-heart-fill"></i>
                            </div>

                            <h4>
                                Pro Plan
                            </h4>

                            <p>
                                Lihat produk
                            </p>

                        </div>

                    </a>

                </div>


                <!-- KITCHEN FLAVOR -->

                <div class="col-6 col-md-4 col-lg-3">

                    <a
                        href="makanan_kucing.php?brand=Kitchen%20Flavor"
                        class="brand-card"
                    >

                        <div class="text-center">

                            <div class="brand-icon">
                                <i class="bi bi-heart-fill"></i>
                            </div>

                            <h4>
                                Kitchen Flavor
                            </h4>

                            <p>
                                Lihat produk
                            </p>

                        </div>

                    </a>

                </div>


                <!-- WHISKAS -->

                <div class="col-6 col-md-4 col-lg-3">

                    <a
                        href="makanan_kucing.php?brand=Whiskas"
                        class="brand-card"
                    >

                        <div class="text-center">

                            <div class="brand-icon">
                                <i class="bi bi-heart-fill"></i>
                            </div>

                            <h4>
                                Whiskas
                            </h4>

                            <p>
                                Lihat produk
                            </p>

                        </div>

                    </a>

                </div>


                <!-- Kitchen Flavor -->

                <div class="col-6 col-md-4 col-lg-3">

                    <a
                        href="makanan_kucing.php?brand=Kitchen Flavor"
                        class="brand-card"
                    >

                        <div class="text-center">

                            <div class="brand-icon">
                                <i class="bi bi-heart-fill"></i>
                            </div>

                            <h4>
                                Kitchen Flavor
                            </h4>

                            <p>
                                Lihat produk
                            </p>

                        </div>

                    </a>

                </div>


                <!-- ME-O -->

                <div class="col-6 col-md-4 col-lg-3">

                    <a
                        href="makanan_kucing.php?brand=Me-O"
                        class="brand-card"
                    >

                        <div class="text-center">

                            <div class="brand-icon">
                                <i class="bi bi-heart-fill"></i>
                            </div>

                            <h4>
                                Me-O
                            </h4>

                            <p>
                                Lihat produk
                            </p>

                        </div>

                    </a>

                </div>


            </div>

        </div>

    </section>


    <!-- FOOTER -->

    <footer>

        <div class="container">

            <div class="row">

                <div class="col-md-4">

                    <b class="text-dark">
                        CAT SHOP
                    </b>

                    <br>

                    Pusat kebutuhan kucing terlengkap.

                </div>

                <div class="col-md-4">

                    WhatsApp:
                    0857-1932-3258

                </div>

                <div class="col-md-4">

                    Copyright © 2026 Cat Shop.

                </div>

            </div>

        </div>

    </footer>


</body>

</html>