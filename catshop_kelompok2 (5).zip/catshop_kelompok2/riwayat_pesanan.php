<?php
session_start();
include 'koneksi.php';

// Jika belum login, alihkan ke halaman login
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location='akun.php';</script>";
    exit();
}

$id_user = $_SESSION['user_id'];
$no_wa_penjual = "6285719323258";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light py-5">

    <div class="container bg-white p-4 rounded shadow-sm">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-bold m-0">📦 Riwayat Pesanan Saya</h3>
            <a href="index.php" class="btn btn-outline-secondary btn-sm">← Kembali ke Beranda</a>
        </div>

        <table class="table table-bordered table-striped align-middle">
<thead class="table-dark">
    <tr>
        <th>No</th>
        <th>ID Pesanan</th>
        <th>Tanggal</th>
        <th>Total Belanja</th>
        <th>Kurir & Pembayaran</th>
        <th class="text-center">Status</th> <!-- Tambahkan baris ini di antara Kurir dan Aksi -->
        <th class="text-center">Aksi</th>
    </tr>
</thead>
            <tbody>
                <?php
                $nomor = 1;
                $ambil = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id_user = '$id_user' ORDER BY id_pesanan DESC");
                while($pecah = mysqli_fetch_assoc($ambil)){
                    $kode_inv = "#INV-00" . $pecah['id_pesanan'];
                    $total_rp = "Rp " . number_format($pecah['total_belanja'], 0, ',', '.');
                    $status_pesanan = isset($pecah['status']) ? $pecah['status'] : 'Menunggu Konfirmasi';
                    $pesan_wa = "Halo Admin CatShop, saya ingin konfirmasi / kirim bukti pembayaran pesanan:\n"
                              . "No. Faktur: " . $kode_inv . "\n"
                              . "Tanggal: " . $pecah['tanggal'] . "\n"
                              . "Total Belanja: " . $total_rp . "\n"
                              . "Kurir: " . $pecah['kurir'] . "\n"
                              . "Metode Pembayaran: " . $pecah['metode_pembayaran'] . "\n"
                              . "Status: " . $status_pesanan;
                    $link_wa = "https://wa.me/" . $no_wa_penjual . "?text=" . rawurlencode($pesan_wa);
                ?>
<tr>
    <td><?php echo $nomor++; ?></td>
    <td><strong>#INV-00<?php echo $pecah['id_pesanan']; ?></strong></td>
    <td><?php echo $pecah['tanggal']; ?></td>
    <td>Rp <?php echo number_format($pecah['total_belanja'], 0, ',', '.'); ?></td>
    <td>
        <small class="d-block text-muted">Kurir: <?php echo $pecah['kurir']; ?></small>
        <small class="d-block text-primary fw-bold">Metode: <?php echo $pecah['metode_pembayaran']; ?></small>
    </td>
    
    <!-- Kolom Status Pesanan -->
    <td class="text-center">
        <span class="badge bg-info text-dark"><?php echo isset($pecah['status']) ? $pecah['status'] : 'Menunggu Konfirmasi'; ?></span>
    </td>

    <!-- Kolom Aksi -->
    <td class="text-center">
        <a href="nota.php?id=<?php echo $pecah['id_pesanan']; ?>" class="btn btn-dark btn-sm mb-1">Nota</a>
        <a href="<?php echo $link_wa; ?>" target="_blank" rel="noopener noreferrer" class="btn btn-outline-success btn-sm mb-1">Chat WA</a>
        
        <?php 
        // Tombol Konfirmasi Pembayaran untuk non-COD
        if ($pecah['metode_pembayaran'] != 'COD (Cash on Delivery)') { 
            $id_p = $pecah['id_pesanan'];
            $cek_konfirm = mysqli_query($koneksi, "SELECT * FROM konfirmasi WHERE id_pesanan = '$id_p'");
            if (mysqli_num_rows($cek_konfirm) > 0) {
                echo '<span class="badge bg-success d-block mb-1">Sudah Konfirmasi</span>';
            } else {
                echo '<a href="konfirmasi_pembayaran.php?id='.$pecah['id_pesanan'].'" class="btn btn-success btn-sm mb-1">Konfirmasi</a>';
            }
        } 

        // Tombol Pesanan Diterima jika status sudah Dalam Pengiriman
        if (isset($pecah['status']) && $pecah['status'] == 'Dalam Pengiriman') {
        ?>
            <a href="terima_pesanan.php?id=<?php echo $pecah['id_pesanan']; ?>" class="btn btn-primary btn-sm" onclick="return confirm('Pastikan pesanan sudah diterima dengan baik. Selesaikan pesanan?')">Pesanan Diterima</a>
        <?php } ?>
    </td>
</tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>
</html>