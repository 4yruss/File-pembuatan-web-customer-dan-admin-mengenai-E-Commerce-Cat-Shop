<?php
session_start();
include 'koneksi.php';

// Jika belum login, alihkan ke halaman akun
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location='akun.php';</script>";
    exit();
}

$id_pesanan = isset($_GET['id']) ? $_GET['id'] : '';

// Ambil data pesanan berdasarkan ID
$ambil = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id_pesanan = '$id_pesanan'");
$det = mysqli_fetch_assoc($ambil);

if (!$det) {
    echo "<script>alert('Pesanan tidak ditemukan!'); window.location='riwayat_pesanan.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pembayaran - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light py-5">
    <div class="container bg-white p-4 rounded shadow-sm" style="max-width: 600px;">
        <h3 class="fw-bold mb-3">💳 Konfirmasi Pembayaran</h3>
        <p class="text-muted">Kirimkan bukti transfer untuk pesanan <strong>#INV-00<?php echo $det['id_pesanan']; ?></strong></p>
        
        <div class="alert alert-info">
            Total yang harus dibayar: <strong>Rp <?php echo number_format($det['total_belanja'], 0, ',', '.'); ?></strong>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label">Nama Penyetor / Pemilik Rekening</label>
                <input type="text" name="nama" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Bank Asal / Tujuan Transfer</label>
                <input type="text" name="bank" class="form-control" placeholder="Contoh: BCA / Mandiri" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Jumlah Transfer (Rp)</label>
                <input type="number" name="jumlah" class="form-control" value="<?php echo $det['total_belanja']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Upload Bukti Transfer (Foto / Screenshot)</label>
                <input type="file" name="bukti" class="form-control" accept="image/*" required>
            </div>
            <div class="d-flex justify-content-between">
                <a href="riwayat_pesanan.php" class="btn btn-outline-secondary">Kembali</a>
                <button type="submit" name="kirim" class="btn btn-dark">Kirim Konfirmasi</button>
            </div>
        </form>

        <?php
        if (isset($_POST['kirim'])) {
            $nama = $_POST['nama'];
            $bank = $_POST['bank'];
            $jumlah = $_POST['jumlah'];
            
            $nama_bukti = $_FILES['bukti']['name'];
            $lokasi_bukti = $_FILES['bukti']['tmp_name'];
            $dir = "img/";
            
            // Buat direktori jika belum ada
            if (!file_exists($dir)) {
                mkdir($dir, 0777, true);
            }
            
            $nama_file_unik = date('YmdHis') . '_' . $nama_bukti;
            move_uploaded_file($lokasi_bukti, $dir . $nama_file_unik);

            // Simpan data konfirmasi ke database
            $query_konfirmasi = "INSERT INTO konfirmasi (id_pesanan, nama, bank, jumlah, bukti) VALUES ('$id_pesanan', '$nama', '$bank', '$jumlah', '$nama_file_unik')";
            $simpan_konfirmasi = mysqli_query($koneksi, $query_konfirmasi);

            if ($simpan_konfirmasi) {
                echo "<script>alert('Konfirmasi pembayaran berhasil dikirim! Terima kasih.'); window.location='riwayat_pesanan.php';</script>";
            } else {
                echo "<script>alert('Gagal mengirim konfirmasi, silakan coba lagi.');</script>";
            }
        }
        ?>
    </div>
</body>
</html>