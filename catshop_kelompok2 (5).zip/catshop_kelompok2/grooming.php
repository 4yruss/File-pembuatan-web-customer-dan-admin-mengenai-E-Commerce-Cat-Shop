<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grooming Kucing - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            color: #222;
        }

        .topbar {
            height: 36px;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }

        .topbar a {
            color: #666;
            text-decoration: none;
        }

        .header {
            min-height: 145px;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
        }

        .logo {
            text-decoration: none;
        }

        .brand {
            font-size: 31px;
            font-weight: 800;
            color: #111;
        }

        .tag {
            font-size: 10px;
            color: #777;
        }

        .search {
            height: 40px;
            background: #f2f2f2;
            border: 0;
            border-radius: 24px;
            padding-left: 18px;
            width: 100%;
        }

        .icons {
            font-size: 21px;
            display: flex;
            gap: 20px;
            justify-content: end;
        }

        .icons a {
            color: #111;
        }

        .nav-wrap {
            border-bottom: 1px solid #ddd;
            min-height: 45px;
        }

        .nav {
            min-height: 45px;
            display: flex;
            align-items: center;
            gap: 25px;
            overflow: auto;
        }

        .nav a {
            font-size: 12px;
            font-weight: 700;
            color: #111;
            text-decoration: none;
            white-space: nowrap;
        }

        .nav a:hover {
            color: #16bde8;
        }

        .hero {
            min-height: 390px;
            background:
                linear-gradient(90deg, rgba(0,0,0,.68), rgba(0,0,0,.20)),
                url('https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1800&q=85') center/cover;
            display: flex;
            align-items: center;
            color: #fff;
        }

        .hero h1 {
            font-size: 52px;
            font-weight: 800;
        }

        .hero p {
            max-width: 650px;
            font-size: 18px;
        }

        .section {
            padding: 65px 0;
        }

        .section-title {
            font-size: 30px;
            font-weight: 800;
            margin-bottom: 15px;
        }

        .section-subtitle {
            color: #666;
            max-width: 750px;
            margin: 0 auto 40px;
        }

        .problem-box,
        .service-card,
        .reason-card {
            height: 100%;
            border: 1px solid #eee;
            border-radius: 12px;
            padding: 28px;
            background: #fff;
            box-shadow: 0 4px 16px rgba(0,0,0,.06);
        }

        .problem-box i,
        .service-card i,
        .reason-card i {
            font-size: 36px;
            color: #16bde8;
        }

        .service-card {
            text-align: center;
            transition: .2s;
        }

        .service-card:hover {
            transform: translateY(-5px);
        }

        .service-card h4 {
            font-weight: 800;
            margin-top: 18px;
        }

        .benefit-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .benefit-list li {
            margin-bottom: 13px;
        }

        .benefit-list i {
            color: #16bde8;
            margin-right: 8px;
        }

        .gallery img {
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 12px;
        }

        .cta {
            background: #111;
            color: #fff;
            border-radius: 16px;
            padding: 45px;
        }

        .cta .btn {
            background: #16bde8;
            border: 0;
            color: #fff;
            font-weight: 700;
            padding: 12px 24px;
            border-radius: 25px;
        }

        footer {
            background: #111;
            color: #ddd;
            padding: 55px 0 20px;
            font-size: 14px;
        }

        .footer-title {
            color: #fff;
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 18px;
        }

        .footer-logo {
            color: #fff;
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -1px;
            margin-bottom: 12px;
        }

        .footer-text {
            color: #aaa;
            line-height: 1.8;
        }

        .footer-links {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: #aaa;
            text-decoration: none;
            transition: .2s;
        }

        .footer-links a:hover {
            color: #16bde8;
        }

        .footer-contact {
            color: #aaa;
            line-height: 1.9;
        }

        .footer-contact i {
            color: #16bde8;
            width: 22px;
        }

        .footer-social a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            margin-right: 7px;
            border: 1px solid #444;
            border-radius: 50%;
            color: #fff;
            text-decoration: none;
            transition: .2s;
        }

        .footer-social a:hover {
            background: #16bde8;
            border-color: #16bde8;
        }

        .footer-bottom {
            border-top: 1px solid #333;
            margin-top: 35px;
            padding-top: 20px;
            color: #888;
            font-size: 13px;
        }

        @media(max-width: 767px) {
            .hero h1 {
                font-size: 38px;
            }

            .hero {
                min-height: 330px;
            }
        }
    </style>
</head>
<body>

    <div class="topbar d-flex align-items-center">
        <div class="container d-flex justify-content-between">
            <div>
                <a href="index.php">
                    <i class="bi bi-house me-1"></i>Cat Shop
                </a>
                <span class="mx-3">Order Tracking</span>
            </div>
            <b>CAT SHOP</b>
        </div>
    </div>

    <header class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <a href="index.php" class="logo">
                        <div class="brand">CAT SHOP</div>
                        <div class="tag">Pusat Kebutuhan Kucing Terlengkap</div>
                    </a>
                </div>

                <div class="col-md-6">
                    <input class="search" placeholder="Search products...">
                </div>

                <div class="col-md-3">
                    <div class="icons">
                        <a href="#"><i class="bi bi-person"></i></a>
                        <a href="#"><i class="bi bi-heart"></i></a>
                        <a href="shop.php"><i class="bi bi-cart3"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="nav-wrap">
        <div class="container">
            <nav class="nav">
                <a href="index.php">BERANDA</a>
                <a href="our_story.php">OUR STORY</a>
                <a href="our_channel.php">OUR CHANNEL</a>
                <a href="our_leaders.php">OUR LEADERS</a>
                <a href="our_veterinarian.php">OUR VETERINARIAN</a>
                <a href="brand.php">BRAND</a>
                <a href="blog.php">BLOG</a>
                <a href="toko_terdekat.php">TOKO TERDEKAT</a>
                <a href="link.php">LINK</a>
                <a href="karir.php">KARIR</a>
            </nav>
        </div>
    </div>

    <!-- HERO -->
    <section class="hero">
        <div class="container">
            <small class="fw-bold">CAT SHOP GROOMING SERVICES</small>
            <h1>Grooming Kucing</h1>
            <p class="lead mb-4">
                Rawat kebersihan, kesehatan, dan kenyamanan kucing kesayanganmu
                dengan layanan grooming khusus kucing dari Cat Shop.
            </p>
            <a href="https://wa.me/6285719323258" class="btn btn-info text-white fw-bold rounded-pill px-4 py-2">
                <i class="bi bi-whatsapp me-2"></i>Booking Grooming
            </a>
        </div>
    </section>

    <!-- MASALAH -->
    <section class="section bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Kucing Kamu Mengalami Ini?</h2>
                <p class="section-subtitle">
                    Grooming bukan hanya membuat kucing terlihat bersih, tetapi juga membantu menjaga kenyamanan dan kebersihan tubuhnya.
                </p>
            </div>

            <div class="row g-4">
                <div class="col-md-3">
                    <div class="problem-box text-center">
                        <i class="bi bi-droplet-half"></i>
                        <h5 class="fw-bold mt-3">Bulu Kotor</h5>
                        <p class="text-muted mb-0">Bulu terkena debu, tanah, atau kotoran.</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="problem-box text-center">
                        <i class="bi bi-scissors"></i>
                        <h5 class="fw-bold mt-3">Bulu Gimbal</h5>
                        <p class="text-muted mb-0">Bulu kusut, menggumpal, dan sulit dirapikan.</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="problem-box text-center">
                        <i class="bi bi-emoji-frown"></i>
                        <h5 class="fw-bold mt-3">Kuku Panjang</h5>
                        <p class="text-muted mb-0">Kuku perlu dipotong dan dirapikan secara rutin.</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="problem-box text-center">
                        <i class="bi bi-clock"></i>
                        <h5 class="fw-bold mt-3">Tidak Punya Waktu?</h5>
                        <p class="text-muted mb-0">Serahkan perawatan kucing kepada groomer kami.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- LAYANAN -->
    <section class="section">
        <div class="container">
            <div class="text-center">
                <h2 class="section-title">Grooming Services</h2>
                <p class="section-subtitle">
                    Pilih perawatan yang sesuai dengan kebutuhan kucingmu.
                </p>
            </div>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="service-card">
                        <i class="bi bi-droplet"></i>
                        <h4>Basic Grooming</h4>
                        <p class="text-muted">
                            Perawatan dasar untuk membantu membuat kucing lebih bersih, segar, dan nyaman.
                        </p>
                        <ul class="benefit-list text-start mt-4">
                            <li><i class="bi bi-check-circle-fill"></i>Mandi & shampoo</li>
                            <li><i class="bi bi-check-circle-fill"></i>Pengeringan bulu</li>
                            <li><i class="bi bi-check-circle-fill"></i>Potong kuku</li>
                            <li><i class="bi bi-check-circle-fill"></i>Bersihkan telinga</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="service-card">
                        <i class="bi bi-stars"></i>
                        <h4>Mix Grooming</h4>
                        <p class="text-muted">
                            Grooming dasar dengan tambahan perawatan yang disesuaikan dengan kondisi bulu kucing.
                        </p>
                        <ul class="benefit-list text-start mt-4">
                            <li><i class="bi bi-check-circle-fill"></i>Basic Grooming</li>
                            <li><i class="bi bi-check-circle-fill"></i>Perawatan bulu</li>
                            <li><i class="bi bi-check-circle-fill"></i>Pembersihan area sensitif</li>
                            <li><i class="bi bi-check-circle-fill"></i>Rapikan bulu</li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="service-card">
                        <i class="bi bi-heart-fill"></i>
                        <h4>Complete Grooming</h4>
                        <p class="text-muted">
                            Perawatan lebih lengkap untuk kucing yang membutuhkan perhatian ekstra.
                        </p>
                        <ul class="benefit-list text-start mt-4">
                            <li><i class="bi bi-check-circle-fill"></i>Basic Grooming</li>
                            <li><i class="bi bi-check-circle-fill"></i>Perawatan bulu lengkap</li>
                            <li><i class="bi bi-check-circle-fill"></i>Potong & rapikan bulu</li>
                            <li><i class="bi bi-check-circle-fill"></i>Perawatan kebersihan kucing</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- BENEFIT -->
    <section class="section bg-light">
        <div class="container">
            <div class="row align-items-center g-5">
                <div class="col-md-6">
                    <img
                        src="https://images.unsplash.com/photo-1574158622682-e40e69881006?auto=format&fit=crop&w=1000&q=85"
                        class="img-fluid rounded-4 shadow"
                        alt="Kucing setelah grooming"
                    >
                </div>

                <div class="col-md-6">
                    <h2 class="section-title">Apa Saja yang Didapat?</h2>
                    <p class="text-muted mb-4">
                        Setiap sesi grooming dilakukan dengan memperhatikan kenyamanan kucing.
                    </p>

                    <ul class="benefit-list">
                        <li><i class="bi bi-check-circle-fill"></i>Membersihkan bulu dan tubuh kucing</li>
                        <li><i class="bi bi-check-circle-fill"></i>Potong kuku</li>
                        <li><i class="bi bi-check-circle-fill"></i>Pembersihan telinga</li>
                        <li><i class="bi bi-check-circle-fill"></i>Perapian bulu paw dan area belakang</li>
                        <li><i class="bi bi-check-circle-fill"></i>Pengeringan dan perapian bulu</li>
                        <li><i class="bi bi-check-circle-fill"></i>Perawatan dilakukan dengan hati-hati</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- BEFORE AFTER -->
    <section class="section">
        <div class="container">
            <div class="text-center">
                <h2 class="section-title">Before & After Grooming</h2>
                <p class="section-subtitle">
                    Contoh perubahan tampilan kucing setelah mendapatkan perawatan grooming.
                </p>
            </div>

            <div class="row g-4 gallery">
                <div class="col-md-6">
                    <img src="https://images.unsplash.com/photo-1511044568932-338cba0ad803?auto=format&fit=crop&w=1000&q=85" alt="Kucing sebelum grooming">
                    <h5 class="fw-bold mt-3">Sebelum Grooming</h5>
                </div>

                <div class="col-md-6">
                    <img src="https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop&w=1000&q=85" alt="Kucing setelah grooming">
                    <h5 class="fw-bold mt-3">Setelah Grooming</h5>
                </div>
            </div>
        </div>
    </section>

    <!-- ALASAN -->
    <section class="section bg-light">
        <div class="container">
            <div class="text-center">
                <h2 class="section-title">Kenapa Grooming di Cat Shop?</h2>
                <p class="section-subtitle">
                    Kami fokus memberikan pengalaman grooming yang nyaman untuk kucing.
                </p>
            </div>

            <div class="row g-4">
                <div class="col-md-3">
                    <div class="reason-card text-center">
                        <i class="bi bi-heart-fill"></i>
                        <h5 class="fw-bold mt-3">Penyayang Kucing</h5>
                        <p class="text-muted mb-0">Kucing diperlakukan dengan lembut selama proses grooming.</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="reason-card text-center">
                        <i class="bi bi-person-badge"></i>
                        <h5 class="fw-bold mt-3">Groomer Profesional</h5>
                        <p class="text-muted mb-0">Perawatan dilakukan dengan prosedur grooming yang teratur.</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="reason-card text-center">
                        <i class="bi bi-shield-check"></i>
                        <h5 class="fw-bold mt-3">Produk Aman</h5>
                        <p class="text-muted mb-0">Produk perawatan dipilih dengan mempertimbangkan kebutuhan kucing.</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="reason-card text-center">
                        <i class="bi bi-house-heart"></i>
                        <h5 class="fw-bold mt-3">Nyaman</h5>
                        <p class="text-muted mb-0">Kami mengutamakan kenyamanan kucing selama perawatan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="section">
        <div class="container">
            <div class="cta text-center">
                <h2 class="fw-bold mb-3">Kucingmu Sudah Waktunya Grooming?</h2>
                <p class="mb-4">
                    Hubungi Cat Shop untuk menanyakan jadwal dan layanan grooming kucing.
                </p>
                <a href="https://wa.me/6285719323258" class="btn">
                    <i class="bi bi-whatsapp me-2"></i>Tanya via WhatsApp
                </a>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer>
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-logo">CAT SHOP</div>
                    <p class="footer-text mb-4">
                        Pusat kebutuhan kucing yang menyediakan produk dan layanan
                        untuk membantu kucing tetap sehat, bersih, nyaman, dan bahagia.
                    </p>
                    <div class="footer-social">
                        <a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                        <a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
                        <a href="https://wa.me/6285719323258" aria-label="WhatsApp"><i class="bi bi-whatsapp"></i></a>
                    </div>
                </div>

                <div class="col-lg-2 col-md-6">
                    <div class="footer-title">Cat Shop</div>
                    <ul class="footer-links">
                        <li><a href="index.php">Beranda</a></li>
                        <li><a href="our_story.php">Tentang Kami</a></li>
                        <li><a href="brand.php">Brand</a></li>
                        <li><a href="blog.php">Blog</a></li>
                        <li><a href="toko_terdekat.php">Toko Terdekat</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="footer-title">Layanan</div>
                    <ul class="footer-links">
                        <li><a href="shop.php">Shop</a></li>
                        <li><a href="grooming.php">Grooming</a></li>
                        <li><a href="klinik.php">Klinik Kucing</a></li>
                        <li><a href="hotel.php">Hotel Kucing</a></li>
                        <li><a href="pelatihan.php">Pelatihan</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="footer-title">Hubungi Kami</div>
                    <div class="footer-contact">
                        <div><i class="bi bi-whatsapp"></i>0857-1932-3258</div>
                        <div><i class="bi bi-envelope"></i>info@catshop.com</div>
                        <div><i class="bi bi-geo-alt"></i>Indonesia</div>
                        <div><i class="bi bi-clock"></i>Setiap Hari, 09.00 - 21.00</div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom d-flex justify-content-between flex-wrap gap-2">
                <div>© 2026 Cat Shop. All Rights Reserved.</div>
                <div>Website Cat Shop</div>
            </div>
        </div>
    </footer>

</body>
</html>
