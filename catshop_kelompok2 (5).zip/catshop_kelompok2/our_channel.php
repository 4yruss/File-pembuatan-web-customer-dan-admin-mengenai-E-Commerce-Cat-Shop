<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Our Channel - Cat Shop</title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            color: #222;
        }

        .topbar {
            height: 36px;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }

        .topbar a {
            color: #666;
            text-decoration: none;
        }

        .main-header {
            min-height: 145px;
            border-bottom: 1px solid #ddd;
        }

        .logo {
            text-decoration: none;
        }

        .brand {
            font-size: 31px;
            font-weight: 800;
            color: #16bde8;
        }

        .tag {
            font-size: 10px;
            color: #777;
        }

        .search {
            height: 40px;
            background: #f2f2f2;
            border-radius: 24px;
            border: 0;
            padding-left: 18px;
            width: 100%;
        }

        .icons {
            font-size: 21px;
            display: flex;
            gap: 20px;
            justify-content: end;
        }

        .icons a {
            color: #111;
        }

        .nav-wrap {
            border-bottom: 1px solid #ddd;
            height: 45px;
        }

        .nav {
            height: 100%;
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .nav a {
            font-size: 12px;
            font-weight: 700;
            color: #111;
            text-decoration: none;
        }

        .nav a:hover {
            color: #16bde8;
        }

        .hero {
            background:
                linear-gradient(
                    90deg,
                    rgba(0, 0, 0, .65),
                    rgba(0, 0, 0, .2)
                ),
                url('https://images.unsplash.com/photo-1511044568932-338cba0ad803?auto=format&fit=crop&w=1800&q=85')
                center/cover;

            height: 350px;
            display: flex;
            align-items: center;
            color: #fff;
        }

        .hero h1 {
            font-size: 46px;
            font-weight: 800;
        }

        .section {
            padding: 65px 0;
        }

        .cardx {
            border: 1px solid #eee;
            padding: 30px;
            height: 100%;
            box-shadow: 0 3px 12px rgba(0, 0, 0, .06);
        }

        .icon {
            font-size: 42px;
            color: #16bde8;
        }

        footer {
            border-top: 1px solid #eee;
            padding: 40px 0;
            color: #666;
            font-size: 13px;
        }

        @media (max-width: 767px) {
            .nav {
                overflow: auto;
                gap: 15px;
            }

            .hero h1 {
                font-size: 35px;
            }
        }
    </style>
</head>

<body>

    <!-- TOP BAR -->
    <div class="topbar d-flex align-items-center">
        <div class="container d-flex justify-content-between">

            <div>
                <a href="index.php">
                    <i class="bi bi-house me-1"></i>
                    Cat Shop
                </a>

                <span class="mx-3">
                    Order Tracking
                </span>
            </div>

            <b>
                CAT SHOP
            </b>

        </div>
    </div>


    <!-- HEADER -->
    <header class="main-header d-flex align-items-center">
        <div class="container">

            <div class="row align-items-center">

                <!-- LOGO -->
                <div class="col-md-3">

                    <a href="index.php" class="logo">

                        <div class="brand">
                            CAT SHOP
                        </div>

                        <div class="tag">
                            Pusat Kebutuhan Kucing Terlengkap
                        </div>

                    </a>

                </div>


                <!-- SEARCH -->
                <div class="col-md-6">

                    <input
                        class="search"
                        placeholder="Search products..."
                    >

                </div>


                <!-- ICONS -->
                <div class="col-md-3">

                    <div class="icons">

                        <a href="#">
                            <i class="bi bi-person"></i>
                        </a>

                        <a href="#">
                            <i class="bi bi-heart"></i>
                        </a>

                        <a href="#">
                            <i class="bi bi-cart3"></i>
                        </a>

                    </div>

                </div>

            </div>

        </div>
    </header>


    <!-- NAVBAR -->
    <div class="nav-wrap">
        <div class="container">

            <nav class="nav">

                <a href="index.php">
                    BERANDA
                </a>

                <a href="our_story.php">
                    OUR STORY
                </a>

                <a href="our_channel.php">
                    OUR CHANNEL
                </a>

                <a href="our_leaders.php">
                    OUR LEADERS
                </a>

                <a href="our_veterinarian.php">
                    OUR VETERINARIAN
                </a>

            </nav>

        </div>
    </div>


    <!-- HERO -->
    <section class="hero">

        <div class="container">

            <small>
                CHANNEL CAT SHOP
            </small>

            <h1>
                Our Channel
            </h1>

            <p class="lead">
                Konten dan informasi seputar dunia kucing
                untuk membantu Cat Lovers merawat kucing
                dengan lebih baik.
            </p>

        </div>

    </section>


    <!-- CONTENT -->
    <section class="section">

        <div class="container">

            <div class="row g-4">

                <!-- VIDEO KUCING -->
                <div class="col-md-4">

                    <div class="cardx">

                        <i class="bi bi-youtube icon"></i>

                        <h3 class="mt-3">
                            Video Kucing
                        </h3>

                        <p>
                            Tips perawatan, makanan, grooming,
                            kesehatan, dan aktivitas kucing.
                        </p>

                    </div>

                </div>


                <!-- TUTORIAL -->
                <div class="col-md-4">

                    <div class="cardx">

                        <i class="bi bi-play-circle icon"></i>

                        <h3 class="mt-3">
                            Tutorial
                        </h3>

                        <p>
                            Panduan praktis untuk Cat Lovers
                            dalam merawat kucing sehari-hari.
                        </p>

                    </div>

                </div>


                <!-- MEDIA SOSIAL -->
                <div class="col-md-4">

                    <div class="cardx">

                        <i class="bi bi-instagram icon"></i>

                        <h3 class="mt-3">
                            Media Sosial
                        </h3>

                        <p>
                            Ikuti konten terbaru dan informasi
                            kegiatan Cat Shop.
                        </p>

                    </div>

                </div>

            </div>

        </div>

    </section>


    <!-- FOOTER -->
    <footer>

        <div class="container d-flex justify-content-between flex-wrap">

            <div>
                <b class="text-dark">
                    CAT SHOP
                </b>

                <br>

                Pusat kebutuhan kucing terlengkap.
            </div>


            <div>
                WhatsApp: 0857-1932-3258
            </div>


            <div>
                Copyright © 2026 Cat Shop.
            </div>

        </div>

    </footer>

</body>

</html>