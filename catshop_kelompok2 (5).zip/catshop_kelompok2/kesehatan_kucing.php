<?php
include 'koneksi.php';
$produk = [];
$query = mysqli_query($koneksi, "SELECT * FROM produk");
while ($row = mysqli_fetch_assoc($query)) {
    $produk[] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vitamin & Kesehatan - Cat Shop</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light">

    <!-- Topbar -->
    <div class="topbar d-flex align-items-center bg-dark text-white py-1 px-3 small">
        <div class="container d-flex justify-content-between">
            <span>CAT SHOP - Pusat Kebutuhan Kucing</span>
            <span>0857-1932-3258</span>
        </div>
    </div>

    <!-- Header -->
    <header class="header bg-white py-3 border-bottom shadow-sm">
        <div class="container d-flex justify-content-between align-items-center">
            <a href="index.php" class="text-decoration-none">
                <div class="fw-bold fs-3 text-dark">CAT SHOP</div>
                <div class="text-muted small" style="font-size: 11px;">Pusat Kebutuhan Kucing Terlengkap</div>
            </a>
            <div class="d-flex align-items-center gap-3">
                <a href="akun.php" class="text-dark fs-5"><i class="bi bi-person"></i></a>
                <a href="wishlist.php" class="text-dark fs-5"><i class="bi bi-heart"></i></a>
                <a href="keranjang.php" class="text-dark fs-5"><i class="bi bi-cart"></i></a>
            </div>
        </div>
    </header>

    <!-- Navigation Bar -->
    <nav class="bg-white border-bottom py-2">
        <div class="container d-flex overflow-auto gap-4 text-nowrap small fw-semibold justify-content-center">
            <a href="index.php" class="text-secondary text-decoration-none">HOME</a>
            <a href="shop.php" class="text-secondary text-decoration-none">SHOP</a>
            <a href="brand.php" class="text-secondary text-decoration-none">BRAND</a>
            <a href="kucing.php" class="text-secondary text-decoration-none">KUCING</a>
            <a href="grooming.php" class="text-secondary text-decoration-none">GROOMING</a>
            <a href="klinik.php" class="text-secondary text-decoration-none">KLINIK</a>
            <a href="hotel.php" class="text-secondary text-decoration-none">HOTEL</a>
            <a href="blog.php" class="text-secondary text-decoration-none">BLOG</a>
            <a href="toko_terdekat.php" class="text-secondary text-decoration-none">TOKO TERDEKAT</a>
        </div>
    </nav>

    <!-- Breadcrumb -->
    <div class="bg-white py-2 border-bottom small text-muted">
        <div class="container">
            <a href="index.php" class="text-decoration-none text-muted">Home Page</a> / <a href="#" class="text-decoration-none text-muted">Kategori</a> / <span class="text-dark fw-semibold">Vitamin & Kesehatan</span>
        </div>
    </div>

    <!-- Main Content -->
    <main class="container my-4">
        <div class="row">
            
            <!-- Sidebar Kiri (Filter) -->
            <div class="col-md-3 mb-4">
                <!-- Kategori -->
                <div class="card p-3 mb-3 border-0 shadow-sm">
                    <h6 class="fw-bold text-uppercase border-bottom pb-2 mb-3">Kategori</h6>
                    <ul class="list-unstyled small mb-0">
                        <li class="mb-2"><a href="makanan_kucing.php" class="text-decoration-none text-secondary">Makanan Kucing</a></li>
                        <li class="mb-2"><a href="perlengkapan_kucing.php" class="text-decoration-none text-secondary">Pasir & Toilet</a></li>
                        <li class="mb-2"><a href="mainan_kucing.php" class="text-decoration-none text-secondary">Mainan Kucing</a></li>
                        <li class="mb-2"><a href="kesehatan_kucing.php" class="text-decoration-none text-dark fw-bold">Vitamin & Kesehatan</a></li>
                        <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Aksesoris Kucing</a></li>
                        <li><a href="perawatan_kucing.php" class="text-decoration-none text-secondary">Perawatan & Grooming</a></li>
                    </ul>
                </div>

                <!-- Filter Harga -->
                <div class="card p-3 mb-3 border-0 shadow-sm">
                    <h6 class="fw-bold text-uppercase border-bottom pb-2 mb-3">Filter Harga</h6>
                    <div class="mb-2">
                        <label class="form-label text-muted small">Harga minimum</label>
                        <input type="text" class="form-control form-control-sm" value="Rp 0">
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small">Harga maksimum</label>
                        <input type="text" class="form-control form-control-sm" value="Rp 3.000.000">
                    </div>
                    <button class="btn btn-dark btn-sm w-100">Terapkan Filter</button>
                </div>

                <!-- Brands -->
                <div class="card p-3 mb-3 border-0 shadow-sm">
                    <h6 class="fw-bold text-uppercase border-bottom pb-2 mb-3">Brands</h6>
                    <ul class="list-unstyled small mb-0">
                        <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Vitapet</a></li>
                        <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Nutri-Plus</a></li>
                        <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Beaphar</a></li>
                        <li><a href="#" class="text-decoration-none text-secondary">Virbac</a></li>
                    </ul>
                </div>
            </div>

            <!-- Konten Kanan (Produk) -->
            <div class="col-md-9">
                <div class="mb-3">
                    <h2 class="fw-bold mb-1">Vitamin & Kesehatan</h2>
                    <p class="text-muted small">Berbagai pilihan vitamin, suplemen, dan produk kesehatan untuk menjaga kebugaran anabul.</p>
                </div>

                <!-- Banner Kategori -->
                <div class="p-4 mb-4 rounded-3 text-white bg-dark shadow-sm">
                    <span class="badge bg-secondary mb-2">CAT SHOP • KESEHATAN KUCING</span>
                    <h3 class="fw-bold h4">Anabul Sehat, Pemilik Tenang</h3>
                    <p class="small text-light mb-0">Berikan nutrisi tambahan dan vitamin terbaik untuk menjaga kekebalan tubuh kucing kesayangan.</p>
                </div>

                <!-- Info & Sorting -->
                <div class="d-flex justify-content-between align-items-center bg-white p-3 rounded-3 shadow-sm mb-4 small text-muted">
                    <span>Menampilkan 1-4 dari 4 produk</span>
                    <select class="form-select form-select-sm w-auto">
                        <option>Diurutkan: Terbaru</option>
                        <option>Harga Terendah</option>
                        <option>Harga Tertinggi</option>
                    </select>
                </div>

<!-- Grid Produk -->
<div class="row g-3">
    <?php foreach ($produk as $item) : ?>
        <?php if ($item['kategori'] == 'Vitamin & Kesehatan') : ?>
            <div class="col-md-4 mb-3">
                <div class="card h-100 border-0 shadow-sm p-3">
                    <img src="<?php echo $item['gambar']; ?>" class="card-img-top rounded mb-2" alt="Produk">
                    <span class="text-muted small"><?php echo $item['brand']; ?></span>
                    <h6 class="fw-bold mb-1"><?php echo $item['nama']; ?></h6>
                    <p class="text-dark fw-bold mb-3">Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></p>
                    <a href="produk.php?id=<?php echo $item['id']; ?>" class="btn btn-dark btn-sm mt-auto text-center">Lihat Produk</a>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center small text-muted">
            Copyright © 2026 Cat Shop. All rights reserved.
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>