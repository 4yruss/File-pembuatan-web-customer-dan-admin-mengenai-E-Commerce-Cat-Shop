<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Merawat Kucing Kesayangan di Rumah - Cat Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-white">

    <!-- BAGIAN 1: COPY NAVBAR/MENU DARI index.php KE SINI -->

    <div class="container mt-5 mb-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <!-- Kategori & Tanggal -->
                <div class="mb-3">
                    <span class="badge bg-info text-dark">Kucing</span>
                    <small class="text-muted ms-3"><i class="bi bi-calendar"></i> 10 Maret 2026</small>
                </div>

                <!-- Judul Artikel -->
                <h1 class="fw-bold mb-4">Merawat Kucing Kesayangan di Rumah dengan Optimal</h1>

                <!-- Gambar Utama Artikel -->
                <img src="https://placehold.co/800x400/f1f5f9/333?text=Kucing+di+Rumah" class="img-fluid rounded mb-4 w-100 object-fit-cover" alt="Kucing di dalam rumah">

                <!-- Isi Konten Artikel -->
                <div class="article-content" style="font-size: 16px; line-height: 1.8; color: #444;">
                    
                    <p>Menjaga kesehatan mental dan fisik kucing peliharaan agar tetap aktif dan ceria setiap hari di dalam rumah adalah kunci utama umur panjang. Terutama saat kucing lebih banyak menghabiskan waktu di dalam ruangan (indoor).</p>

                    <h5 class="fw-bold text-dark mt-4">1. Sediakan Waktu Bermain Interaktif</h5>
                    <p>Kucing adalah hewan pemburu alami. Berada di dalam rumah bisa membuat mereka bosan dan stres jika energi mereka tidak tersalurkan. Sediakan mainan pancingan bulu, bola kecil, atau laser (gunakan dengan hati-hati) dan luangkan waktu setidaknya 15-20 menit setiap hari untuk bermain bersama mereka.</p>

                    <h5 class="fw-bold text-dark mt-4">2. Perhatikan Asupan Nutrisi dan Berat Badan</h5>
                    <p>Kucing indoor cenderung kurang aktif dibandingkan kucing yang bebas keluar rumah. Oleh karena itu, mereka lebih rentan mengalami obesitas. Pastikan porsi makan mereka ditakar dengan baik dan gunakan makanan khusus "indoor" yang biasanya memiliki kalori lebih rendah namun tinggi serat untuk membantu pencernaan dan mengurangi hairball.</p>

                    <!-- Gambar Sisipan -->
                    <img src="https://placehold.co/800x400/f1f5f9/333?text=Mainan+Kucing" class="img-fluid rounded mb-3 mt-3 w-100" alt="Mainan kucing">

                    <h5 class="fw-bold text-dark mt-4">3. Ciptakan Lingkungan yang Kaya (Enrichment)</h5>
                    <p>Berikan kucingmu akses untuk melihat ke luar jendela. Jika memungkinkan, pasang <i>cat tree</i> (pohon kucing) atau rak dinding agar mereka bisa memanjat dan memantau area sekitar dari tempat yang tinggi. Kucing merasa aman dan nyaman saat berada di ketinggian.</p>

                </div>

                <!-- Tombol Kembali -->
                <div class="mt-5 border-top pt-4">
                    <a href="index.php" class="btn btn-primary rounded-pill px-4"><i class="bi bi-arrow-left"></i> Kembali ke Beranda</a>
                </div>

            </div>
        </div>
    </div>

    <!-- BAGIAN 2: COPY FOOTER DARI index.php KE SINI -->

</body>
</html>