<?php
session_start();
include 'koneksi.php';

// Ambil id_pesanan dari URL
$id_pesanan = isset($_GET['id']) ? $_GET['id'] : '';

// Ambil data pesanan berdasarkan id_pesanan
$ambil_pesanan = mysqli_query($koneksi, "SELECT * FROM pesanan WHERE id_pesanan = '$id_pesanan'");
$detail = mysqli_fetch_assoc($ambil_pesanan);

// Jika pesanan tidak ditemukan
if (!$detail) {
    echo "<script>alert('Nota tidak ditemukan!'); window.location='index.php';</script>";
    exit();
}

// Siapkan link WhatsApp otomatis berdasarkan detail pesanan
$no_wa_penjual = "6285719323258";
$kode_inv      = "#INV-00" . $detail['id_pesanan'];
$total_rp      = "Rp " . number_format($detail['total_belanja'], 0, ',', '.');

$pesan_wa = "Halo Admin CatShop, saya ingin konfirmasi & kirim bukti pembayaran pesanan:\n"
          . "No. Faktur: " . $kode_inv . "\n"
          . "Tanggal: " . $detail['tanggal'] . "\n"
          . "Nama Penerima: " . $detail['nama_penerima'] . "\n"
          . "No. HP/WA: " . $detail['no_hp'] . "\n"
          . "Alamat: " . $detail['alamat_lengkap'] . "\n"
          . "Kurir: " . $detail['kurir'] . "\n"
          . "Metode Pembayaran: " . $detail['metode_pembayaran'] . "\n"
          . "Total Pembayaran: " . $total_rp;

$link_wa_nota = "https://wa.me/" . $no_wa_penjual . "?text=" . rawurlencode($pesan_wa);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
-    <title>Faktur Pesanan #<?php echo $detail['id_pesanan']; ?>Cat Shop
</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body class="bg-light py-5">

    <div class="container bg-white p-5 rounded shadow-sm" style="max-width: 800px;">
        <!-- Header Nota -->
        <div class="d-flex justify-content-between align-items-center border-bottom pb-4 mb-4">
            <div>
                <h3 class="fw-bold text-dark m-0">🐱 Cat Shop</h3>
                <small class="text-muted">Pusat Kebutuhan Kucing Terlengkap</small>
            </div>
            <div class="text-end">
                <h4 class="fw-bold text-secondary m-0">FAKTUR</h4>
                <p class="m-0 text-muted">Tanggal: <?php echo $detail['tanggal']; ?></p>
                <span class="badge bg-dark">#INV-00<?php echo $detail['id_pesanan']; ?></span>
            </div>
        </div>

        <!-- Informasi Alamat & Pembayaran -->
        <div class="row mb-4">
            <div class="col-md-6">
                <h6 class="fw-bold text-uppercase text-muted fs-7">Alamat Pengiriman:</h6>
                <p class="mb-1 fw-bold"><?php echo $detail['nama_penerima']; ?></p>
                <p class="mb-1"><?php echo $detail['alamat_lengkap']; ?></p>
                <p class="mb-1 text-muted">No. HP: <?php echo $detail['no_hp']; ?></p>
                <p class="mb-0 text-muted">Kurir: <?php echo $detail['kurir']; ?></p>
            </div>
            <div class="col-md-6 text-md-end">
                <h6 class="fw-bold text-uppercase text-muted fs-7">Metode Pembayaran:</h6>
                <p class="mb-0 fw-bold text-primary"><?php echo $detail['metode_pembayaran']; ?></p>
            </div>
        </div>

        <!-- Tabel Rincian -->
        <table class="table table-bordered mb-4">
            <thead class="table-dark">
                <tr>
                    <th>Detail Pesanan</th>
                    <th class="text-end">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <strong>Belanja Produk Cat Shop</strong><br>
                        <small class="text-muted">Pembelian via *Website* Cat Shop</small>
                    </td>
                    <td class="text-end fw-bold">Rp <?php echo number_format($detail['total_belanja'], 0, ',', '.'); ?></td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th class="text-end">Total Pembayaran:</th>
                    <th class="text-end text-primary fs-5">Rp <?php echo number_format($detail['total_belanja'], 0, ',', '.'); ?></th>
                </tr>
            </tfoot>
        </table>

        <!-- Tombol Aksi (Hilang saat diprint) -->
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 no-print mt-4">
            <a href="index.php" class="btn btn-outline-secondary">← Kembali ke Beranda</a>
            <div class="d-flex flex-wrap gap-2">
                <a href="<?php echo $link_wa_nota; ?>" target="_blank" rel="noopener noreferrer" class="btn btn-success">
                    Kirim Bukti / Chat WA
                </a>
                <button onclick="window.print()" class="btn btn-dark">Cetak / Simpan PDF</button>
            </div>
        </div>
    </div>

</body>
</html>