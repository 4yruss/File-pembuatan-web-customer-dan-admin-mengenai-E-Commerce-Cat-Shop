<?php
session_start();
include 'koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='akun.php';</script>";
    exit;
}

$id_user = $_SESSION['user_id'];

// Ambil data keranjang dari database yang digabungkan dengan tabel produk
$query_keranjang = mysqli_query($koneksi, "
    SELECT keranjang.id_keranjang, keranjang.jumlah, produk.nama, produk.harga, produk.gambar
    FROM keranjang
    JOIN produk ON keranjang.id_produk = produk.id
    WHERE keranjang.id_user = '$id_user'
");

// Hitung total jumlah produk untuk badge keranjang di header
$query_jml = mysqli_query($koneksi, "SELECT SUM(jumlah) AS total FROM keranjang WHERE id_user = '$id_user'");
$data_jml = mysqli_fetch_assoc($query_jml);
$jumlah_keranjang = $data_jml['total'] ?? 0
?>
<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Keranjang - Cat Shop</title>

    <!-- Bootstrap -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fa;
        }

        .logo {
            font-size: 28px;
            font-weight: 800;
            color: #111;
            text-decoration: none;
        }

        .header-icon {
            color: #111;
            text-decoration: none;
            font-size: 22px;
            margin-left: 20px;
            position: relative;
        }

        .badge-count {
            position: absolute;
            top: -9px;
            right: -10px;

            background: #111;
            color: #fff;

            border-radius: 20px;

            font-size: 10px;

            min-width: 16px;
            height: 16px;

            text-align: center;
        }

        .item {
            background: #fff;
            border: 1px solid #e5e5e5;
            border-radius: 10px;
            padding: 15px;
        }

        .item img {
            width: 90px;
            height: 90px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>

<body>

    <!-- =========================
         HEADER
    ========================== -->
    <header class="bg-white border-bottom py-3">

        <div class="container d-flex justify-content-between align-items-center">

            <!-- Logo -->
            <a href="index.php" class="logo">
                CAT SHOP
            </a>


            <!-- Header Icons -->
            <div>

                <!-- Akun -->
                <a href="akun.php" class="header-icon">
                    <i class="bi bi-person"></i>
                </a>


                <!-- Wishlist -->
                <a href="wishlist.php" class="header-icon">

                    <i class="bi bi-heart"></i>

                    <span
                        class="badge-count"
                        id="wishCount"
                    >
                        0
                    </span>

                </a>


<!-- Keranjang -->
<a href="keranjang.php" class="header-icon">
    <i class="bi bi-cart3"></i>
    <span class="badge-count">
        <?php echo $jumlah_keranjang; ?>
    </span>
</a>
            </div>

        </div>

    </header>


    <!-- =========================
         MAIN CONTENT
    ========================== -->
    <main class="container py-5">

        <h2 class="fw-bold">
            Keranjang Belanja
        </h2>


 <div class="mt-4">
        <?php if (mysqli_num_rows($query_keranjang) == 0) : ?>
            <div class="alert alert-light border">
                Keranjang masih kosong. Silakan pilih produk dari halaman Shop.
            </div>
        <?php else : ?>
            <div class="table-responsive">
                <table class="table table-bordered align-middle text-center">
                    <thead class="table-light">
                        <tr>
                            <th>Gambar</th>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_belanja = 0;
                        while ($item = mysqli_fetch_assoc($query_keranjang)) : 
                            $subtotal = $item['harga'] * $item['jumlah'];
                            $total_belanja += $subtotal;
                        ?>
                        <tr>
                            <td>
                                <img src="<?= $item['gambar']; ?>" alt="<?= $item['nama']; ?>" width="50">
                            </td>
                            <td><?= $item['nama']; ?></td>
                            <td>Rp <?= number_format($item['harga'], 0, ',', '.'); ?></td>
                            <td><?= $item['jumlah']; ?></td>
                            <td>Rp <?= number_format($subtotal, 0, ',', '.'); ?></td>
                            <td>
<a href="hapus_keranjang.php?id=<?php echo $item['id_keranjang']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus produk ini dari keranjang?')">
    <i class="bi bi-trash"></i>
</a>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <!-- Bagian Total Belanja & Checkout -->
            <div class="d-flex justify-content-between align-items-center mt-4 p-3 border rounded bg-light">
                <h4 class="mb-0 fw-bold">Total: Rp <?= number_format($total_belanja, 0, ',', '.'); ?></h4>
<a href="checkout.php" class="btn btn-dark btn-lg">Lanjut ke Checkout</a>
            </div>
        <?php endif; ?>
    </div>

    </main>


    <!-- =========================
         JAVASCRIPT
    ========================== -->
    <script>

        // =========================
        // AMBIL DATA KERANJANG
        // =========================

        let cart = JSON.parse(
            localStorage.getItem('catshop_cart') || '[]'
        );


        // =========================
        // AMBIL DATA WISHLIST
        // =========================

        let wishlist = JSON.parse(
            localStorage.getItem('catshop_wishlist') || '[]'
        );


        // =========================
        // UPDATE JUMLAH WISHLIST
        // =========================

        document.getElementById('wishCount').textContent =
            wishlist.length;


        // =========================
        // UPDATE JUMLAH KERANJANG
        // =========================

        document.getElementById('cartCount').textContent =
            cart.reduce(
                (total, item) => total + (item.qty || 1),
                0
            );


        // =========================
        // TAMPILKAN KERANJANG
        // =========================

        function render() {

            const list = document.getElementById('list');
            const totalElement = document.getElementById('total');


            // Jika keranjang kosong
            if (cart.length === 0) {

                list.innerHTML = `
                    <div class="alert alert-light border">
                        Keranjang masih kosong.
                        Silakan pilih produk dari halaman Shop.
                    </div>
                `;

                totalElement.innerHTML = '';

                return;
            }


            let total = 0;


            // Tampilkan setiap produk
            list.innerHTML = cart.map((product, index) => {

                const quantity = product.qty || 1;

                total += Number(product.price) * quantity;


                return `
                    <div class="item d-flex align-items-center gap-3 mb-3">

                        <!-- Gambar Produk -->
                        <img
                            src="${product.image}"
                            alt="${product.name}"
                        >


                        <!-- Informasi Produk -->
                        <div class="flex-grow-1">

                            <h6 class="fw-bold">
                                ${product.name}
                            </h6>


                            <div>
                                Rp ${Number(product.price).toLocaleString('id-ID')}
                            </div>


                            <!-- Kontrol Jumlah -->
                            <div class="mt-2">

                                <button
                                    class="btn btn-sm btn-outline-secondary"
                                    onclick="qty(${index}, -1)"
                                >
                                    −
                                </button>


                                <span class="mx-3">
                                    ${quantity}
                                </span>


                                <button
                                    class="btn btn-sm btn-outline-secondary"
                                    onclick="qty(${index}, 1)"
                                >
                                    +
                                </button>


                                <!-- Tombol Hapus -->
                                <button
                                    class="btn btn-sm btn-outline-danger ms-3"
                                    onclick="del(${index})"
                                >
                                    Hapus
                                </button>

                            </div>

                        </div>

                    </div>
                `;

            }).join('');


            // =========================
            // TAMPILKAN TOTAL
            // =========================

            totalElement.innerHTML = `
                <div class="card p-3">

                    <h5>
                        Total:
                        <b>
                            Rp ${total.toLocaleString('id-ID')}
                        </b>
                    </h5>


                    <!-- Checkout WhatsApp -->
                    <a
                        href="https://wa.me/6285719323258?text=Halo%20Cat%20Shop%2C%20saya%20ingin%20melanjutkan%20pesanan%20dari%20keranjang."
                        class="btn btn-dark"
                    >
                        Checkout via WhatsApp
                    </a>

                </div>
            `;
        }


        // =========================
        // UBAH JUMLAH PRODUK
        // =========================

        function qty(index, number) {

            cart[index].qty =
                (cart[index].qty || 1) + number;


            // Jika jumlah menjadi 0
            if (cart[index].qty < 1) {
                cart.splice(index, 1);
            }


            // Simpan perubahan
            localStorage.setItem(
                'catshop_cart',
                JSON.stringify(cart)
            );


            // Refresh halaman
            location.reload();
        }


        // =========================
        // HAPUS PRODUK
        // =========================

        function del(index) {

            cart.splice(index, 1);


            // Simpan perubahan
            localStorage.setItem(
                'catshop_cart',
                JSON.stringify(cart)
            );


            // Refresh halaman
            location.reload();
        }


        // =========================
        // JALANKAN RENDER
        // =========================

        render();

    </script>

</body>

</html>