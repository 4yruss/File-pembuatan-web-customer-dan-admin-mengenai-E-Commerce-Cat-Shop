<?php
// admin/produk.php
// CRUD tabel produk: daftar, tambah (dengan upload gambar), edit, hapus.
//
// Catatan penyimpanan gambar:
//  - File yang diupload disimpan di folder ../img/ dan di database dicatat sebagai "img/namafile.ext"
//    (relatif terhadap root toko, sama seperti cara halaman toko memanggil $item['gambar']).
//  - Gambar lama berupa URL (https://placehold.co/...) tetap didukung lewat kolom "URL gambar".

require_once __DIR__ . '/cek_admin.php';

$halaman_aktif = 'produk';

$folder_upload = __DIR__ . '/../img/';
$maks_ukuran   = 2 * 1024 * 1024; // 2 MB
$ekstensi_ok   = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif'];

// ---------- Fungsi bantu ----------

// Menyimpan file upload. Mengembalikan "img/namafile" atau null (isi $err bila gagal).
function simpan_gambar($file, $folder_upload, $maks_ukuran, $ekstensi_ok, &$err)
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $err = 'Upload gambar gagal (kode error ' . (int)$file['error'] . ').';
        return null;
    }
    if ($file['size'] > $maks_ukuran) {
        $err = 'Ukuran gambar maksimal 2 MB.';
        return null;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!isset($ekstensi_ok[$ext])) {
        $err = 'Format gambar harus JPG, PNG, WEBP, atau GIF.';
        return null;
    }
    // Cek isi file yang sebenarnya, bukan hanya ekstensinya
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if ($mime !== $ekstensi_ok[$ext] || @getimagesize($file['tmp_name']) === false) {
        $err = 'File yang diupload bukan gambar yang valid.';
        return null;
    }
    if (!is_dir($folder_upload) || !is_writable($folder_upload)) {
        $err = 'Folder img/ tidak ditemukan atau tidak bisa ditulis.';
        return null;
    }
    $nama_dasar = preg_replace('/[^A-Za-z0-9_-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
    $nama_dasar = substr($nama_dasar, 0, 60);
    $nama_baru  = 'produk_' . date('YmdHis') . '_' . $nama_dasar . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $folder_upload . $nama_baru)) {
        $err = 'Gagal menyimpan file ke folder img/.';
        return null;
    }
    return 'img/' . $nama_baru;
}

// Menghapus file gambar lokal "img/xxx" jika tidak dipakai produk lain / bukti transfer.
function hapus_gambar_lokal($db, $path, $folder_upload, $id_kecuali)
{
    if (!preg_match('#^img/[^/\\\\]+$#', (string)$path)) {
        return; // bukan file lokal di img/ (mis. URL), jangan disentuh
    }
    $nama = basename($path);

    $stmt = mysqli_prepare($db, "SELECT COUNT(*) AS n FROM produk WHERE gambar = ? AND id <> ?");
    mysqli_stmt_bind_param($stmt, 'ss', $path, $id_kecuali);
    mysqli_stmt_execute($stmt);
    $dipakai_produk = (int)mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['n'];
    mysqli_stmt_close($stmt);

    $stmt = mysqli_prepare($db, "SELECT COUNT(*) AS n FROM konfirmasi WHERE bukti = ?");
    mysqli_stmt_bind_param($stmt, 's', $nama);
    mysqli_stmt_execute($stmt);
    $dipakai_bukti = (int)mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['n'];
    mysqli_stmt_close($stmt);

    if ($dipakai_produk === 0 && $dipakai_bukti === 0) {
        $lokasi = $folder_upload . $nama;
        if (is_file($lokasi)) {
            @unlink($lokasi);
        }
    }
}

// URL gambar untuk preview di halaman admin (admin/ ada satu tingkat di bawah root)
function url_gambar_admin($gambar)
{
    $gambar = (string)$gambar;
    if ($gambar === '') {
        return 'https://placehold.co/80x80/eeeeee/999?text=No+Img';
    }
    if (preg_match('#^https?://#i', $gambar)) {
        return $gambar;
    }
    return '../' . $gambar;
}

// ---------- Proses form (POST) ----------

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        set_flash('gagal', 'Sesi tidak valid. Muat ulang halaman lalu coba lagi.');
        header('Location: produk.php');
        exit;
    }

    $aksi = $_POST['aksi'] ?? '';

    // --- HAPUS ---
    if ($aksi === 'hapus') {
        $id = trim($_POST['id'] ?? '');

        $stmt = mysqli_prepare($db, "SELECT gambar FROM produk WHERE id = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 's', $id);
        mysqli_stmt_execute($stmt);
        $lama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);

        if (!$lama) {
            set_flash('gagal', 'Produk tidak ditemukan.');
        } else {
            // Bersihkan keranjang & wishlist yang masih menunjuk produk ini
            $stmt = mysqli_prepare($db, "DELETE FROM keranjang WHERE id_produk = ?");
            mysqli_stmt_bind_param($stmt, 's', $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            if (ctype_digit($id)) { // kolom wishlist.id_produk bertipe angka
                $id_angka = (int)$id;
                $stmt = mysqli_prepare($db, "DELETE FROM wishlist WHERE id_produk = ?");
                mysqli_stmt_bind_param($stmt, 'i', $id_angka);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }

            $stmt = mysqli_prepare($db, "DELETE FROM produk WHERE id = ?");
            mysqli_stmt_bind_param($stmt, 's', $id);
            $ok = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            if ($ok) {
                hapus_gambar_lokal($db, $lama['gambar'], $folder_upload, $id);
                set_flash('sukses', 'Produk berhasil dihapus.');
            } else {
                set_flash('gagal', 'Produk gagal dihapus.');
            }
        }
        header('Location: produk.php');
        exit;
    }

    // --- TAMBAH / EDIT ---
    if ($aksi === 'tambah' || $aksi === 'edit') {
        $id       = trim($_POST['id'] ?? '');
        $brand    = trim($_POST['brand'] ?? '');
        $nama     = trim($_POST['nama'] ?? '');
        $kategori = trim($_POST['kategori'] ?? '');
        $berat    = trim($_POST['berat'] ?? '');
        $harga_in = trim($_POST['harga'] ?? '');
        $badge    = trim($_POST['badge'] ?? '');
        $url_gbr  = trim($_POST['gambar_url'] ?? '');

        $errors = [];

        if ($id === '' || !preg_match('/^[A-Za-z0-9_-]{1,50}$/', $id)) {
            $errors[] = 'ID produk wajib diisi (maks. 50 karakter: huruf, angka, tanda - dan _).';
        }
        if ($nama === '' || mb_strlen($nama) > 100) {
            $errors[] = 'Nama produk wajib diisi (maks. 100 karakter).';
        }
        if (mb_strlen($brand) > 50) {
            $errors[] = 'Brand maksimal 50 karakter.';
        }
        if (mb_strlen($kategori) > 50) {
            $errors[] = 'Kategori maksimal 50 karakter.';
        }
        if (mb_strlen($berat) > 20) {
            $errors[] = 'Berat maksimal 20 karakter.';
        }
        if (mb_strlen($badge) > 20) {
            $errors[] = 'Badge maksimal 20 karakter.';
        }
        if ($harga_in === '' || !ctype_digit($harga_in) || (int)$harga_in > 2000000000) {
            $errors[] = 'Harga harus berupa angka bulat (tanpa titik/koma).';
        }
        if ($url_gbr !== '' && (!filter_var($url_gbr, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url_gbr) || strlen($url_gbr) > 255)) {
            $errors[] = 'URL gambar tidak valid (harus diawali http:// atau https://, maks. 255 karakter).';
        }
        $harga = (int)$harga_in;

        // Data lama (untuk edit) dan cek duplikasi ID (untuk tambah)
        $gambar_lama = '';
        if ($aksi === 'edit') {
            $stmt = mysqli_prepare($db, "SELECT gambar FROM produk WHERE id = ? LIMIT 1");
            mysqli_stmt_bind_param($stmt, 's', $id);
            mysqli_stmt_execute($stmt);
            $lama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            mysqli_stmt_close($stmt);
            if (!$lama) {
                $errors[] = 'Produk yang akan diedit tidak ditemukan.';
            } else {
                $gambar_lama = (string)$lama['gambar'];
            }
        } else {
            $stmt = mysqli_prepare($db, "SELECT COUNT(*) AS n FROM produk WHERE id = ?");
            mysqli_stmt_bind_param($stmt, 's', $id);
            mysqli_stmt_execute($stmt);
            $ada = (int)mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['n'];
            mysqli_stmt_close($stmt);
            if ($ada > 0) {
                $errors[] = 'ID produk "' . $id . '" sudah dipakai produk lain.';
            }
        }

        // Tentukan gambar: file upload > URL > gambar lama
        $gambar_baru = $gambar_lama;
        $upload_baru = false;
        if (!$errors) {
            if (!empty($_FILES['gambar']['name'])) {
                $err_upload = '';
                $hasil = simpan_gambar($_FILES['gambar'], $folder_upload, $maks_ukuran, $ekstensi_ok, $err_upload);
                if ($hasil === null) {
                    $errors[] = $err_upload;
                } else {
                    $gambar_baru = $hasil;
                    $upload_baru = true;
                }
            } elseif ($url_gbr !== '') {
                $gambar_baru = $url_gbr;
            }
        }

        if ($errors) {
            $_SESSION['form_error'] = $errors;
            $_SESSION['form_data'] = compact('id', 'brand', 'nama', 'kategori', 'berat', 'badge') + ['harga' => $harga_in, 'gambar' => $gambar_lama, 'gambar_url' => $url_gbr];
            header('Location: produk.php?aksi=' . ($aksi === 'edit' ? 'edit&id=' . urlencode($id) : 'tambah'));
            exit;
        }

        if ($aksi === 'tambah') {
            $stmt = mysqli_prepare($db, "INSERT INTO produk (id, brand, nama, kategori, berat, harga, gambar, badge) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, 'sssssiss', $id, $brand, $nama, $kategori, $berat, $harga, $gambar_baru, $badge);
            $ok = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            if ($ok) {
                set_flash('sukses', 'Produk "' . $nama . '" berhasil ditambahkan.');
            } else {
                if ($upload_baru) {
                    hapus_gambar_lokal($db, $gambar_baru, $folder_upload, $id);
                }
                set_flash('gagal', 'Produk gagal disimpan.');
            }
        } else {
            $stmt = mysqli_prepare($db, "UPDATE produk SET brand = ?, nama = ?, kategori = ?, berat = ?, harga = ?, gambar = ?, badge = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, 'ssssisss', $brand, $nama, $kategori, $berat, $harga, $gambar_baru, $badge, $id);
            $ok = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            if ($ok) {
                // Hapus file lama bila gambarnya sudah diganti
                if ($gambar_baru !== $gambar_lama) {
                    hapus_gambar_lokal($db, $gambar_lama, $folder_upload, $id);
                }
                set_flash('sukses', 'Produk "' . $nama . '" berhasil diperbarui.');
            } else {
                if ($upload_baru) {
                    hapus_gambar_lokal($db, $gambar_baru, $folder_upload, $id);
                }
                set_flash('gagal', 'Produk gagal diperbarui.');
            }
        }
        header('Location: produk.php');
        exit;
    }

    header('Location: produk.php');
    exit;
}

// ---------- Tampilan (GET) ----------

$mode = $_GET['aksi'] ?? 'daftar';
$form_error = $_SESSION['form_error'] ?? [];
$form_data  = $_SESSION['form_data'] ?? null;
unset($_SESSION['form_error'], $_SESSION['form_data']);

// Daftar kategori yang sudah ada (untuk saran di form)
$daftar_kategori = [];
$q = mysqli_query($db, "SELECT DISTINCT kategori FROM produk WHERE kategori IS NOT NULL AND kategori <> '' ORDER BY kategori");
while ($r = mysqli_fetch_assoc($q)) {
    $daftar_kategori[] = $r['kategori'];
}

$produk_edit = null;
if ($mode === 'edit') {
    $id_edit = trim($_GET['id'] ?? '');
    $stmt = mysqli_prepare($db, "SELECT * FROM produk WHERE id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 's', $id_edit);
    mysqli_stmt_execute($stmt);
    $produk_edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    if (!$produk_edit) {
        set_flash('gagal', 'Produk tidak ditemukan.');
        header('Location: produk.php');
        exit;
    }
    if ($form_data) {
        $produk_edit = array_merge($produk_edit, $form_data);
    }
}

$nilai = ['id' => '', 'brand' => '', 'nama' => '', 'kategori' => '', 'berat' => '', 'harga' => '', 'gambar' => '', 'badge' => '', 'gambar_url' => ''];
if ($mode === 'tambah' && $form_data) {
    $nilai = array_merge($nilai, $form_data);
}
if ($mode === 'edit') {
    $nilai = array_merge($nilai, $produk_edit);
}

// Daftar produk + pencarian
$cari = trim($_GET['q'] ?? '');
$produk_list = [];
if ($mode === 'daftar') {
    if ($cari !== '') {
        $like = '%' . $cari . '%';
        $stmt = mysqli_prepare($db, "SELECT * FROM produk WHERE id LIKE ? OR nama LIKE ? OR brand LIKE ? OR kategori LIKE ? ORDER BY nama ASC");
        mysqli_stmt_bind_param($stmt, 'ssss', $like, $like, $like, $like);
        mysqli_stmt_execute($stmt);
        $hasil = mysqli_stmt_get_result($stmt);
    } else {
        $hasil = mysqli_query($db, "SELECT * FROM produk ORDER BY nama ASC");
    }
    while ($r = mysqli_fetch_assoc($hasil)) {
        $produk_list[] = $r;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Produk - Admin CatShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f1f3f6; }
        .thumb { width: 60px; height: 60px; object-fit: contain; background: #fff; border: 1px solid #dee2e6; border-radius: 6px; }
        .preview-besar { max-width: 180px; max-height: 180px; object-fit: contain; background: #fff; border: 1px solid #dee2e6; border-radius: 6px; }
    </style>
</head>
<body>
<?php include __DIR__ . '/_navbar.php'; ?>

<div class="container pb-5">
<?php if ($mode === 'tambah' || $mode === 'edit'): ?>

    <!-- ===================== FORM TAMBAH / EDIT ===================== -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0"><?= $mode === 'edit' ? 'Edit Produk' : 'Tambah Produk Baru' ?></h3>
        <a href="produk.php" class="btn btn-outline-secondary btn-sm">&larr; Kembali ke daftar</a>
    </div>

    <?php if ($form_error): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($form_error as $e): ?>
                    <li><?= h($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="post" action="produk.php" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="aksi" value="<?= $mode === 'edit' ? 'edit' : 'tambah' ?>">

                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="id" class="form-label">ID Produk <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="id" name="id" maxlength="50"
                               pattern="[A-Za-z0-9_\-]+" value="<?= h($nilai['id']) ?>"
                               <?= $mode === 'edit' ? 'readonly' : 'required' ?>>
                        <div class="form-text">
                            <?= $mode === 'edit' ? 'ID tidak dapat diubah.' : 'Huruf, angka, - dan _ saja. Contoh: 903 atau whiskas-tuna-1kg' ?>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <label for="nama" class="form-label">Nama Produk <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nama" name="nama" maxlength="100"
                               value="<?= h($nilai['nama']) ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label for="brand" class="form-label">Brand</label>
                        <input type="text" class="form-control" id="brand" name="brand" maxlength="50"
                               value="<?= h($nilai['brand']) ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="kategori" class="form-label">Kategori</label>
                        <input type="text" class="form-control" id="kategori" name="kategori" maxlength="50"
                               list="saran-kategori" value="<?= h($nilai['kategori']) ?>">
                        <datalist id="saran-kategori">
                            <?php foreach ($daftar_kategori as $k): ?>
                                <option value="<?= h($k) ?>"></option>
                            <?php endforeach; ?>
                        </datalist>
                    </div>
                    <div class="col-md-4">
                        <label for="berat" class="form-label">Berat</label>
                        <input type="text" class="form-control" id="berat" name="berat" maxlength="20"
                               value="<?= h($nilai['berat']) ?>">
                        <div class="form-text">Contoh: 2000 atau 85 gr</div>
                    </div>

                    <div class="col-md-6">
                        <label for="harga" class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="harga" name="harga" min="0" step="1"
                               value="<?= h($nilai['harga']) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="badge" class="form-label">Badge</label>
                        <input type="text" class="form-control" id="badge" name="badge" maxlength="20"
                               value="<?= h($nilai['badge']) ?>">
                        <div class="form-text">Label kecil di produk, mis. Terlaris, PROMO, Spesial. Boleh kosong.</div>
                    </div>

                    <div class="col-12">
                        <hr class="my-1">
                        <label class="form-label fw-semibold">Gambar Produk</label>
                    </div>
                    <?php if ($mode === 'edit' && $nilai['gambar'] !== ''): ?>
                        <div class="col-12">
                            <div class="small text-muted mb-1">Gambar saat ini:</div>
                            <img src="<?= h(url_gambar_admin($nilai['gambar'])) ?>" alt="Gambar saat ini" class="preview-besar">
                            <div class="form-text">Kosongkan kolom di bawah jika tidak ingin mengganti gambar.</div>
                        </div>
                    <?php endif; ?>
                    <div class="col-md-6">
                        <label for="gambar" class="form-label">Upload gambar (JPG, PNG, WEBP, GIF - maks. 2 MB)</label>
                        <input type="file" class="form-control" id="gambar" name="gambar" accept=".jpg,.jpeg,.png,.webp,.gif,image/*">
                        <div class="form-text">Disimpan di folder img/.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="gambar_url" class="form-label">Atau tempel URL gambar</label>
                        <input type="url" class="form-control" id="gambar_url" name="gambar_url" maxlength="255"
                               placeholder="https://..." value="<?= h($nilai['gambar_url']) ?>">
                        <div class="form-text">Jika upload file dan URL sama-sama diisi, yang dipakai adalah file upload.</div>
                    </div>
                </div>

                <div class="mt-4 d-flex gap-2">
                    <button type="submit" class="btn btn-dark"><?= $mode === 'edit' ? 'Simpan Perubahan' : 'Simpan Produk' ?></button>
                    <a href="produk.php" class="btn btn-outline-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>

<?php else: ?>

    <!-- ===================== DAFTAR PRODUK ===================== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h3 class="mb-0">Data Produk</h3>
        <a href="produk.php?aksi=tambah" class="btn btn-dark">+ Tambah Produk</a>
    </div>

    <?php tampil_flash(); ?>

    <form method="get" action="produk.php" class="row g-2 mb-3">
        <div class="col-sm-8 col-md-6">
            <input type="search" name="q" class="form-control" placeholder="Cari ID, nama, brand, atau kategori..."
                   value="<?= h($cari) ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-dark">Cari</button>
            <?php if ($cari !== ''): ?>
                <a href="produk.php" class="btn btn-link">Reset</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Gambar</th>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>Brand</th>
                        <th>Kategori</th>
                        <th>Berat</th>
                        <th class="text-end">Harga</th>
                        <th>Badge</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$produk_list): ?>
                    <tr><td colspan="9" class="text-center text-muted py-4">
                        <?= $cari !== '' ? 'Tidak ada produk yang cocok dengan pencarian.' : 'Belum ada produk.' ?>
                    </td></tr>
                <?php endif; ?>
                <?php foreach ($produk_list as $p): ?>
                    <tr>
                        <td><img src="<?= h(url_gambar_admin($p['gambar'])) ?>" alt="" class="thumb" loading="lazy"></td>
                        <td class="text-break"><code><?= h($p['id']) ?></code></td>
                        <td><?= h($p['nama']) ?></td>
                        <td><?= h($p['brand']) ?></td>
                        <td><?= h($p['kategori']) ?></td>
                        <td><?= h($p['berat']) ?></td>
                        <td class="text-end"><?= h(rupiah($p['harga'])) ?></td>
                        <td>
                            <?php if ($p['badge'] !== null && $p['badge'] !== ''): ?>
                                <span class="badge bg-warning text-dark"><?= h($p['badge']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center text-nowrap">
                            <a href="produk.php?aksi=edit&id=<?= urlencode($p['id']) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <form method="post" action="produk.php" class="d-inline"
                                  onsubmit="return confirm('Hapus produk &quot;<?= h(addslashes($p['nama'])) ?>&quot;? Tindakan ini tidak bisa dibatalkan.');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="aksi" value="hapus">
                                <input type="hidden" name="id" value="<?= h($p['id']) ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer bg-white text-muted small">
            Menampilkan <?= count($produk_list) ?> produk
        </div>
    </div>

<?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
