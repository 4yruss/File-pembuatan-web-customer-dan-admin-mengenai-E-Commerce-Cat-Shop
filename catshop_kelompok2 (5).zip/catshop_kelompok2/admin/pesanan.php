<?php
// admin/pesanan.php
// Daftar pesanan (JOIN konfirmasi) + form ubah status pesanan.

require_once __DIR__ . '/cek_admin.php';

$halaman_aktif = 'pesanan';

// Status yang tersedia. 'Dalam Pengiriman' dipakai halaman riwayat_pesanan.php milik pelanggan
// untuk memunculkan tombol "Pesanan Diterima", jadi sebaiknya tetap ada.
$daftar_status = ['Menunggu Konfirmasi', 'Diproses', 'Dalam Pengiriman', 'Terkirim', 'Selesai'];

function kelas_status($status)
{
    switch ($status) {
        case 'Menunggu Konfirmasi': return 'warning text-dark';
        case 'Diproses':            return 'info text-dark';
        case 'Dalam Pengiriman':    return 'primary';
        case 'Terkirim':            return 'secondary';
        case 'Selesai':             return 'success';
        default:                    return 'dark';
    }
}

// ---------- Proses ubah status (POST) ----------

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kembali = 'pesanan.php';
    if (!empty($_POST['kembali']) && preg_match('/^[A-Za-z0-9_=&%+.\-]*$/', $_POST['kembali'])) {
        $kembali = 'pesanan.php' . ($_POST['kembali'] !== '' ? '?' . $_POST['kembali'] : '');
    }

    if (!csrf_valid()) {
        set_flash('gagal', 'Sesi tidak valid. Muat ulang halaman lalu coba lagi.');
        header('Location: ' . $kembali);
        exit;
    }

    $id_pesanan = (int)($_POST['id_pesanan'] ?? 0);
    $status_baru = trim($_POST['status'] ?? '');

    if ($id_pesanan <= 0 || !in_array($status_baru, $daftar_status, true)) {
        set_flash('gagal', 'Data tidak valid. Status tidak diubah.');
        header('Location: ' . $kembali);
        exit;
    }

    $stmt = mysqli_prepare($db, "UPDATE pesanan SET status = ? WHERE id_pesanan = ?");
    mysqli_stmt_bind_param($stmt, 'si', $status_baru, $id_pesanan);
    $ok = mysqli_stmt_execute($stmt);
    $baris = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);

    if (!$ok) {
        set_flash('gagal', 'Status pesanan gagal diperbarui.');
    } elseif ($baris === 0) {
        set_flash('sukses', 'Status pesanan #INV-00' . $id_pesanan . ' tidak berubah (sudah "' . $status_baru . '" atau pesanan tidak ditemukan).');
    } else {
        set_flash('sukses', 'Status pesanan #INV-00' . $id_pesanan . ' diubah menjadi "' . $status_baru . '".');
    }
    header('Location: ' . $kembali);
    exit;
}

// ---------- Ambil data (GET) ----------

$filter_status = trim($_GET['status'] ?? '');
$cari = trim($_GET['q'] ?? '');

// Satu pesanan bisa punya lebih dari satu konfirmasi; yang ditampilkan adalah konfirmasi terbaru
// supaya baris pesanan tidak dobel.
$sql = "SELECT p.id_pesanan, p.id_user, p.nama_penerima, p.no_hp, p.alamat_lengkap, p.kurir,
               p.metode_pembayaran, p.total_belanja, p.tanggal, p.status,
               k.nama AS nama_pengirim, k.bank, k.jumlah AS jumlah_transfer,
               k.tanggal AS tanggal_konfirmasi, k.bukti
        FROM pesanan p
        LEFT JOIN konfirmasi k
               ON k.id_konfirmasi = (SELECT MAX(k2.id_konfirmasi) FROM konfirmasi k2 WHERE k2.id_pesanan = p.id_pesanan)";

$kondisi = [];
$tipe = '';
$param = [];

if ($filter_status !== '') {
    if ($filter_status === 'Menunggu Konfirmasi') {
        $kondisi[] = "(p.status = ? OR p.status IS NULL OR p.status = '')";
    } else {
        $kondisi[] = "p.status = ?";
    }
    $tipe .= 's';
    $param[] = $filter_status;
}
if ($cari !== '') {
    $kondisi[] = "(p.nama_penerima LIKE ? OR p.no_hp LIKE ? OR CAST(p.id_pesanan AS CHAR) = ?)";
    $tipe .= 'sss';
    $like = '%' . $cari . '%';
    $angka = preg_replace('/\D/', '', $cari);
    $param[] = $like;
    $param[] = $like;
    $param[] = $angka !== '' ? ltrim($angka, '0') : '-';
}
if ($kondisi) {
    $sql .= ' WHERE ' . implode(' AND ', $kondisi);
}
$sql .= ' ORDER BY p.tanggal DESC, p.id_pesanan DESC';

$stmt = mysqli_prepare($db, $sql);
if ($param) {
    mysqli_stmt_bind_param($stmt, $tipe, ...$param);
}
mysqli_stmt_execute($stmt);
$hasil = mysqli_stmt_get_result($stmt);
$pesanan_list = [];
while ($r = mysqli_fetch_assoc($hasil)) {
    $pesanan_list[] = $r;
}
mysqli_stmt_close($stmt);

// Query string untuk kembali ke filter yang sama setelah simpan status
$qs_kembali = http_build_query(array_filter(['status' => $filter_status, 'q' => $cari], function ($v) {
    return $v !== '';
}));

$folder_img = __DIR__ . '/../img/';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pesanan - Admin CatShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f1f3f6; }
        .thumb-bukti { width: 56px; height: 56px; object-fit: cover; border: 1px solid #dee2e6; border-radius: 6px; background: #fff; }
        .kolom-alamat { min-width: 200px; max-width: 280px; }
        .kolom-status { min-width: 210px; }
    </style>
</head>
<body>
<?php include __DIR__ . '/_navbar.php'; ?>

<div class="container-fluid px-lg-4 pb-5">
    <h3 class="mb-3">Data Pesanan</h3>

    <?php tampil_flash(); ?>

    <form method="get" action="pesanan.php" class="row g-2 mb-3">
        <div class="col-sm-5 col-md-4 col-lg-3">
            <select name="status" class="form-select" onchange="this.form.submit()">
                <option value="">Semua status</option>
                <?php foreach ($daftar_status as $s): ?>
                    <option value="<?= h($s) ?>" <?= $filter_status === $s ? 'selected' : '' ?>><?= h($s) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-sm-7 col-md-5 col-lg-4">
            <input type="search" name="q" class="form-control" placeholder="Cari no. pesanan, nama, atau no. HP..."
                   value="<?= h($cari) ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-dark">Cari</button>
            <?php if ($filter_status !== '' || $cari !== ''): ?>
                <a href="pesanan.php" class="btn btn-link">Reset</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="card shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>No. Pesanan</th>
                        <th>Tanggal</th>
                        <th>Penerima</th>
                        <th>Alamat</th>
                        <th>Kurir</th>
                        <th>Pembayaran</th>
                        <th class="text-end">Total</th>
                        <th>Bukti Transfer</th>
                        <th class="kolom-status">Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$pesanan_list): ?>
                    <tr><td colspan="9" class="text-center text-muted py-4">Tidak ada pesanan yang ditemukan.</td></tr>
                <?php endif; ?>

                <?php foreach ($pesanan_list as $p):
                    $status_now = ($p['status'] !== null && $p['status'] !== '') ? $p['status'] : 'Menunggu Konfirmasi';
                    $opsi_status = $daftar_status;
                    if (!in_array($status_now, $opsi_status, true)) {
                        array_unshift($opsi_status, $status_now); // jaga status lama di luar daftar agar tidak hilang
                    }
                    $nama_bukti = ($p['bukti'] !== null && $p['bukti'] !== '') ? basename($p['bukti']) : '';
                    $bukti_ada = $nama_bukti !== '' && is_file($folder_img . $nama_bukti);
                    $url_bukti = '../img/' . rawurlencode($nama_bukti);
                    ?>
                    <tr>
                        <td class="text-nowrap fw-semibold">#INV-00<?= (int)$p['id_pesanan'] ?></td>
                        <td class="text-nowrap"><?= h(date('d/m/Y H:i', strtotime($p['tanggal']))) ?></td>
                        <td>
                            <div class="fw-semibold"><?= h($p['nama_penerima']) ?></div>
                            <div class="small text-muted"><?= h($p['no_hp']) ?></div>
                        </td>
                        <td class="kolom-alamat small"><?= nl2br(h($p['alamat_lengkap'])) ?></td>
                        <td class="small"><?= $p['kurir'] !== '' ? h($p['kurir']) : '<span class="text-muted">-</span>' ?></td>
                        <td class="small"><?= h($p['metode_pembayaran']) ?></td>
                        <td class="text-end text-nowrap"><?= h(rupiah($p['total_belanja'])) ?></td>
                        <td class="small">
                            <?php if ($nama_bukti === ''): ?>
                                <span class="text-muted">Belum ada konfirmasi</span>
                            <?php else: ?>
                                <div class="d-flex gap-2 align-items-start">
                                    <?php if ($bukti_ada): ?>
                                        <a href="<?= h($url_bukti) ?>" class="lihat-bukti" data-src="<?= h($url_bukti) ?>"
                                           data-judul="Bukti transfer #INV-00<?= (int)$p['id_pesanan'] ?>">
                                            <img src="<?= h($url_bukti) ?>" alt="Bukti transfer" class="thumb-bukti" loading="lazy">
                                        </a>
                                    <?php endif; ?>
                                    <div>
                                        <?php if ($bukti_ada): ?>
                                            <a href="<?= h($url_bukti) ?>" target="_blank" rel="noopener">Buka bukti</a>
                                        <?php else: ?>
                                            <span class="text-danger">File tidak ditemukan</span>
                                        <?php endif; ?>
                                        <div class="text-muted">
                                            <?= h($p['nama_pengirim']) ?> &bull; <?= h($p['bank']) ?><br>
                                            <?= h(rupiah($p['jumlah_transfer'])) ?>
                                            <?php if ((int)$p['jumlah_transfer'] !== (int)$p['total_belanja']): ?>
                                                <br><span class="text-danger">Nominal tidak sama dengan total</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="kolom-status">
                            <span class="badge bg-<?= kelas_status($status_now) ?> mb-2"><?= h($status_now) ?></span>
                            <form method="post" action="pesanan.php" class="d-flex gap-1">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id_pesanan" value="<?= (int)$p['id_pesanan'] ?>">
                                <input type="hidden" name="kembali" value="<?= h($qs_kembali) ?>">
                                <select name="status" class="form-select form-select-sm" aria-label="Ubah status pesanan">
                                    <?php foreach ($opsi_status as $s): ?>
                                        <option value="<?= h($s) ?>" <?= $status_now === $s ? 'selected' : '' ?>><?= h($s) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-dark">Simpan</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer bg-white text-muted small">
            Menampilkan <?= count($pesanan_list) ?> pesanan
        </div>
    </div>
</div>

<!-- Modal preview bukti transfer -->
<div class="modal fade" id="modalBukti" tabindex="-1" aria-labelledby="judulBukti" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="judulBukti">Bukti transfer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body text-center">
                <img id="gambarBukti" src="" alt="Bukti transfer" class="img-fluid">
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Klik thumbnail -> tampil di modal (jika JS mati, link tetap membuka gambar langsung)
    document.querySelectorAll('.lihat-bukti').forEach(function (el) {
        el.addEventListener('click', function (e) {
            e.preventDefault();
            document.getElementById('gambarBukti').src = el.dataset.src;
            document.getElementById('judulBukti').textContent = el.dataset.judul;
            new bootstrap.Modal(document.getElementById('modalBukti')).show();
        });
    });
</script>
</body>
</html>
