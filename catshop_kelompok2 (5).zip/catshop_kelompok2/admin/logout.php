<?php
// admin/logout.php
// Menghapus sesi admin saja (sesi pelanggan di sisi toko tidak ikut terhapus).

session_start();

unset($_SESSION['admin_id'], $_SESSION['admin_nama'], $_SESSION['admin_role']);
session_regenerate_id(true);

header('Location: login.php');
exit;
