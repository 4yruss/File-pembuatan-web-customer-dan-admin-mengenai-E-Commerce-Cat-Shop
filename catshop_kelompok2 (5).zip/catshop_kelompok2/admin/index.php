<?php
// admin/index.php
// Dashboard ringkasan toko.

require_once __DIR__ . '/cek_admin.php';

$halaman_aktif = 'dashboard';

// Jumlah produk
$q = mysqli_query($db, "SELECT COUNT(*) AS total FROM produk");
$jumlah_produk = (int)mysqli_fetch_assoc($q)['total'];

// Pesanan menunggu konfirmasi (status kosong dianggap menunggu konfirmasi)
$q = mysqli_query($db, "SELECT COUNT(*) AS total FROM pesanan WHERE status = 'Menunggu Konfirmasi' OR status IS NULL OR status = ''");
$jumlah_menunggu = (int)mysqli_fetch_assoc($q)['total'];

// Total transaksi (semua pesanan masuk)
$q = mysqli_query($db, "SELECT COUNT(*) AS total FROM pesanan");
$total_transaksi = (int)mysqli_fetch_assoc($q)['total'];

// Total pendapatan dari pesanan berstatus Selesai
$q = mysqli_query($db, "SELECT COALESCE(SUM(total_belanja), 0) AS total FROM pesanan WHERE status = 'Selesai'");
$total_pendapatan = (int)mysqli_fetch_assoc($q)['total'];

// Jumlah pesanan per status
$per_status = [];
$q = mysqli_query($db, "SELECT COALESCE(NULLIF(status, ''), 'Menunggu Konfirmasi') AS st, COUNT(*) AS jml FROM pesanan GROUP BY st ORDER BY jml DESC");
while ($r = mysqli_fetch_assoc($q)) {
    $per_status[] = $r;
}

// 5 pesanan terbaru
$pesanan_terbaru = [];
$q = mysqli_query($db, "SELECT id_pesanan, nama_penerima, total_belanja, tanggal, status FROM pesanan ORDER BY tanggal DESC, id_pesanan DESC LIMIT 5");
while ($r = mysqli_fetch_assoc($q)) {
    $pesanan_terbaru[] = $r;
}

function kelas_status($status)
{
    switch ($status) {
        case 'Menunggu Konfirmasi': return 'warning text-dark';
        case 'Diproses':            return 'info text-dark';
        case 'Dalam Pengiriman':    return 'primary';
        case 'Terkirim':            return 'secondary';
        case 'Selesai':             return 'success';
        default:                    return 'dark';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard - Admin CatShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f1f3f6; }
        .angka { font-size: 1.8rem; font-weight: 700; }
    </style>
</head>
<body>
<?php include __DIR__ . '/_navbar.php'; ?>

<div class="container pb-5">
    <h3 class="mb-3">Dashboard</h3>
    <?php tampil_flash(); ?>

    <div class="row g-3 mb-4">
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card shadow-sm h-100 border-start border-4 border-primary">
                <div class="card-body">
                    <div class="text-muted small">Jumlah Produk</div>
                    <div class="angka"><?= number_format($jumlah_produk, 0, ',', '.') ?></div>
                    <a href="produk.php" class="small">Kelola produk &rarr;</a>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card shadow-sm h-100 border-start border-4 border-warning">
                <div class="card-body">
                    <div class="text-muted small">Menunggu Konfirmasi</div>
                    <div class="angka"><?= number_format($jumlah_menunggu, 0, ',', '.') ?></div>
                    <a href="pesanan.php?status=<?= urlencode('Menunggu Konfirmasi') ?>" class="small">Lihat pesanan &rarr;</a>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card shadow-sm h-100 border-start border-4 border-info">
                <div class="card-body">
                    <div class="text-muted small">Total Transaksi</div>
                    <div class="angka"><?= number_format($total_transaksi, 0, ',', '.') ?></div>
                    <a href="pesanan.php" class="small">Semua pesanan &rarr;</a>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card shadow-sm h-100 border-start border-4 border-success">
                <div class="card-body">
                    <div class="text-muted small">Total Pendapatan (Selesai)</div>
                    <div class="angka"><?= h(rupiah($total_pendapatan)) ?></div>
                    <span class="small text-muted">Hanya pesanan berstatus Selesai</span>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-semibold">Pesanan Terbaru</div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No. Pesanan</th>
                                <th>Penerima</th>
                                <th>Tanggal</th>
                                <th class="text-end">Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (!$pesanan_terbaru): ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">Belum ada pesanan.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($pesanan_terbaru as $p):
                            $st = $p['status'] !== null && $p['status'] !== '' ? $p['status'] : 'Menunggu Konfirmasi'; ?>
                            <tr>
                                <td>#INV-00<?= (int)$p['id_pesanan'] ?></td>
                                <td><?= h($p['nama_penerima']) ?></td>
                                <td><?= h(date('d/m/Y H:i', strtotime($p['tanggal']))) ?></td>
                                <td class="text-end"><?= h(rupiah($p['total_belanja'])) ?></td>
                                <td><span class="badge bg-<?= kelas_status($st) ?>"><?= h($st) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-semibold">Pesanan per Status</div>
                <ul class="list-group list-group-flush">
                    <?php if (!$per_status): ?>
                        <li class="list-group-item text-muted">Belum ada data.</li>
                    <?php endif; ?>
                    <?php foreach ($per_status as $s): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span class="badge bg-<?= kelas_status($s['st']) ?>"><?= h($s['st']) ?></span>
                            <strong><?= (int)$s['jml'] ?></strong>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
