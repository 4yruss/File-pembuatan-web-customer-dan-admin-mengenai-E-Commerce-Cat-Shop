<?php
// admin/_navbar.php
// Navigasi atas bersama untuk semua halaman admin.
// Sebelum di-include, set $halaman_aktif = 'dashboard' | 'produk' | 'pesanan'
$halaman_aktif = $halaman_aktif ?? '';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">🐾 CatShop Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuAdmin"
                aria-controls="menuAdmin" aria-expanded="false" aria-label="Buka menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuAdmin">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= $halaman_aktif === 'dashboard' ? 'active' : '' ?>" href="index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $halaman_aktif === 'produk' ? 'active' : '' ?>" href="produk.php">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $halaman_aktif === 'pesanan' ? 'active' : '' ?>" href="pesanan.php">Pesanan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../index.php" target="_blank">Lihat Toko</a>
                </li>
            </ul>
            <span class="navbar-text me-3">Halo, <?= h($_SESSION['admin_nama'] ?? 'Admin') ?></span>
            <a class="btn btn-outline-light btn-sm" href="logout.php">Logout</a>
        </div>
    </div>
</nav>
