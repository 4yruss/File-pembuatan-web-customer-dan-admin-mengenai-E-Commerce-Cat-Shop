<?php
// admin/cek_admin.php
// Di-include paling atas di setiap halaman admin (kecuali login.php).
// Memastikan pengunjung sudah login dan role-nya 'admin'.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../koneksi.php';

// Koneksi proyek ini memakai $koneksi. Jika suatu saat diganti $conn, tetap aman.
if (isset($koneksi) && $koneksi instanceof mysqli) {
    $db = $koneksi;
} elseif (isset($conn) && $conn instanceof mysqli) {
    $db = $conn;
} else {
    die('Koneksi database tidak ditemukan. Periksa file koneksi.php');
}
mysqli_set_charset($db, 'utf8mb4');

// Fungsi bantu: escape output HTML
if (!function_exists('h')) {
    function h($teks)
    {
        return htmlspecialchars((string)$teks, ENT_QUOTES, 'UTF-8');
    }
}

// Fungsi bantu: format rupiah
if (!function_exists('rupiah')) {
    function rupiah($angka)
    {
        return 'Rp ' . number_format((int)$angka, 0, ',', '.');
    }
}

// Token CSRF untuk semua form POST
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . h($_SESSION['csrf_token']) . '">';
}

function csrf_valid()
{
    return isset($_POST['csrf_token'], $_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
}

// Cek 1: sudah login sebagai admin?
if (empty($_SESSION['admin_id']) || ($_SESSION['admin_role'] ?? '') !== 'admin') {
    header('Location: login.php');
    exit;
}

// Cek 2: pastikan di database akun ini masih ada dan masih berrole admin
$id_admin = (int)$_SESSION['admin_id'];
$stmt = mysqli_prepare($db, "SELECT nama FROM users WHERE id = ? AND role = 'admin' LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $id_admin);
mysqli_stmt_execute($stmt);
$hasil = mysqli_stmt_get_result($stmt);
$admin = mysqli_fetch_assoc($hasil);
mysqli_stmt_close($stmt);

if (!$admin) {
    unset($_SESSION['admin_id'], $_SESSION['admin_nama'], $_SESSION['admin_role']);
    header('Location: login.php');
    exit;
}

$_SESSION['admin_nama'] = $admin['nama'];

// Pesan flash (berhasil / gagal) yang tampil sekali setelah redirect
function set_flash($tipe, $pesan)
{
    $_SESSION['flash'] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function tampil_flash()
{
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        $kelas = $f['tipe'] === 'sukses' ? 'success' : 'danger';
        echo '<div class="alert alert-' . $kelas . ' alert-dismissible fade show" role="alert">'
            . h($f['pesan'])
            . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button></div>';
    }
}
