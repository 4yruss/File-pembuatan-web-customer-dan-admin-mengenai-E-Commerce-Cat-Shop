<?php
// admin/login.php
// Halaman login khusus admin (tabel users, role = 'admin').

session_start();
require_once __DIR__ . '/../koneksi.php';

if (isset($koneksi) && $koneksi instanceof mysqli) {
    $db = $koneksi;
} elseif (isset($conn) && $conn instanceof mysqli) {
    $db = $conn;
} else {
    die('Koneksi database tidak ditemukan. Periksa file koneksi.php');
}
mysqli_set_charset($db, 'utf8mb4');

function h($teks)
{
    return htmlspecialchars((string)$teks, ENT_QUOTES, 'UTF-8');
}

// Jika sudah login sebagai admin, langsung ke dashboard
if (!empty($_SESSION['admin_id']) && ($_SESSION['admin_role'] ?? '') === 'admin') {
    header('Location: index.php');
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';
$email_input = '';

// Pembatasan percobaan login sederhana (5x gagal -> tunggu 5 menit)
$maks_percobaan = 5;
$waktu_tunggu = 300;
if (!isset($_SESSION['login_gagal'])) {
    $_SESSION['login_gagal'] = 0;
    $_SESSION['login_gagal_waktu'] = 0;
}
$terkunci = $_SESSION['login_gagal'] >= $maks_percobaan
    && (time() - $_SESSION['login_gagal_waktu']) < $waktu_tunggu;
if ($_SESSION['login_gagal'] >= $maks_percobaan && !$terkunci) {
    $_SESSION['login_gagal'] = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email_input = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error = 'Sesi tidak valid. Muat ulang halaman lalu coba lagi.';
    } elseif ($terkunci) {
        $error = 'Terlalu banyak percobaan gagal. Coba lagi dalam beberapa menit.';
    } elseif ($email_input === '' || $password === '') {
        $error = 'Email dan password wajib diisi.';
    } else {
        $stmt = mysqli_prepare($db, "SELECT id, nama, password, role FROM users WHERE email = ? LIMIT 1");
        if (!$stmt) {
            $error = 'Kolom role belum ada di tabel users. Jalankan dulu file database_admin.sql.';
        } else {
            mysqli_stmt_bind_param($stmt, 's', $email_input);
            mysqli_stmt_execute($stmt);
            $hasil = mysqli_stmt_get_result($stmt);
            $user = mysqli_fetch_assoc($hasil);
            mysqli_stmt_close($stmt);

            if ($user && $user['role'] === 'admin' && password_verify($password, $user['password'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = (int)$user['id'];
                $_SESSION['admin_nama'] = $user['nama'];
                $_SESSION['admin_role'] = 'admin';
                $_SESSION['login_gagal'] = 0;
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header('Location: index.php');
                exit;
            }

            $_SESSION['login_gagal']++;
            $_SESSION['login_gagal_waktu'] = time();
            $error = 'Email atau password salah, atau akun ini bukan admin.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin - CatShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f1f3f6; min-height: 100vh; display: flex; align-items: center; }
        .kartu-login { max-width: 420px; width: 100%; }
    </style>
</head>
<body>
<div class="container d-flex justify-content-center">
    <div class="card shadow-sm kartu-login">
        <div class="card-body p-4">
            <h4 class="text-center fw-bold mb-1">🐾 CatShop Admin</h4>
            <p class="text-center text-muted mb-4">Masuk untuk mengelola toko</p>

            <?php if ($error !== ''): ?>
                <div class="alert alert-danger py-2"><?= h($error) ?></div>
            <?php endif; ?>

            <form method="post" action="login.php" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email"
                           value="<?= h($email_input) ?>" required autofocus>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-dark w-100">Masuk</button>
            </form>
            <div class="text-center mt-3">
                <a href="../index.php" class="small text-decoration-none">&larr; Kembali ke toko</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
