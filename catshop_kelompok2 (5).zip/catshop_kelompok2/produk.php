<?php
session_start();
include 'koneksi.php';

// Proses saat tombol Tambah ke Keranjang ditekan
if (isset($_POST['tambah_keranjang'])) {
    if (!isset($_SESSION['user_id'])) {
        echo "<script>alert('Silakan login terlebih dahulu!'); window.location='akun.php';</script>";
        exit;
    }

    $id_user = $_SESSION['user_id'];
$id_user = $_SESSION['user_id'];
$id_produk_input = $_GET['id']; // Mengambil ID langsung dari URL agar lebih aman
$jumlah = $_POST['jumlah'];

$query_keranjang = mysqli_query($koneksi, "INSERT INTO keranjang (id_user, id_produk, jumlah) VALUES ('$id_user', '$id_produk_input', '$jumlah')");

    if ($query_keranjang) {
        echo "<script>alert('Produk berhasil ditambahkan ke keranjang!'); window.location='keranjang.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan ke keranjang.');</script>";
    }
}
// Proses saat tombol/ikon wishlist ditekan
if (isset($_POST['tambah_wishlist'])) {
    if (!isset($_SESSION['user_id'])) {
        echo "<script>alert('Silakan login terlebih dahulu!'); window.location='akun.php';</script>";
        exit;
    }

$id_user = $_SESSION['user_id'];
// Mengambil id_produk dari POST (hidden input) atau fallback ke GET
$id_produk = isset($_POST['id_produk']) ? $_POST['id_produk'] : (isset($_GET['id']) ? $_GET['id'] : '');
    // Cek apakah produk sudah ada di wishlist
    $cek_wishlist = mysqli_query($koneksi, "SELECT * FROM wishlist WHERE id_user = '$id_user' AND id_produk = '$id_produk'");
    if (mysqli_num_rows($cek_wishlist) > 0) {
        echo "<script>alert('Produk sudah ada di wishlist!'); window.location='wishlist.php';</script>";
    } else {
        $query_wishlist = mysqli_query($koneksi, "INSERT INTO wishlist (id_user, id_produk) VALUES ('$id_user', '$id_produk')");
        if ($query_wishlist) {
            echo "<script>alert('Produk berhasil ditambahkan ke wishlist!'); window.location='wishlist.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan ke wishlist.');</script>";
        }
    }
}
$id_produk = isset($_GET['id']) ? $_GET['id'] : '';

$query = mysqli_query($koneksi, "SELECT * FROM produk WHERE id = '$id_produk'");
$data = mysqli_fetch_array($query);

if ($data) {
    $nama_produk   = $data['nama']; 
    $harga_produk  = "Rp " . number_format($data['harga'], 0, ',', '.'); 
    $gambar_produk = $data['gambar']; 
    $sku           = $data['id']; 
} else {
    echo "<script>alert('Produk tidak ditemukan!'); window.location='makanan_kucing.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - Cat Shop</title>
    <!-- Pastikan link Bootstrap ini sama dengan yang ada di file Anda yang lain -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .product-image-box { border: 1px solid #e0e0e0; border-radius: 10px; padding: 20px; text-align: center; }
        .btn-add-cart { background-color: #0d6efd; color: white; border-radius: 25px; padding: 10px 30px; font-weight: bold; }
        .btn-add-cart:hover { background-color: #0b5ed7; color: white; }
    </style>
</head>
<body>

    <!-- TODO: Taruh INCLUDE NAVBAR Anda di sini (misal: include 'navbar.php';) -->

    <main class="container my-5">
        <!-- Area Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb small">
                <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none text-dark">Home Page</a></li>
                <li class="breadcrumb-item"><a href="makanan_kucing.php" class="text-decoration-none text-dark">Makanan Kucing</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo $nama_produk; ?></li>
            </ol>
        </nav>

        <div class="row">
            <!-- KOLOM KIRI: Gambar Produk -->
            <div class="col-md-5 mb-4">
                <div class="product-image-box">
                    <!-- Nanti src-nya diganti dengan variabel dari database -->
                    <img src="<?php echo $gambar_produk; ?>" alt="Gambar Produk" class="img-fluid" style="max-height: 400px; object-fit: contain;">
                </div>
            </div>

            <!-- KOLOM KANAN: Detail Produk -->
            <div class="col-md-7 px-md-4">
                <span class="badge bg-success mb-2">In Stock</span>
                <h2 class="fw-bold"><?php echo $nama_produk; ?></h2>
                <p class="text-muted small">Brand: <span class="text-primary">Royal Canin</span> | SKU: <?php echo $sku; ?></p>
                
                <h3 class="fw-bold text-primary mb-4"><?php echo $harga_produk; ?></h3>

                <h5 class="fw-bold mb-3">Informasi Produk</h5>
                <ul class="text-muted small" style="line-height: 1.8;">
                    <li><strong>Nama Produk:</strong> <?php echo $nama_produk; ?></li>
                    <li><strong>Kategori:</strong> Makanan Basah (Wet Food)</li>
                    <li><strong>Kegunaan:</strong> Mendukung kesehatan pencernaan kucing.</li>
                </ul>

                <p class="text-muted small mt-3"><em>Catatan: Informasi mengenai ukuran, bahan, dan warna mungkin berbeda. Pastikan sesuai dengan kebutuhan peliharaan Anda.</em></p>

                <hr class="my-4">

                <!-- Input Kuantitas & Tombol Tambah Keranjang -->
<form action="" method="POST" class="d-flex align-items-center mb-4">
    <!-- ID Produk disembunyikan tapi akan dikirim ke database -->
    <input type="hidden" name="id_produk" value="<?= isset($_GET['id']) ? $_GET['id'] : ''; ?>">
    
    <!-- Input untuk jumlah barang -->
    <input type="number" name="jumlah" value="1" min="1" class="form-control me-3" style="width: 80px;" required>
    
    <!-- Tombol Submit Keranjang -->
<!-- Tombol Submit Keranjang -->
                <button type="submit" name="tambah_keranjang" class="btn btn-add-cart me-2">
                    <i class="bi bi-cart-plus me-2"></i>Tambah Ke Keranjang
                </button>

                <!-- Tombol Wishlist (Ikon Love) -->
                <button type="submit" name="tambah_wishlist" class="btn btn-outline-danger" title="Tambah ke Wishlist">
                    <i class="bi bi-heart-fill"></i>
                </button>
            </form>

        </div>

        <!-- AREA BAWAH: Tabs Deskripsi -->
        <div class="row mt-5">
            <div class="col-12">
                <ul class="nav nav-tabs" id="productTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active text-dark fw-bold" id="deskripsi-tab" data-bs-toggle="tab" data-bs-target="#deskripsi-pane" type="button" role="tab" aria-controls="deskripsi-pane" aria-selected="true">Deskripsi</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link text-dark fw-bold" id="informasi-tab" data-bs-toggle="tab" data-bs-target="#informasi-pane" type="button" role="tab" aria-controls="informasi-pane" aria-selected="false">Informasi Tambahan</button>
                    </li>
                </ul>
                <div class="tab-content border border-top-0 p-4 bg-white" id="productTabContent">
                    <div class="tab-pane fade show active text-muted small" id="deskripsi-pane" role="tabpanel" aria-labelledby="deskripsi-tab" tabindex="0">
                        <h6 class="fw-bold text-dark mb-3">Mengenal <?php echo $nama_produk; ?></h6>
                        <p>Di sini Anda bisa menampilkan deskripsi panjang dari database. Penjelasan mengenai kandungan nutrisi, cara penggunaan, dan manfaat utama dari produk ini untuk kucing kesayangan Anda.</p>
                        <p>Berikan makanan dengan takaran yang sesuai dengan berat badan dan usia kucing agar hasil maksimal.</p>
                    </div>
                    <div class="tab-pane fade text-muted small" id="informasi-pane" role="tabpanel" aria-labelledby="informasi-tab" tabindex="0">
                        <p><strong>Berat Pengiriman:</strong> 100gr</p>
                        <p><strong>Dimensi Kemasan:</strong> 10cm x 15cm</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- TODO: Taruh INCLUDE FOOTER Anda di sini (misal: include 'footer.php';) -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>